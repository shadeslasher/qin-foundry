import { PartyPanel, registerParty } from "./module/party.mjs";
import { OfficerCodex, registerOfficerCodex } from "./module/officer-codex.mjs";
import { registerOfficerLimit } from "./module/officer-rules.mjs";
import { registerRecruitQuery } from "./module/recruit.mjs";
import * as CFG from "./module/config.mjs";
import { CharacterData, HenchmanData, UnitData } from "./module/data/actor-models.mjs";
import * as IM from "./module/data/item-models.mjs";
import { QinActor } from "./module/documents/actor.mjs";
import { QinItem, QinCombat } from "./module/documents/other.mjs";
import { CharacterSheet, HenchmanSheet, UnitSheet, QinItemSheet } from "./module/sheets/sheets.mjs";
import { onRenderChatMessage } from "./module/chat.mjs";
import { BattlePanel, registerBattleQuery, battleRequest } from "./module/battle/battle.mjs";
import { registerDeployDrop } from "./module/battle/deploy-drop.mjs";
import { emptyBattle, onTokenMoved, getBattle } from "./module/battle/adapter.mjs";
import * as QinRules from "./module/rules/qin-rules.mjs";
import { registerTokenHover } from "./module/token-hover.mjs";
import { registerCombatQuery, onRenderCombatTracker } from "./module/combat-actions.mjs";
import { registerAttackFxSocket, registerDamageFloats } from "./module/attack-fx.mjs";
import { registerUnitBars, redrawAllUnitBars, registerFacingKey } from "./module/unit-bars.mjs";
import { registerFactions, factionList } from "./module/factions.mjs";
import { refreshBattleUI, repositionBattleUI, lockUnitTokens, lockUnitMoves, onUnitSelected, registerUnitClicks } from "./module/battle/battle-ui.mjs";
import { refreshTactics, registerTactics } from "./module/battle/tactics-ui.mjs";
import { registerDeployZones, drawDeployZones, setDeployChangeHandler } from "./module/battle/deploy.mjs";
import { registerPreBattleCover } from "./module/battle/cover.mjs";
import { registerReinforcements, drawReinforceZones, setReinforceChangeHandler } from "./module/battle/reinforce.mjs";
import { registerTileTip, toggleTileTip } from "./module/battle/tile-tip.mjs";
import { registerDeployDrawing, syncDeployDrawing } from "./module/battle/deploy-draw.mjs";
import { panToActiveOfficer, registerTurnPan } from "./module/battle/turn-pan.mjs";
import { registerBattleSpeed } from "./module/battle/battle-speed.mjs";
import { registerHealthV2, migrateHealthV2 } from "./module/health-v2.mjs";
import { registerBattleAI } from "./module/battle/ai-driver.mjs";
import { registerRevealPick } from "./module/battle/reveal-pick.mjs";
import { registerFireFx, drawFires } from "./module/battle/fire-fx.mjs";
import { HotkeyGuide } from "./module/hotkeys.mjs";
import { registerSounds, registerSoundPack, onBattleSetting, primeBattleSounds, primeTokenPositions, onUnitTokenMoved, SoundPanel, playMoment } from "./module/sound.mjs";
import { registerNameLabels, toggleNameLabels } from "./module/battle/name-labels.mjs";
import { registerEquipment } from "./module/equipment.mjs";
import { registerTurnBanner, renderTurnBanner } from "./module/battle/turn-banner.mjs";
import { registerObjectives, refreshObjectives, setObjectivesChangeHandler } from "./module/battle/objectives-ui.mjs";
import { NEW_UNIT_TOOL, newUnitDialog, registerNewUnitDrop } from "./module/new-unit.mjs";
import { UNIT_EDITOR_TOOL, UnitEditorApp, registerUnitEditor, reapplyUnitEdits } from "./module/unit-editor.mjs";
import { registerMapRenderer, syncBattleMap, initBattleMapSync, redrawScene, MapEditorApp } from "./module/battle/maprender.mjs";
import { importBattleMap } from "./module/battle/battlemap.mjs";
import { registerUnitInfo, openUnitInfo, openOfficerView, registerDangerZoneKey, toggleDangerZone } from "./module/unit-info.mjs";

const { SYSTEM_ID } = CFG;

/** Expose the chosen text size to the stylesheet as a zoom factor. */
function applyTextScale() {
  let pct = 115;
  try { pct = Number(game.settings.get(SYSTEM_ID, "textScale")) || 115; } catch { /* not registered yet */ }
  document.documentElement.style.setProperty("--qin-scale", String(pct / 100));
}

import { registerCompendiumSync } from "./module/compendium-sync.mjs";
import { partRowHTML, chipHTML, formatValue } from "./module/rules/sources.mjs";
import { registerCombatState } from "./module/combat-state.mjs";
import { registerSkillEffects } from "./module/skill-effects.mjs";
import { CombatPanel, registerCombatPanel } from "./module/combat-panel.mjs";
registerCombatState();
registerSkillEffects();
registerCombatPanel();
import { registerPlacedTag } from "./module/placed-tag.mjs";
import { registerGameYear } from "./module/game-year.mjs";
import { DuelScenesConfig } from "./module/battle/duel-scene.mjs";
import { loadSpecData, specCount } from "./module/battle/skill-data.mjs";
import { loadFullArt } from "./module/full-art.mjs";
registerCompendiumSync();
registerPlacedTag();
Hooks.once("init", () => {
  console.log("Qin | Initializing Qin: The Warring States");
  CONFIG.QIN = CFG;
  CONFIG.qinFactions ??= {};
  globalThis.qin = game.qin = { config: CFG, rules: QinRules, openBattle: () => BattlePanel.open(), battleRequest, registerFactions, factionList, openUnitInfo, openOfficerView, importBattleMap: () => importBattleMap(SYSTEM_ID),
    registerMapRenderer, redrawMap: (scene = canvas.scene) => redrawScene(scene), paintMap: (scene = canvas.scene) => MapEditorApp.open(scene), refreshBattlePanel: () => BattlePanel.refresh(), newUnit: () => newUnitDialog(), unitEditor: () => UnitEditorApp.open(), registerSoundPack, playSound: (m) => playMoment(m, { minGap: 0 }), openSounds: () => SoundPanel.toggle(), openCombatPanel: (actor) => CombatPanel.open(actor) };

  CONFIG.Actor.documentClass = QinActor;
  CONFIG.Item.documentClass = QinItem;
  CONFIG.Combat.documentClass = QinCombat;
  Object.assign(CONFIG.Actor.dataModels, { character: CharacterData, henchman: HenchmanData, unit: UnitData });
  Object.assign(CONFIG.Item.dataModels, {
    weapon: IM.WeaponData, armor: IM.ArmorData, tao: IM.TaoData, technique: IM.TechniqueData, magic: IM.MagicData,
    gift: IM.TraitData, weakness: IM.TraitData, gear: IM.GearData, skill: IM.SkillData, officerAbility: IM.OfficerAbilityData, signature: IM.SignatureData, formation: IM.FormationData,
  });
  CONFIG.Actor.trackableAttributes = {
    character: { bar: [], value: ["chi.value", "bol.damage", "renown"] },
    unit: { bar: ["men"], value: ["morale"] },
    henchman: { bar: [], value: [] },
  };

  const { Actors, Items } = foundry.documents.collections;
  registerGameYear();
  Actors.registerSheet(SYSTEM_ID, CharacterSheet, { types: ["character"], makeDefault: true, label: "Qin character" });
  Actors.registerSheet(SYSTEM_ID, HenchmanSheet, { types: ["henchman"], makeDefault: true, label: "Qin henchman" });
  Actors.registerSheet(SYSTEM_ID, UnitSheet, { types: ["unit"], makeDefault: true, label: "Battlefield unit" });
  Items.registerSheet(SYSTEM_ID, QinItemSheet, { makeDefault: true, label: "Qin item" });

  const { ObjectField, ArrayField } = foundry.data.fields;
  game.settings.register(SYSTEM_ID, "battle", {
    scope: "world", config: false, type: new ObjectField(), default: emptyBattle(),
    onChange: () => {
      BattlePanel.refresh();
      refreshBattleUI();
      redrawAllUnitBars();
      refreshTactics();
      drawDeployZones();
      drawReinforceZones();
      refreshObjectives();
      try { drawFires(); } catch (e) { console.warn("Qin | fire", e); }
      renderTurnBanner();
      try { onBattleSetting(getBattle(), (id) => canvas?.scene?.tokens.get(id)?.actor?.system?.side ?? null); } catch (e) { console.warn("Qin | turn sounds", e); }
      syncBattleMap();
      syncDeployDrawing(getBattle()).catch(e => console.warn("Qin | deployment drawing", e));
      try { panToActiveOfficer(getBattle()); } catch (e) { console.warn("Qin | follow officer", e); }
      if (getBattle().active && !BattlePanel.instance?.rendered && game.settings.get(SYSTEM_ID, "autoOpenBattle")) BattlePanel.open();
    },
  });
  game.settings.register(SYSTEM_ID, "rerollInitiative", {
    name: "Reroll initiative every round (personal combat)", hint: "Qin rerolls Water + Yin/Yang each round.",
    scope: "world", config: true, type: Boolean, default: true,
  });
  registerUnitEditor();
  registerDeployDrawing();
  registerHealthV2();
  registerBattleAI();
  registerRevealPick();
  registerFireFx();
  registerTurnPan();
  registerBattleSpeed();
  game.settings.register(SYSTEM_ID, "compactUnits", { // the Battle panel's "Less info" button, per player
    scope: "client", config: false, type: Boolean, default: false,
  });
  game.settings.register(SYSTEM_ID, "rotateFacing", {
    name: "Rotate unit tokens to show facing", hint: "Battle units turn toward the unit they attacked, or the first unit that attacked them that round (unless they had already attacked), and turn back when the round ends. Leave off if your token art isn't top-down.",
    scope: "world", config: true, type: Boolean, default: false,
  });
  game.settings.register(SYSTEM_ID, "duelScenes", { scope: "world", config: false, type: Object, default: {} });
  game.settings.registerMenu(SYSTEM_ID, "duelScenesMenu", {
    name: "Duel scenes", label: "Choose duel scenes", icon: "fa-solid fa-swords", restricted: true,
    hint: "The person-scale scene a duel moves to, for each kind of ground the challenged officer stands on.",
    type: DuelScenesConfig,
  });
  game.settings.register(SYSTEM_ID, "manageStealth", {
    name: "Hide stealthy enemy units from players", hint: "Enemy units hidden in grass or trees are hidden from players until spotted.",
    scope: "world", config: true, type: Boolean, default: true,
  });
  game.settings.register(SYSTEM_ID, "textScale", {
    name: "Qin text size", hint: "Scales the text on Qin sheets, the battle panel and Qin chat cards. Reopen sheets after changing.",
    scope: "client", config: true, type: Number, default: 115,
    choices: { 100: "Normal (100%)", 115: "Large (115%)", 130: "Larger (130%)", 145: "Largest (145%)" },
    onChange: applyTextScale,
  });
  applyTextScale();
  game.settings.register(SYSTEM_ID, "attackTargeting", {
    name: "Click a hex to attack", hint: "When attacking from a token on the scene, highlight the weapon's reach and click the hex to strike. Right-click or Esc cancels.",
    scope: "client", config: true, type: Boolean, default: true,
  });
  game.settings.register(SYSTEM_ID, "attackAnimations", {
    name: "Attack animations", hint: "Automatic uses JB2A animations when the Sequencer and JB2A modules are active, otherwise the built-in effects.",
    scope: "world", config: true, type: String, default: "auto",
    choices: { auto: "Automatic (JB2A if available)", builtin: "Built-in effects only", off: "Off" },
  });
  game.settings.register(SYSTEM_ID, "showMovementTrail", {
    name: "Show token movement trails", hint: "Foundry draws the path a token has travelled when you hover it. Off: the trail is wiped after every move.",
    scope: "world", config: true, type: Boolean, default: false,
  });
  game.settings.register(SYSTEM_ID, "autoOpenBattle", {
    name: "Open the battle panel automatically", scope: "client", config: true, type: Boolean, default: false,
  });

  Handlebars.registerHelper("add", (a, b) => Number(a) + Number(b));
  // Option values are strings ("0".."6"), but our data is numbers: compare as strings so the
  // stored level (e.g. 1 = Apprentice) is the one shown as selected.
  const coreSelectOptions = Handlebars.helpers.selectOptions;
  if (coreSelectOptions && !coreSelectOptions.qinWrapped) {
    const wrapped = function (choices, options) {
      const sel = options?.hash?.selected;
      if (typeof sel === "number" || typeof sel === "boolean") options.hash.selected = String(sel);
      else if (Array.isArray(sel)) options.hash.selected = sel.map(v => (typeof v === "number" ? String(v) : v));
      return coreSelectOptions.call(this, choices, options);
    };
    wrapped.qinWrapped = true;
    Handlebars.registerHelper("selectOptions", wrapped);
  }
  Handlebars.registerHelper("qinObj", (options) => options.hash);
  if (!Handlebars.helpers.eq) Handlebars.registerHelper("eq", (a, b) => a === b);
  if (!Handlebars.helpers.or) Handlebars.registerHelper("or", (...args) => args.slice(0, -1).some(Boolean));
  // Source-tagged roll parts (David, 2026-11-05)
  Handlebars.registerHelper("qinPart", (p) => new Handlebars.SafeString(partRowHTML(Array.isArray(p) ? { kind: "modifier", label: p[0], value: p[1] } : p)));
  Handlebars.registerHelper("qinChip", (p) => new Handlebars.SafeString(chipHTML(p)));
  Handlebars.registerHelper("signed", (v) => formatValue(v, "unique"));
  if (!Handlebars.helpers.inc) Handlebars.registerHelper("inc", (n) => Number(n) + 1);

  // Combat turn hotkeys (change them in Configure Controls)
  const turnKey = (dir) => () => {
    const combat = game.combat;
    if (!combat?.started) return false;
    if (!game.user.isGM && !combat.combatant?.isOwner) { ui.notifications.warn("It isn't your turn."); return true; }
    if (dir > 0) combat.nextTurn();
    else if (game.user.isGM) combat.previousTurn();
    return true;
  };
  game.keybindings.register(SYSTEM_ID, "nextTurn", {
    name: "Next turn (combat)", hint: "End the current turn. Players can use it on their own turn.",
    editable: [{ key: "PageDown" }], onDown: turnKey(1), precedence: CONST.KEYBINDING_PRECEDENCE?.NORMAL,
  });
  game.keybindings.register(SYSTEM_ID, "previousTurn", {
    name: "Previous turn (combat)", hint: "Step back one turn (GM only).",
    editable: [{ key: "PageUp" }], onDown: turnKey(-1), restricted: true, precedence: CONST.KEYBINDING_PRECEDENCE?.NORMAL,
  });
  game.keybindings.register(SYSTEM_ID, "battlePanel", {
    name: "Open battle panel", hint: "Opens the Battle window; press again to close it.",
    editable: [{ key: "KeyB" }], precedence: CONST.KEYBINDING_PRECEDENCE?.NORMAL,
    onDown: () => { if (BattlePanel.instance?.rendered) BattlePanel.instance.close(); else BattlePanel.open(); return true; },
  });
  game.keybindings.register(SYSTEM_ID, "partyPanel", {
    name: "Open party panel", hint: "Every player's units with health, morale and XP; press again to close it.",
    editable: [{ key: "KeyP" }], precedence: CONST.KEYBINDING_PRECEDENCE?.NORMAL,
    onDown: () => { PartyPanel.toggle(); return true; },
  });
  registerParty();
  registerOfficerCodex();
  registerOfficerLimit();
  game.keybindings.register(SYSTEM_ID, "tileTip", {
    name: "Tile info", hint: "Show a small tooltip by the cursor describing the square under it (terrain, buildings and their effects). Press again to turn it off.",
    editable: [{ key: "KeyV" }], precedence: CONST.KEYBINDING_PRECEDENCE?.NORMAL,
    onDown: () => { toggleTileTip(); return true; },
  });
  registerTileTip();
  registerSounds();
  game.keybindings.register(SYSTEM_ID, "nameLabels", {
    name: "Unit names", hint: "Show every unit's name (and its officer) under its stand. Press again to hide them.",
    editable: [{ key: "KeyL" }], precedence: CONST.KEYBINDING_PRECEDENCE?.NORMAL,
    onDown: () => { if (!canvas?.ready) return false; toggleNameLabels(); return true; },
  });
  registerNameLabels();
  game.keybindings.register(SYSTEM_ID, "hotkeys", {
    name: "Hotkey guide", hint: "Opens a window listing these shortcuts; press again to close it.",
    editable: [{ key: "KeyH" }], precedence: CONST.KEYBINDING_PRECEDENCE?.NORMAL,
    onDown: () => { HotkeyGuide.toggle(); return true; },
  });
  game.keybindings.register(SYSTEM_ID, "newUnit", {
    name: "New unit (GM)", hint: "Opens the New unit window (or brings it to the front).",
    editable: [{ key: "KeyN" }], restricted: true, precedence: CONST.KEYBINDING_PRECEDENCE?.NORMAL,
    onDown: () => { newUnitDialog(); return true; },
  });

  registerBattleQuery();
  registerDeployDrop();
  registerNewUnitDrop();
  registerRecruitQuery();
  registerCombatQuery();
});

Hooks.once("ready", () => {
  // officers' battlefield skills: the private specs in Data/qin-data (none = skills stay GM-applied, as before)
  loadFullArt().then(n => { console.log("Qin | full character art: " + n); Object.values(ui.windows ?? {}).forEach(w => w.document?.documentName === "Actor" && w.render?.()); }).catch(() => {});
  loadSpecData().then(ok => console.log("Qin | battlefield skill specs: " + (ok ? specCount() + " loaded" : "none found"))).catch(() => {});
  syncDeployDrawing(getBattle()).catch(e => console.warn("Qin | deployment drawing", e)); // catch up if deployment started or ended while no GM was on
  reapplyUnitEdits();
  removeFormationItems();
  migrateHealthV2().catch(e => console.warn("Qin | health v2", e));
  registerAttackFxSocket();
  initBattleMapSync();
  refreshTactics();
  // the Battle panel no longer opens by itself when the world loads, GM included (David 2026-11-01); the setting can turn it back on
  if (getBattle().active && game.settings.get(SYSTEM_ID, "autoOpenBattle")) BattlePanel.open();
});

/**
 * Formations were removed from the game (David, 2026-10-29). The item type stays registered so old worlds load
 * cleanly; on the GM's client any formation items left on units or in the world are deleted once.
 */
async function removeFormationItems() {
  if (!game.user.isGM) return;
  try {
    for (const a of game.actors ?? []) {
      const ids = a.items.filter(i => i.type === "formation").map(i => i.id);
      if (ids.length) await a.deleteEmbeddedDocuments("Item", ids);
    }
    const world = (game.items ?? []).filter(i => i.type === "formation").map(i => i.id);
    if (world.length) await Item.deleteDocuments(world);
  } catch (e) { console.warn("Qin | removing formation items", e); }
}
// ...and no new ones can be made
Hooks.on("preCreateItem", (item) => { if (item.type === "formation") { ui.notifications.warn("Formations aren't part of the game any more."); return false; } });

Hooks.on("renderChatMessageHTML", onRenderChatMessage);
registerTokenHover();
registerDamageFloats();
registerUnitBars();
registerUnitInfo();
registerTactics();
registerDeployZones();
registerPreBattleCover();
registerReinforcements();
registerEquipment();
setReinforceChangeHandler(() => BattlePanel.refresh());
registerTurnBanner();
registerObjectives();
setObjectivesChangeHandler(() => BattlePanel.refresh());
setDeployChangeHandler(() => BattlePanel.refresh());
registerUnitClicks();
Hooks.on("renderCombatTracker", onRenderCombatTracker);
// Recharging unique skills: character sheets update as the fight's rounds pass, and clear when it ends
const rerenderCharacterSheets = () => { for (const a of game.actors ?? []) if (a.type === "character" && a.sheet?.rendered) a.sheet.render(); };
Hooks.on("updateCombat", (c, change) => { if ("round" in change || "started" in change) rerenderCharacterSheets(); });
Hooks.on("deleteCombat", rerenderCharacterSheets);
Hooks.on("updateToken", (doc, change) => { try { onUnitTokenMoved(doc, change, getBattle()); } catch (e) { console.warn("Qin | move sound", e); } });
Hooks.on("updateToken", (doc, change, options) => {
  onTokenMoved(doc, change, options);
  // Wipe the hover movement trail after each move unless the GM wants it
  if (("x" in change || "y" in change) && game.user.isActiveGM && !game.settings.get(SYSTEM_ID, "showMovementTrail") && doc.movementHistory?.length) {
    setTimeout(() => doc.clearMovementHistory?.().catch?.(() => {}), 0);
  }
});
Hooks.on("updateActor", () => { BattlePanel.refresh(); refreshBattleUI(); });
Hooks.on("canvasReady", () => { refreshBattleUI(); try { primeTokenPositions(canvas.scene); primeBattleSounds(getBattle(), (id) => canvas?.scene?.tokens.get(id)?.actor?.system?.side ?? null); } catch { /* fine */ } });
Hooks.on("canvasPan", () => repositionBattleUI());
// Foundry 13+ moves tokens through its movement API: refuse a move there (preMoveToken). Older versions: preUpdateToken.
Hooks.once("init", () => {
  if ((game.release?.generation ?? 12) >= 13) Hooks.on("preMoveToken", lockUnitMoves);
  else Hooks.on("preUpdateToken", lockUnitTokens);
});
Hooks.on("controlToken", onUnitSelected);

Hooks.on("getSceneControlButtons", (controls) => {
  const tool = {
    name: "qinBattle", title: "Battle panel", icon: "fa-solid fa-chess-rook", order: 99,
    button: true, visible: true, onChange: () => BattlePanel.open(),
  };
  const codexTool = { name: "qinOfficers", title: "Officers", icon: "fa-solid fa-book-open", order: 100, button: true, visible: true, onChange: () => OfficerCodex.toggle() };
  const unitTool = { ...NEW_UNIT_TOOL, visible: !!game.user?.isGM }, editTool = { ...UNIT_EDITOR_TOOL, visible: !!game.user?.isGM };
  if (Array.isArray(controls)) controls.find(c => c.name === "token")?.tools.push({ ...tool, onClick: tool.onChange }, { ...codexTool, onClick: codexTool.onChange }, { ...unitTool, onClick: unitTool.onChange }, { ...editTool, onClick: editTool.onChange });
  else if (controls.tokens?.tools) { controls.tokens.tools.qinBattle = tool; controls.tokens.tools.qinOfficers = codexTool; controls.tokens.tools.qinNewUnit = unitTool; controls.tokens.tools.qinUnitEditor = editTool; }
});

/* ---------- Macro bar: drag a weapon (or Tao, technique...) onto the hotbar to get a click-to-use button */
async function rollItemMacro(name, uuid) {
  // Use the selected token's copy of the item if it has one (handy for henchman groups), else the original
  const tok = canvas?.tokens?.controlled?.find(t => t.actor?.items?.getName?.(name));
  let item = tok?.actor.items.getName(name);
  if (!item && uuid) item = await fromUuid(uuid);
  if (!item) return ui.notifications.warn(`No "${name}" on the selected token.`);
  if (!item.isOwner) return ui.notifications.warn(`You don't own ${item.parent?.name ?? "that character"}.`);
  return item.use();
}
/** Aspect or skill Test from the macro bar: the selected token's character, else the one it was dragged from. */
async function rollTestMacro({ actorUuid, aspect, skill, skillItem }) {
  const tok = canvas?.tokens?.controlled?.find(t => t.actor && t.actor.type !== "unit" && t.actor.isOwner);
  const actor = tok?.actor ?? (actorUuid ? await fromUuid(actorUuid) : null);
  if (!actor) return ui.notifications.warn("Select a token first.");
  if (!actor.isOwner) return ui.notifications.warn(`You don't own ${actor.name}.`);
  if (aspect) return actor.rollTest({ aspect });
  let key = skill, domain = CFG.SKILLS[skill]?.domain;
  if (!key && skillItem) {
    const it = actor.items.find(i => i.type === "skill" && i.name === skillItem);
    if (!it) return ui.notifications.warn(`${actor.name} has no "${skillItem}" skill.`);
    key = it.id; domain = it.system.domain;
  }
  domain ??= "metal";
  return actor.rollTest({ aspect: domain, skill: key, physical: domain === "water" });
}
Hooks.once("init", () => { registerDangerZoneKey(SYSTEM_ID); registerFacingKey(SYSTEM_ID); game.qin.toggleDangerZone = toggleDangerZone; game.qin.rollItemMacro = rollItemMacro; game.qin.rollTestMacro = rollTestMacro; });
Hooks.on("hotbarDrop", (bar, data, slot) => {
  if (data?.type !== "QinRoll") return;
  (async () => {
    const actor = data.actorUuid ? fromUuidSync(data.actorUuid) : null;
    const label = data.aspect ? `${CFG.ASPECTS[data.aspect]?.label ?? data.aspect} Test`
      : data.skill ? (CFG.SKILLS[data.skill]?.label ?? data.skill) : data.skillItem;
    const payload = { actorUuid: data.actorUuid, aspect: data.aspect, skill: data.skill, skillItem: data.skillItem };
    const command = `game.qin.rollTestMacro(${JSON.stringify(payload)});`;
    let macro = game.macros.find(m => m.command === command && m.isOwner);
    macro ??= await CONFIG.Macro.documentClass.create({
      name: label, type: "script", img: data.aspect ? "icons/svg/d10-grey.svg" : "icons/svg/book.svg", command, flags: { qin: { rollMacro: true, actor: actor?.name } },
    });
    await game.user.assignHotbarMacro(macro, slot);
  })();
  return false;
});
Hooks.on("hotbarDrop", (bar, data, slot) => {
  if (data?.type !== "Item" || !data.uuid) return;
  const item = fromUuidSync(data.uuid);
  if (!item?.parent || !["weapon", "tao", "technique", "magic", "signature", "gear", "gift", "weakness"].includes(item.type)) return;
  (async () => {
    const command = `game.qin.rollItemMacro(${JSON.stringify(item.name)}, ${JSON.stringify(item.uuid)});`;
    const MacroCls = CONFIG.Macro.documentClass;
    let macro = game.macros.find(m => m.command === command && m.isOwner);
    macro ??= await MacroCls.create({
      name: item.type === "weapon" ? `${item.name} attack` : item.name, type: "script", img: item.img, command,
      flags: { qin: { itemMacro: true } },
    });
    await game.user.assignHotbarMacro(macro, slot);
  })();
  return false;
});

// Renaming an actor renames its tokens too (prototype + placed tokens that still had the old name)
Hooks.on("preUpdateActor", (actor, change, options) => {
  if (!("name" in change) || change.name === actor.name) return;
  options.qinOldName = actor.name;
  if (!actor.isToken && (actor.prototypeToken?.name === actor.name || !actor.prototypeToken?.name)) {
    foundry.utils.setProperty(change, "prototypeToken.name", change.name);
  }
});
Hooks.on("updateActor", async (actor, change, options, userId) => {
  const oldName = options.qinOldName;
  if (!oldName || userId !== game.user.id || !("name" in change)) return;
  const name = actor.name;
  if (actor.isToken) {
    if (actor.token?.name === oldName) await actor.token.update({ name });
    return;
  }
  for (const scene of game.scenes) {
    const updates = scene.tokens.filter(t => t.actorLink && t.actorId === actor.id && t.name === oldName && t.canUserModify(game.user, "update"))
      .map(t => ({ _id: t.id, name }));
    if (updates.length) await scene.updateEmbeddedDocuments("Token", updates);
  }
});

/* Unit tokens: only Player units are linked to their actor sheet (health and morale carry between battles).
 * Ally, Enemy and Neutral units are always placed as independent copies, even the first one. A second token
 * of the same Player unit on a scene is also a copy, so two tokens never share one health pool. */
const pendingLinked = new Set();
Hooks.on("preCreateToken", (doc, data) => {
  const actor = doc.actor ?? game.actors.get(data.actorId);
  if (actor?.type !== "unit") return;
  if (actor.system.side !== "player") { if (doc.actorLink) doc.updateSource({ actorLink: false }); return; }
  const scene = doc.parent, key = `${scene?.id}.${actor.id}`;
  const taken = pendingLinked.has(key) || scene?.tokens.some(t => t.actorLink && t.actorId === actor.id);
  if (taken) { if (doc.actorLink) doc.updateSource({ actorLink: false }); return; }
  if (!doc.actorLink) doc.updateSource({ actorLink: true });
  pendingLinked.add(key); setTimeout(() => pendingLinked.delete(key), 0);
});

// Changing a unit's side updates what its future tokens do
Hooks.on("preUpdateActor", (actor, change) => {
  const side = foundry.utils.getProperty(change, "system.side");
  if (actor.type !== "unit" || side === undefined || actor.isToken) return;
  foundry.utils.setProperty(change, "prototypeToken.actorLink", side === "player");
});

/** Existing scenes: unlink non-Player unit tokens and extra copies of a Player unit. */
async function unlinkSharedUnits(scene) {
  if (!scene || !game.user.isActiveGM) return;
  const seen = new Set(), updates = [];
  for (const t of scene.tokens) {
    if (!t.actorLink || t.actor?.type !== "unit") continue;
    if (t.actor.system.side !== "player" || seen.has(t.actorId)) updates.push({ _id: t.id, actorLink: false });
    else seen.add(t.actorId);
  }
  if (!updates.length) return;
  await scene.updateEmbeddedDocuments("Token", updates);
  ui.notifications.info(`${updates.length} unit token${updates.length === 1 ? "" : "s"} on "${scene.name}" now track their own health and morale.`);
}
Hooks.on("canvasReady", (c) => { unlinkSharedUnits(c.scene).catch(e => console.warn("Qin | unlinking unit tokens", e)); });

// New characters start with sensible tokens
Hooks.on("preCreateActor", (actor, data) => {
  if (data.prototypeToken) return;
  const proto = { actorLink: actor.type === "character", displayName: 20, displayBars: 20 };
  // Units: our own always-on health/morale bars replace Foundry's; player units keep their health between battles
  if (actor.type === "unit") Object.assign(proto, { bar1: { attribute: null }, displayBars: 0, actorLink: (data.system?.side ?? "player") === "player" });
  actor.updateSource({ prototypeToken: proto });
});
