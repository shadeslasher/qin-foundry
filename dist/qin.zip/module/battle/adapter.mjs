import { Chat } from "../dice.mjs";
import { broadcastBattleAnim, broadcastFreeze, broadcastAnimHold } from "../attack-fx.mjs";
import { logSoundSteps } from "../sound.mjs";
import { touchedBy } from "./touched.mjs";
// Bridges Foundry (scene tokens, unit actors, officer characters) and the pure battle
// engine. Runs only on the active GM's client; players reach it through queries.
import * as E from "./engine.mjs";
import { traitTiersOf, shieldArmorOf } from "./traits.mjs";
import { REINFORCE_FLAG, REINFORCE_TOKEN_FLAG, zonesOf as reinforceZonesOf, isWaiting as isWaitingReinforcement } from "./reinforce-rules.mjs";
import { equipmentByName } from "./equipment-data.mjs";
import { allStocks, settleSiegeLosses } from "../siege-stock.mjs";
import { officerEligibility } from "../officer-rules.mjs";
export { traitTiersOf, shieldArmorOf };
import { HEROIC_ACTIONS } from "./engine-data.mjs";
import { SYSTEM_ID } from "../config.mjs";
import { specForItem } from "./skill-data.mjs";
import { decodeTiles, gatesFromMap, FLAG as MAP_FLAG } from "./battlemap.mjs";
import { DEPLOY_FLAG } from "./deploy-rules.mjs";
import { OBJECTIVES_FLAG, emptyObjectives, freshObjState } from "./objectives.mjs";
import * as Q from "../rules/qin-rules.mjs";

const SETTING = "battle";
let writing = false;
/** True while the battle itself is moving tokens (so the token lock lets those moves through). */
export const isWritingBack = () => writing;
const BIG = 100000;
let queue = Promise.resolve();


export function emptyBattle() {
  return { active: false, sceneId: null, turn: E.newState().turn, log: [], meta: {}, tactics: null, siege: null };
}

export function getBattle() {
  return foundry.utils.deepClone(game.settings.get(SYSTEM_ID, SETTING) ?? emptyBattle());
}

/* ------------------------------------------------------------ build engine state */

function stripHtml(html) {
  const d = document.createElement("div");
  d.innerHTML = html || "";
  return d.textContent.trim();
}

function ownerUserId(actor) {
  const user = game.users.find(u => !u.isGM && actor.testUserPermission(u, "OWNER"));
  return user?.id ?? null;
}

/**
 * What battlefield skills may compare about an officer (David, 2026-11-05): military rank (the rtk13-map module's
 * rank flag or his sheet's titles; 1 without either), his faction and whether he leads it (rtk13-map), his family
 * name (the first word of his name), and his aspects. Without the map module, rank 1 and no faction.
 */
function officerStanding(officer) {
  const api = game.modules?.get?.("rtk13-map")?.active ? game.modules.get("rtk13-map").api : null;
  let rank = 1, faction = null, ruler = false;
  try {
    const flag = officer.getFlag?.("rtk13-map", "rank");
    const sheet = api?.fromSheet?.(officer);
    rank = Number(flag ?? sheet?.rank ?? 1) || 1;
    faction = api?.actorFaction?.(officer) ?? null;
    ruler = !!sheet?.ruler;
  } catch { /* no map module */ }
  // fighting in his own district? from the world map: where the party is vs. where he is posted (David, 2026-11-09)
  let homeDistrict = false;
  try { homeDistrict = !!api?.inHomeDistrict?.(officer)?.home; } catch { /* no map module */ }
  const family = String(officer.name ?? "").replace(/\s*\(.*\)\s*$/, "").trim().split(/\s+/)[0] || "";
  return { rank, faction, ruler, family, homeDistrict, aspects: { ...(officer.system.aspects ?? {}) } };
}

/** The automated battlefield passive / active of an officer, when a spec exists for his items (skill-data.mjs). */
function battleSpecs(pItem, aItem) {
  const passive = specForItem(pItem), active = specForItem(aItem);
  if (!passive && !active) return null;
  return { passive, active, passiveName: pItem?.name ?? "", activeName: aItem?.name ?? "" };
}

function officerLibraryEntry(officer) {
  const skills = {};
  for (const [k, v] of Object.entries(officer.system.skills ?? {})) skills[k] = v.value;
  // Signature Battle Passive / Battle Active slots count as a passive and a battle skill.
  const sig = (slot) => officer.items.find(i => i.type === "signature" && i.system.slot === slot);
  const asTactic = (item, kind) => item && { name: item.name, system: { ...item.system, kind } };
  const abilities = [
    asTactic(sig("battlePassive"), "passive"), asTactic(sig("battleActive"), "skill"),
  ].filter(Boolean);
  const effects = {};
  for (const a of abilities.filter(a => a.system.kind === "passive")) {
    for (const [k, v] of Object.entries(a.system.effects)) {
      if (typeof v === "boolean") effects[k] = effects[k] || v;
      else if (v) effects[k] = (effects[k] || 0) + v;
    }
  }
  const skill = abilities.find(a => a.system.kind === "skill");
  const battle = battleSpecs(sig("battlePassive"), sig("battleActive"));
  if (battle?.passive) for (const k of Object.keys(effects)) delete effects[k]; // the automated passive replaces the old effect flags (no double bonus)
  return {
    id: officer.uuid, name: officer.name,
    ctype: String(officer.system.details?.characterType ?? ""), style: String(officer.system.details?.battleStyle ?? ""), // how the battle AI plays him
    fire: officer.system.aspects.fire, command: officer.system.skills.command?.value ?? 0, skills,
    passive: { name: abilities.filter(a => a.system.kind === "passive").map(a => a.name).join(", "), text: abilities.filter(a => a.system.kind === "passive").map(a => stripHtml(a.system.description)).filter(Boolean).join(" "), effects },
    skill: skill ? { name: skill.name, text: stripHtml(skill.system.description), moraleCost: battle?.active?.moraleCost ?? skill.system.moraleCost, // a spec may set the cost (David, 2026-11-09)
      recharge: skill.system.recharge ?? 0, perBattle: !!skill.system.perScene || !!battle?.active?.oncePerBattle, lastStand: !!skill.system.lastStand || !!battle?.active?.lastStand } : null, // a spec may make it a last stand (David, 2026-11-09)
    heroicActions: HEROIC_ACTIONS.map(h => ({ name: h.name, text: h.text })), // every officer may use the heroic action list
    tier: parseInt(String(officer.system.details?.tier ?? "").match(/\d+/)?.[0] ?? "0", 10) || 0,
    tierHigh: /high/i.test(String(officer.system.details?.tier ?? "")), // Tier 2 High: its own look for self-buff borders
    ...officerStanding(officer), // rank, faction, ruler, family, aspects: for battlefield skills that compare officers
    battle, // officers' battlefield skills, automated (skills.mjs)
  };
}

/**
 * Traits from a unit's Traits tab, as { "base name": tier } (1 = base, 2 = "+", 3 = "++").
 * Each line reads "Name - effect"; only the name matters here.
 */
function terrainAt(scene, x, y) {
  for (const region of scene.regions ?? []) {
    const name = (region.name || "").toLowerCase();
    const kind = /impassable|cliff|wall|river/.test(name) ? "impassable" : /tree|forest|wood/.test(name) ? "trees" : /grass/.test(name) ? "grass" : null;
    if (!kind) continue;
    try {
      if (region.testPoint({ x, y, elevation: 0 })) return kind;
    } catch { /* region API unavailable: ignore terrain */ }
  }
  return "flat";
}

/** High ground for tactics like Raise Flag: a region named hill, high ground, fort, command tent or wall. */
const HIGH_GROUND = ["hill", "city-wall", "fortress-tower", "fort", "small-fort", "command-tent"];
function isHighGround(scene, gx, gy) {
  // scenes from the map generator: the square's own overlays (hill, city wall or tower, fort, command tent)
  const bm = scene.getFlag?.(SYSTEM_ID, MAP_FLAG);
  if (bm?.terrain) {
    if (gx < 0 || gy < 0 || gx >= bm.cols || gy >= bm.rows) return false;
    if ((bm.overlays?.[gy * bm.cols + gx] ?? []).some(o => HIGH_GROUND.includes(o))) return true;
  }
  // other scenes: Regions named for it
  const size = scene.grid.size, pt = { x: gx * size + size / 2, y: gy * size + size / 2, elevation: 0 };
  return (scene.regions ?? []).some(r => /hill|high ground|fort|command tent|wall/i.test(r.name || "") && (() => { try { return r.testPoint(pt); } catch { return false; } })());
}

export function unitTokens(scene) {
  return scene ? scene.tokens.filter(t => t.actor?.type === "unit") : [];
}

/** Siege equipment a unit starts a battle with, from its traits (one or the other, ladders first). */
export function startingCarry(traits) {
  const t = traitTiersOf(traits);
  return t["siege ladders"] || t["siege ladder"] ? "ladders" : t["siege engine"] ? "engine" : null;
}

const tileCache = new Map(); // sceneId -> { flag, tiles } (decoded battle map squares)

const warned = new Set();
function warnOnce(msg) { if (warned.has(msg) || !game.user?.isGM) return; warned.add(msg); ui.notifications?.warn(msg); }

/** Engine state assembled from the battle setting and the scene's unit tokens. */
export function buildState(battle, { useLastPosition = null, terrainFor = null } = {}) {
  const scene = game.scenes.get(battle.sceneId);
  const s = E.newState();
  s.freeMovement = true;
  s.turn = battle.turn;
  s.log = battle.log ?? [];
  s.tactics = battle.tactics ?? null;
  s.siege = battle.siege ?? null;
  s.skillsBegun = !!battle.skillsBegun; // officers' battlefield skills: battle-start effects done
  s.skillInterjects = battle.skillInterjects ?? []; s.skillExtra = battle.skillExtra ?? []; s.skillNow = battle.skillNow ?? []; // short extra turns skills hand out
  s.skillOrder = battle.skillOrder ?? []; s.skillCancelTactic = battle.skillCancelTactic ?? []; s.skFallen = battle.skFallen ?? {};
  s.tileOverrides = battle.tileOverrides ?? {};
  s.siegeDeploy = !!battle.siegeDeploy; s.siegeIssued = battle.siegeIssued ?? null; // siege equipment hand-outs (David, 2026-11-13)
  try { s.siegeStock = allStocks(); } catch { s.siegeStock = null; }
  s.revealPicks = battle.revealPicks ?? []; // battle-start reveals waiting for the GM (or the AI) to pick a hidden enemy
  s.deployZones = scene?.getFlag?.(SYSTEM_ID, DEPLOY_FLAG) ?? []; // deployment squares, saved with the scene
  s.objectives = foundry.utils.deepClone(scene?.getFlag?.(SYSTEM_ID, OBJECTIVES_FLAG) ?? emptyObjectives()); // victory / defeat conditions
  s.objState = battle.objState ?? freshObjState();
  s.aiSeen = battle.aiSeen ?? null; // where each side last saw the other's units (the AI remembers hidden ones)
  s.objEval = battle.objEval ?? null;
  s.outcome = battle.outcome ?? null;
  s.introAt = battle.introAt ?? null;
  s.duels = foundry.utils.deepClone(battle.duels ?? { pending: null, refused: [] });
  s.library.unitTypes = [];
  s.library.officers = [];
  s.map = { image: null, cols: BIG, rows: BIG, tile: 1, offsetX: 0, offsetY: 0, terrain: {} };
  s.players = { host: { name: "GM", color: "#d9a441" } };
  for (const u of game.users) if (!u.isGM) s.players[u.id] = { name: u.name, color: u.color?.css ?? String(u.color) };
  if (!scene) return { s, scene: null };
  const size = scene.grid.size;
  // A scene imported from a battle map knows every square's terrain; others fall back to named regions
  const bm = scene.getFlag?.(SYSTEM_ID, MAP_FLAG) ?? scene.flags?.[SYSTEM_ID]?.[MAP_FLAG];
  const tiles = bm ? (tileCache.get(scene.id)?.flag === bm ? tileCache.get(scene.id).tiles : decodeTiles(bm)) : null;
  if (tiles) { tileCache.set(scene.id, { flag: bm, tiles }); s.map.tiles = tiles; s.map.cols = bm.cols; s.map.rows = bm.rows; }
  // squares a battlefield skill changed (a ford dug, a palisade raised...): laid over the map, without touching the cached one
  if (tiles && battle.tileOverrides && Object.keys(battle.tileOverrides).length) { s.map.tiles = { ...tiles }; for (const [k, o] of Object.entries(battle.tileOverrides)) if (o?.tile) s.map.tiles[k] = o.tile; }
  // city gates live with the battle (owners, locked/open/broken/burned); a new battle starts from the map
  if (tiles && !(s.siege?.gates?.length)) {
    const gates = gatesFromMap(bm);
    if (gates.length) s.siege = { ladders: [], dropped: [], ...(s.siege ?? {}), gates };
  }
  const officers = new Map();
  const rzones = reinforceZonesOf(scene.getFlag?.(SYSTEM_ID, REINFORCE_FLAG));
  for (const tok of unitTokens(scene)) {
    const rzId = tok.getFlag?.(SYSTEM_ID, REINFORCE_TOKEN_FLAG);
    if (isWaitingReinforcement(rzId, rzones)) { // reinforcements not yet arrived: not in the battle
      // ...but their own side knows they are coming, and when (the battle AI plays for time until then)
      const z = rzones.find(z => z.id === rzId);
      (s.incoming ??= []).push({ side: tok.actor?.system?.side, round: z?.round ?? null, tier: Number(tok.actor?.system?.tier) || 1, shown: !!z?.shown,
        x: Math.round(tok.x / size), y: Math.round(tok.y / size) });
      continue;
    }
    const a = tok.actor, sys = a.system;
    const gx = Math.round(tok.x / size), gy = Math.round(tok.y / size);
    const ranged = sys.range > 1;
    s.library.unitTypes.push({
      id: tok.id, name: a.name, faction: sys.faction, tier: sys.tier, category: sys.category, weapon: ranged ? "ranged" : "melee",
      skill: sys.weaponSkill, skill2: sys.weaponSkill2 || "", unitValue: sys.unitValue, damage: sys.damage, armor: sys.armor, armorPen: sys.armorPen, move: sys.move,
      shield: /shield/i.test(String(sys.unitType ?? "")), // carries a shield (its weapon includes one): Shield Breaker gives Attack against it (EX ignores all its armor)
      rangeMin: ranged ? Math.min(sys.rangeMin || 1, sys.range) : 1, rangeMax: ranged ? sys.range : 1,
    });
    let officerId = null;
    let officer = sys.officerActor;
    const elig = officer ? officerEligibility(officer, sys) : null;
    if (officer && !elig.ok) { warnOnce(`${a.name}: ${officer.name} can't lead it (${elig.reason}), so it fights without an officer.`); officer = null; }
    if (officer?.system?.bol?.dead) officer = null; // slain (in a duel or otherwise): the unit fights on without him
    if (officer) {
      if (!officers.has(officer.uuid)) officers.set(officer.uuid, officerLibraryEntry(officer));
      officerId = officer.uuid;
    }
    const meta = battle.meta?.[tok.id] ?? {};
    const fierce = String(sys.traits ?? "").match(/^\s*Fierce Charge(\+{0,2})\s*(?:-|–|:|$)/mi);
    // During rounds the battle's own record of positions is the truth (tokens may still be animating);
    // a token that was just dragged is already at its new tile, so the engine needs where it came from.
    const fromPos = (useLastPosition === tok.id || battle.turn?.phase !== "setup") && meta.pos ? meta.pos : null;
    s.units.push({
      id: tok.id, typeId: tok.id, officerId, name: tok.name, side: sys.side, owner: ownerUserId(a),
      x: fromPos ? fromPos.x : gx, y: fromPos ? fromPos.y : gy, men: sys.men.value, maxMen: sys.men.max, morale: sys.morale, xp: sys.xp?.value ?? 0, level: sys.level ?? 1,
      facing: meta.facing ?? null, hidden: sys.hidden, status: sys.status,
      fierceCharge: fierce ? 1 + fierce[1].length : (traitTiersOf(sys.traits)['fierce charge'] || 0), // Fierce Charge EX = 4 (David, 2026-10-31)
      traitTiers: traitTiersOf(sys.traits), fx: tok.getFlag?.(SYSTEM_ID, "arrived") ? { ...(meta.fx ?? {}), reinforced: true } : (meta.fx ?? {}), // arrived as a reinforcement (battlefield skills)
      // players' units get siege equipment handed out at deployment (their stock); others carry what their sheet says
      carry: meta.carry !== undefined ? meta.carry : ownerUserId(a) ? null : startingCarry(sys.traits),
      mods: meta.mods ?? [], overwatch: !!meta.overwatch, heroicUsed: meta.heroicUsed ?? 0, lastHeroic: meta.lastHeroic ?? null,
      surrounded: meta.surrounded ?? false, round: meta.round ?? { activated: false, moved: false, cannotMove: false, holding: false, attacked: false, skillUsed: false, heroicUsed: false, meleeTarget: null, meleeAttacker: null },
    });
    // Terrain for this tile and its neighbours (stealth cover, encirclement)
    if (!s.map.tiles) for (const [dx, dy] of [[0, 0], [1, 0], [-1, 0], [0, 1], [0, -1]]) {
      const k = (gx + dx) + "," + (gy + dy);
      if (k in s.map.terrain) continue;
      const t = terrainAt(scene, (gx + dx) * size + size / 2, (gy + dy) * size + size / 2);
      if (t !== "flat") s.map.terrain[k] = t;
    }
  }
  s.library.officers = [...officers.values()];
  // Full terrain around one unit (movement range, so impassable regions block its path)
  const tu = terrainFor && !s.map.tiles && s.units.find(u => u.id === terrainFor);
  if (tu) {
    const r = Math.min(30, (E.movementOf(s, tu) || 0) * 2 + 1);
    for (let x = tu.x - r; x <= tu.x + r; x++) for (let y = tu.y - r; y <= tu.y + r; y++) {
      const k = x + "," + y;
      if (k in s.map.terrain || Math.abs(x - tu.x) + Math.abs(y - tu.y) > r) continue;
      const t = terrainAt(scene, x * size + size / 2, y * size + size / 2);
      if (t !== "flat") s.map.terrain[k] = t;
    }
  }
  return { s, scene };
}

/* ------------------------------------------------------------ write back */

/**
 * What battlefield skills ask of Foundry itself (David, 2026-11-05): a unit coming over to the other side, a unit
 * raised next to an officer, reinforcements called in early (by the side's zones, or next to a unit).
 */
async function skillRequests(s, scene) {
  const size = scene?.grid?.size ?? 100;
  const b2 = getBattle(); let touched = false;
  for (const r of s.skillRequests) {
    if (r.kind === "convert") {
      const tok = scene?.tokens.get(r.unitId); if (!tok) continue;
      await tok.actor.update({ "system.side": r.side, "system.officer": "" }, { qinBattle: true });
    } else if (r.kind === "spawn") {
      const pack = game.packs.get("qin-3k-characters.battle-units");
      const idx = pack ? await pack.getIndex({ fields: ["system.traitList", "system.tier"] }) : null;
      const levy = idx?.contents.filter(e => JSON.stringify(e.system?.traitList ?? "").toLowerCase().includes('"levy"')).sort((a, b) => (a.system?.tier ?? 9) - (b.system?.tier ?? 9))[0]
        ?? idx?.contents.find(e => /levy|militia/i.test(e.name));
      if (!levy) { ui.notifications.warn("No Levy unit in the Battle Units compendium for a battlefield skill to raise."); continue; }
      const d = (await pack.getDocument(levy._id)).toObject(); delete d._id;
      d.system.side = r.side; d.name = d.name + " (raised)";
      const actor = await Actor.create(d);
      const taken = new Set(scene.tokens.map(t => Math.round(t.x / size) + "," + Math.round(t.y / size)));
      let spot = null;
      for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1], [1, 1], [1, -1], [-1, 1], [-1, -1]]) { const x = r.near.x + dx, y = r.near.y + dy; if (x >= 0 && y >= 0 && !taken.has(x + "," + y) && E._passable(s, x, y)) { spot = { x, y }; break; } }
      if (!spot) { ui.notifications.warn("No free square for the raised unit."); continue; }
      const [tok] = await scene.createEmbeddedDocuments("Token", [(await actor.getTokenDocument({ x: spot.x * size, y: spot.y * size })).toObject()], { qinBattle: true });
      b2.meta ??= {}; b2.meta[tok.id] = { pos: spot, round: { ...E.newRoundFlags(), activated: true } }; touched = true; // it acts from next round
    } else if (r.kind === "reinforce") {
      const near = r.near === "self" ? E.unitById(s, r.srcId) : r.near === "hidden" ? (E.liveUnits(s).find(u => u.hidden && E.alliance(u.side) === E.alliance(r.side)) ?? null) : null;
      const ids = await (await import("./reinforce.mjs")).skillArrive(scene, { side: r.side, count: r.count || 1, near: near ? { x: near.x, y: near.y } : null, category: r.filter?.category ?? null });
      if (!ids.length) ChatMessage.create({ content: "<p>No reinforcements are waiting to answer the call.</p>", speaker: { alias: "Battle" } });
      if (r.buff && ids.length) { b2.meta ??= {}; for (const id of ids) { (b2.meta[id] ??= {}).fx ??= {}; (b2.meta[id].fx.buffs ??= []).push({ id: "arr" + id, name: "Arrived", src: r.srcId, until: { kind: "actEnd", acts: 1 }, mods: r.buff.mods ?? [] }); } touched = true; }
    }
  }
  if (touched) await game.settings.set(SYSTEM_ID, SETTING, b2);
}

async function writeBack(battle, s, scene, rides = null, walks = null) {
  const size = scene?.grid.size ?? 100;
  const tokenUpdates = [];
  const actorUpdates = [];
  const manage = game.settings.get(SYSTEM_ID, "manageStealth");
  const rotate = game.settings.get(SYSTEM_ID, "rotateFacing");
  battle.meta = {};
  for (const u of s.units) {
    const tok = scene?.tokens.get(u.id);
    if (!tok) continue;
    battle.meta[u.id] = { pos: { x: u.x, y: u.y }, facing: u.facing, mods: u.mods, overwatch: !!u.overwatch, heroicUsed: u.heroicUsed, lastHeroic: u.lastHeroic, surrounded: u.surrounded, round: u.round, fx: u.fx ?? {}, carry: u.carry ?? null };
    const sys = tok.actor.system;
    const upd = {};
    if (sys.men.value !== u.men) upd["system.men.value"] = u.men;
    if (sys.morale !== u.morale) upd["system.morale"] = u.morale;
    if ((sys.xp?.value ?? 0) !== (u.xp || 0)) upd["system.xp.value"] = u.xp || 0;
    if ((sys.level ?? 1) !== (u.level || 1)) upd["system.level"] = u.level || 1;
    // Health at the start of the battle (post-battle XP loss = casualties suffered)
    battle.startMen ??= {};
    if (battle.startMen[u.id] === undefined) battle.startMen[u.id] = sys.men.value;
    if (sys.status !== u.status) upd["system.status"] = u.status;
    if (sys.hidden !== !!u.hidden) upd["system.hidden"] = !!u.hidden;
    // siege equipment dropped or picked up in battle: the sheet's Equipment follows (ladders / engine entries);
    // players' units don't keep it on the sheet (their stock is counted at the end of the battle)
    const carried = u.carry === "ladders" ? "Siege Ladders" : u.carry === "engine" ? "Siege Engine" : null;
    const list = tok.actor._source?.system?.traitList ?? sys.traitList ?? [];
    const has = list.filter(e => e.equip && (e.name === "Siege Ladders" || e.name === "Siege Engine")).map(e => e.name);
    if (!u.owner && !(has.length === (carried ? 1 : 0) && (!carried || has[0] === carried))) {
      const kept = list.filter(e => !(e.equip && (e.name === "Siege Ladders" || e.name === "Siege Engine")));
      const piece = carried ? equipmentByName(carried) : null;
      upd["system.traitList"] = piece ? [...kept, { name: piece.name, desc: piece.desc, level: 1, upgrades: [], options: [], chosen: -1, equip: true }] : kept;
      if (sys.traits) upd["system.traits"] = "";
    }
    if (Object.keys(upd).length) actorUpdates.push(tok.actor.update(upd, { qinBattle: true }));
    const t = { _id: u.id };
    // Only the engine moving a unit (a swap) needs the token moved; dragged tokens are already there.
    if (Math.round(tok.x / size) !== u.x || Math.round(tok.y / size) !== u.y) { t.x = u.x * size; t.y = u.y * size; }
    if (rotate && !tok.lockRotation) {
      // no facing: the token goes back to how it was drawn
      const rot = u.facing ? ((Math.atan2(u.facing.dy, u.facing.dx) * 180 / Math.PI) - 90 + 360) % 360 : 0;
      if (Math.round(tok.rotation) !== Math.round(rot)) t.rotation = rot;
    }
    if (manage && u.side !== "player") {
      const unseen = u.status === "active" && !E.visibleTo(s, u, "player");
      const flagged = tok.getFlag(SYSTEM_ID, "stealthHidden");
      if (unseen && !tok.hidden) { t.hidden = true; t[`flags.${SYSTEM_ID}.stealthHidden`] = true; }
      else if (!unseen && flagged) { t.hidden = false; t[`flags.${SYSTEM_ID}.stealthHidden`] = false; }
    }
    if (u.status === "escaped" && !tok.hidden) t.hidden = true; // escaped units leave the map
    if (Object.keys(t).length > 1) tokenUpdates.push(t);
  }
  await Promise.all(actorUpdates);
  if (scene && tokenUpdates.length) {
    writing = true;
    // a unit that rode through the enemy (Ride Them Down) jumps to its end square with no slide and no move sound:
    // its ride animation carries it there along the path (every client holds it on the start square until then)
    const ridden = tokenUpdates.filter(t => rides?.[t._id] && ("x" in t || "y" in t));
    const walked = tokenUpdates.filter(t => !ridden.includes(t) && walks?.[t._id] && ("x" in t || "y" in t)); // walk animation carries them (David, 2026-11-18)
    const rest = tokenUpdates.filter(t => !ridden.includes(t) && !walked.includes(t));
    try {
      for (const t of ridden) await scene.updateEmbeddedDocuments("Token", [t], { qinBattle: true, animate: false, qinRide: { from: rides[t._id] } });
      for (const t of walked) await scene.updateEmbeddedDocuments("Token", [t], { qinBattle: true, animate: false, qinWalk: { from: walks[t._id] } });
      if (rest.length) await scene.updateEmbeddedDocuments("Token", rest, { qinBattle: true });
    }
    finally { writing = false; }
  }
  battle.turn = s.turn;
  battle.tactics = s.tactics ?? null;
  battle.siege = s.siege ?? null;
  battle.skillsBegun = !!s.skillsBegun;
  battle.skillInterjects = s.skillInterjects ?? []; battle.skillExtra = s.skillExtra ?? []; battle.skillNow = s.skillNow ?? [];
  battle.skillOrder = s.skillOrder ?? []; battle.skillCancelTactic = s.skillCancelTactic ?? []; battle.skFallen = s.skFallen ?? {};
  battle.tileOverrides = s.tileOverrides ?? {};
  battle.siegeDeploy = !!s.siegeDeploy; battle.siegeIssued = s.siegeIssued ?? null;
  battle.revealPicks = s.revealPicks ?? [];
  battle.objState = s.objState ?? null;
  battle.aiSeen = s.aiSeen ?? null;
  battle.objEval = s.objEval ?? null;
  battle.outcome = s.outcome ?? null;
  battle.introAt = s.introAt ?? null;
  battle.duels = s.duels ?? null;
  battle.log = s.log.slice(-60);
  await game.settings.set(SYSTEM_ID, SETTING, battle);
}

async function postLog(entries, s) {
  if (!entries.length) return;
  const nameOf = (id) => E.unitById(s, id)?.name ?? "?";
  const signed = (n) => (n > 0 ? `+${n}` : `${n}`);
  const attackIds = new Set();
  for (const e of entries) if (e.detail?.type === "attack") { attackIds.add(e.detail.result.attacker); attackIds.add(e.detail.result.defender); }
  const parts = [];
  for (const e of entries) {
    const d = e.detail;
    if (d?.type === "attack") {
      const r = d.result;
      const A = nameOf(r.attacker), D = nameOf(r.defender);
      const tags = [r.ranged ? "Ranged" : "Melee", r.catapult && "Catapult shot (Damage 10, Pen 10, Attack +6, Splash Attack+; no officer Command, weapon skill or unit traits)", r.charge && "Cavalry charge", r.rear && "Rear", r.ambush && "Ambush"].filter(Boolean).join(" · ");
      const win = r.winner === "attacker" ? A : r.winner === "defender" ? D : null;
      const col = (roll) => roll.parts.filter(([k, v]) => v !== 0 || /Yin/.test(k)).map(([k, v]) => `<div class="qin-row"><span>${k}</span><span>${signed(v)}</span></div>`).join("");
      const line = (cls, label, a, b) => (a || b) ? `<div class="qin-bc-line ${cls}"><span>${a || "—"}</span><span class="qin-bc-label">${label}</span><span>${b || "—"}</span></div>` : "";
      const moraleA = (r.loser === r.attacker ? -r.moraleLoss : 0) + ((r.killMoraleBy ?? r.killedBy) === r.attacker ? r.killMorale || 0 : 0);
      const moraleD = (r.loser === r.defender ? -r.moraleLoss : 0) + ((r.killMoraleBy ?? r.killedBy) === r.defender ? r.killMorale || 0 : 0);
      parts.push(`<div class="qin-battle-card">
        <div class="qin-bc-head"><b>${A}</b> <i class="fa-solid fa-swords"></i> <b>${D}</b><div class="qin-bc-tags">${tags}</div></div>
        <div class="qin-bc-rolls"><div class="${r.winner === "attacker" ? "win" : ""}"><span>${A}</span><b>${r.attackRoll.total}</b></div><div class="qin-bc-vs">vs</div><div class="${r.winner === "defender" ? "win" : ""}"><span>${D}</span><b>${r.defendRoll.total}</b></div></div>
        <div class="qin-bc-result">${win ? `${win} wins by ${r.diff}` : "Tie"}${r.moraleMultiplier > 1 ? ` · morale loss ×${r.moraleMultiplier}` : ""}</div>
        ${line("cas", "Casualties", r.casualtiesAttacker ? `−${r.casualtiesAttacker}` : "", r.casualtiesDefender ? `−${r.casualtiesDefender}` : "")}
        ${line("mor", "Morale", moraleA ? signed(moraleA) : "", moraleD ? signed(moraleD) : "")}
        ${line("xp", "XP", r.xpAttacker ? `+${r.xpAttacker}` : "", r.xpDefender ? `+${r.xpDefender}` : "")}
        <details><summary>Roll breakdown</summary><div class="qin-breakdown"><div><b>${A}: ${r.attackRoll.total}</b>${col(r.attackRoll)}</div><div><b>${D}: ${r.defendRoll.total}</b>${col(r.defendRoll)}</div></div></details>
      </div>`);
      continue;
    }
    // XP and killing-blow morale for an attack are already on its card
    if ((d?.type === "xp" || d?.type === "moraleGain") && attackIds.has(d.unit) && /XP|killing blow|enemy surrendered/.test(e.text)) continue;
    if (/ ends its turn\.$/.test(e.text)) continue;
    if (d?.type === "rideThrough") continue; // its hits are already listed; the line only carries the path for the animation
    if (d?.type === "walk") continue; // only carries the path the token walks
    parts.push(`<p class="qin-bc-note ${d?.type === "warning" ? "qin-warn" : ""}">${e.text}</p>`);
  }
  if (!parts.length) return;
  await Chat().create({ content: `<div class="qin-chat qin-battle-log">${parts.join("")}</div>`, speaker: { alias: "Battle" } });
}

/** Skills with their own animations (David, 2026-11-09; played by battle/unique-fx.mjs): attacks made while the active's
 *  buff is on, contested rolls a passive makes everyone around it take (the end-of-turn terror), and its extra turns. */
export const UNIQUE_ATTACK = ["None Can Stand Before Him"], UNIQUE_CONTEST = ["Terror of the Battlefield", "Stone Sentinel Maze", "Roar That Breaks Bridges", "Terror of Changban"], UNIQUE_EXTRA = ["Terror of the Battlefield"],
  UNIQUE_PICKED = ["The Wolf Bares His Fangs"], UNIQUE_ZAP = ["Eighty Jin of Iron"], UNIQUE_SELF = ["Fight or Be Butchered", "Iron Rule"], UNIQUE_STACK = ["Reckless Conqueror"], UNIQUE_POUNCE = ["The Tiger Pounces"], UNIQUE_PASSIVE_START = ["Lord of the North"]; // ZAP: its damage to one unit has its own animation (unique-fx ON_ZAP)
function uniqueAttackOf(s, id) {
  const u = E.unitById(s, id);
  return (u?.fx?.buffs ?? []).map(b => b.name).find(n => UNIQUE_ATTACK.includes(n)) ?? null;
}

/** The name of the buff giving a unit its Sweep (its animation is keyed to it). */
function sweepSkillOf(s, id) {
  const u = E.unitById(s, id);
  return (u?.fx?.buffs ?? []).find(b => (b.flags ?? []).some(f => String(f.flag).startsWith("sweep")))?.name ?? null;
}

/**
 * After an action, animate it for everyone: for each attack the attacker lunges (casualties and morale
 * over the defender), then the defender strikes back (numbers over the attacker), then both gain XP;
 * level-ups glow; any other changes (e.g. end-of-turn morale) float last.
 */
function animateChanges(scene, before, s, entries, actionType = null) {
  if (!scene) return null;
  const steps = [];
  let overwatchShot = false; // the next attack is an overwatch shot
  const covered = {}; // what the attack steps already showed, per unit
  const add = (id, k, n) => { (covered[id] ??= { men: 0, morale: 0, xp: 0 })[k] += n; };
  const extraTurns = []; // "Another turn" plays after the rout that earned it
  for (const e of entries) {
    // a battlefield active opens with its banner (dim, the side's band, the officer's art); its effects play after it
    if (e.detail?.type === "skill" && e.detail.active) {
      const u = E.unitById(s, e.detail.unit);
      steps.push({ kind: "activeBanner", unit: e.detail.unit, side: u?.side ?? "neutral", skill: e.detail.skill, officerId: u?.officerId ?? null, officerName: u?.name ?? "", touched: e.detail.touched ?? [] });
      // an active whose animation plays on the units picked for it (Sima Yi's hunt), after the banner
      if (UNIQUE_PICKED.includes(e.detail.skill) && e.detail.picks) {
        const ids = [...new Set(Object.values(e.detail.picks).flat())].filter(id => E.unitById(s, id));
        if (ids.length) steps.push({ kind: "terror", unit: e.detail.unit, skill: e.detail.skill, results: ids.map(id => [id, true]), closed: true });
      }
      continue;
    }
    // a ride through the enemy (Gongsun Zan's Ride Them Down): the path and who it trampled, played as one step
    if (e.detail?.type === "rideThrough") {
      for (const [id, cas] of e.detail.hits ?? []) add(id, "men", cas);
      steps.push({ kind: "ride", unit: e.detail.unit, skill: e.detail.skill, path: e.detail.path ?? [], hits: e.detail.hits ?? [] });
      continue;
    }
    // a unit walking its path (it goes round other units); a skill hitting it on the way halts it there (David, 2026-11-18)
    if (e.detail?.type === "walk") {
      const u = E.unitById(s, e.detail.unit);
      steps.push({ kind: "walk", unit: e.detail.unit, path: e.detail.path ?? [], stops: [], cavalry: !!u && E.typeOf(s, u)?.category === "cavalry" });
      continue;
    }
    if (e.detail?.type === "skillCasualties" && e.detail.skill && (e.detail.at !== undefined || UNIQUE_ZAP.includes(e.detail.skill))) {
      const w = e.detail.at !== undefined ? [...steps].reverse().find(x => x.kind === "walk" && x.unit === e.detail.unit) : null;
      if (w) { w.stops.push({ at: e.detail.at + 1, skill: e.detail.skill, src: e.detail.src, cas: e.detail.casualties }); add(e.detail.unit, "men", e.detail.casualties); continue; }
      if (UNIQUE_ZAP.includes(e.detail.skill)) { steps.push({ kind: "zap", skill: e.detail.skill, src: e.detail.src, unit: e.detail.unit, cas: e.detail.casualties }); add(e.detail.unit, "men", e.detail.casualties); continue; }
    }
    // a skill's morale loss on a unit with its own animation (Dong Zhuo's whip at the end of each driven unit's turn)
    if (e.detail?.type === "skillCounter" && UNIQUE_STACK.includes(e.detail.skill)) { steps.push({ kind: "selfFx", skill: e.detail.skill, unit: e.detail.unit, amount: e.detail.count }); continue; } // a stack gained (Sun Ce)
    if (e.detail?.type === "skillMorale" && e.detail.lost > 0 && UNIQUE_SELF.includes(e.detail.skill)) {
      steps.push({ kind: "selfFx", skill: e.detail.skill, unit: e.detail.unit, amount: e.detail.lost }); add(e.detail.unit, "morale", -e.detail.lost); continue;
    }
    // a passive that plays at the start of battle (Yuan Shao's banner), then the units whose starting morale it raised
    // get the blue sweep as their morale float shows (David, 2026-11-21)
    if (e.detail?.type === "passiveStart") {
      if (UNIQUE_PASSIVE_START.includes(e.detail.skill)) {
        const src = E.unitById(s, e.detail.unit);
        const units = entries.filter(x => x.detail?.type === "skillMorale" && x.detail.start > 0).map(x => x.detail.unit)
          .filter(id => E.unitById(s, id)?.side === src?.side);
        steps.push({ kind: "passiveStart", unit: e.detail.unit, skill: e.detail.skill, units });
      }
      continue;
    }
    // a tactic plays where it fired: before the attack that set it off
    if (e.detail?.type === "tactic") { steps.push({ kind: "tactic", tactic: e.detail.tactic }); continue; }
    if (e.detail?.type === "reload") { steps.push({ kind: "reload", unit: e.detail.unit }); continue; } // a crossbow unit reloads (David, 2026-11-10)
    if (e.detail?.type === "setFire") { steps.push({ kind: "setFire", x: e.detail.x, y: e.detail.y }); continue; }
    if (e.detail?.type === "gateHit") { // a unit batters a gate: lunge, impact on the gate, the damage over it
      const g = (s.siege?.gates ?? []).find(q => q.id === e.detail.gate);
      if (g) steps.push({ kind: "gateHit", unit: e.detail.by, squares: g.squares, damage: e.detail.damage, broken: e.detail.hp <= 0 });
      continue;
    }
    if (e.detail?.type === "overwatch" && e.detail.fired) { overwatchShot = true; continue; }
    // a passive's contested rolls on everyone around it (Lu Bu's end-of-turn terror): one pulse, then who resisted
    if (e.detail?.type === "skillContest" && UNIQUE_CONTEST.includes(e.detail.skill)) {
      let tr = steps.find(x => x.kind === "terror" && x.unit === e.detail.src && x.skill === e.detail.skill && !x.closed);
      if (!tr) steps.push(tr = { kind: "terror", unit: e.detail.src, skill: e.detail.skill, results: [] });
      tr.results.push([e.detail.unit, !!e.detail.lost]);
      continue;
    }
    if (e.detail?.type === "skill" && e.detail.extraTurn && UNIQUE_EXTRA.includes(e.detail.skill)) { extraTurns.push({ kind: "anotherTurn", unit: e.detail.unit, skill: e.detail.skill }); continue; }
    // Sweep (Guan Yu): plays right after the attack that set it off
    if (e.detail?.type === "sweep") {
      const at = [...steps].reverse().find(x => x.kind === "attack" && x.attacker === e.detail.by);
      if (at) {
        (at.sweep ??= { skill: s.units.length ? sweepSkillOf(s, e.detail.by) : null, hits: [] }).hits.push([e.detail.unit, e.detail.casualties, e.detail.morale || 0]);
        add(e.detail.unit, "men", e.detail.casualties); add(e.detail.unit, "morale", -(e.detail.morale || 0));
      }
      continue;
    }
    const r = e.detail?.type === "attack" ? e.detail.result : null;
    if (!r) continue;
    const toD = [], toA = [];
    if (r.casualtiesDefender) { toD.push(["unitDamage", `−${r.casualtiesDefender}`]); add(r.defender, "men", r.casualtiesDefender); }
    if (r.loser === r.defender && r.moraleLoss) { toD.push(["moraleDown", `−${r.moraleLoss} morale`]); add(r.defender, "morale", -r.moraleLoss); }
    if (r.casualtiesAttacker) { toA.push(["unitDamage", `−${r.casualtiesAttacker}`]); add(r.attacker, "men", r.casualtiesAttacker); }
    if (r.loser === r.attacker && r.moraleLoss) { toA.push(["moraleDown", `−${r.moraleLoss} morale`]); add(r.attacker, "morale", -r.moraleLoss); }
    // the attacker's sword icon shows this attack's situational total (not the dice or the officer's stats)
    const base = /^(Yin\/Yang|Command|Fire|Skill|Unit Value|Encouraged|Demoralized|One soldier left|Two soldiers left|Modifier:)/;
    const attackBonus = (r.attackRoll?.parts ?? []).reduce((t, [label, v]) =>
      base.test(label) || / Command$/.test(label) || (!r.ranged && /^Attacker bonus/.test(label)) ? t : t + (Number(v) || 0), 0); // a skill's "Command" shows on the rolls icon
    const dUnit = E.unitById(s, r.defender);
    // a ranged unit strikes back with a volley, except a Hybrid caught in melee: it fights back hand to hand (lunge)
    const returnRanged = !!dUnit && E.typeOf(s, dUnit)?.weapon === "ranged" && !(!r.ranged && (dUnit.traitTiers?.hybrid || dUnit.traitTiers?.['throwing axes'] || dUnit.traitTiers?.['spear crossbow']));
    const aType = E.unitById(s, r.attacker) ? E.typeOf(s, E.unitById(s, r.attacker)) : null;
    steps.push({ kind: "attack", attacker: r.attacker, defender: r.defender, toDefender: toD, toAttacker: toA, returnStrike: r.damageToAttacker > 0, attackBonus, ranged: !!r.ranged, returnRanged,
      crossbow: /nushu/i.test(aType?.skill ?? ""), charge: !!r.charge && aType?.category === "cavalry", overwatch: overwatchShot,
      special: !r.ranged && s.units.length ? uniqueAttackOf(s, r.attacker) : null,
      pounce: !r.ranged ? (r.nextAttack ?? []).find(n => UNIQUE_POUNCE.includes(n)) ?? null : null }); // its attack is the skill's own animation (Sun Jian's tiger)
    overwatchShot = false;
    if (r.suppressed) steps.push({ kind: "suppressed", unit: r.defender }); // Suppressing Fire landed
    if (r.charge && !r.ranged && r.loser === r.defender) steps.push({ kind: "charged", unit: r.defender }); // a charge that won: "Charged!" (David, 2026-11-10)
    const gains = [];
    if (r.xpAttacker) { gains.push([r.attacker, "xp", `+${r.xpAttacker} XP`]); add(r.attacker, "xp", r.xpAttacker); }
    if (r.xpDefender) { gains.push([r.defender, "xp", `+${r.xpDefender} XP`]); add(r.defender, "xp", r.xpDefender); }
    { const kb = r.killMoraleBy ?? r.killedBy; if (kb && r.killMorale) { gains.push([kb, "moraleUp", `+${r.killMorale} morale`]); add(kb, "morale", r.killMorale); } }
    if (gains.length) steps.push({ kind: "floats", items: gains });
  }
  for (const e of entries) if (e.detail?.type === "levelUp") steps.push({ kind: "levelUp", unit: e.detail.unit, level: e.detail.level });
  // units left surrounded at the end of a turn: white flash + "Surrounded!" before their morale loss shows
  const firstAttack = entries.findIndex(e => e.detail?.type === "attack");
  const preAttack = [], postAttack = [], lossOf = {};
  entries.forEach((e, i) => {
    if (e.detail?.type !== "surrounded") return;
    lossOf[e.detail.unit] = e.detail.loss ?? 40;
    (firstAttack >= 0 && i < firstAttack ? preAttack : postAttack).push(e.detail.unit);
  });
  const surroundSteps = (ids) => {
    ids = [...new Set(ids)];
    for (const id of ids) add(id, "morale", -lossOf[id]);
    return [{ kind: "surrounded", units: ids }, { kind: "floats", items: ids.filter(id => lossOf[id]).map(id => [id, "moraleDown", `\u2212${lossOf[id]} morale`]) }];
  };
  if (preAttack.length) steps.unshift(...surroundSteps(preAttack));
  if (postAttack.length) steps.push(...surroundSteps(postAttack));
  // anything else that changed (end-of-turn morale, forced march, adjacent defeats...)
  const rest = [];
  for (const u of s.units) {
    const b = before[u.id]; if (!b) continue;
    const c = covered[u.id] ?? { men: 0, morale: 0, xp: 0 };
    const men = b.men - u.men - c.men, morale = u.morale - b.morale - c.morale;
    if (men > 0) rest.push([u.id, "unitDamage", `−${men}`]);
    if (morale) rest.push([u.id, morale > 0 ? "moraleUp" : "moraleDown", `${morale > 0 ? "+" : "−"}${Math.abs(morale)} morale`]);
  }
  if (rest.length) steps.push({ kind: "floats", items: rest });
  const fallen = s.units.filter(u => before[u.id]?.status === "active" && u.status !== "active")
    .map(u => [u.id, u.status === "surrendered" ? "flag" : "skull"]);
  if (fallen.length) steps.push({ kind: "fallen", units: fallen });
  steps.push(...extraTurns);
  steps.push(...logSoundSteps(entries, actionType));
  return broadcastBattleAnim(scene.id, steps);
}

/* ------------------------------------------------------------ officer duels */

/** How far down the Breath of Life track an officer is: 0 Normal ... 4 Fatally injured, 5 coma, 6 dead. */
export function bolStep(actor, damage = actor?.system?.bol?.damage ?? 0) {
  const levels = actor?.system?.bol?.levels;
  if (!levels) return 0;
  const st = Q.bolState(levels.map(l => l.max), damage);
  return st.dead ? 6 : st.coma ? 5 : Q.BOL_KEYS.indexOf(st.current);
}
/** The officer actor (character) leading a battle unit, by the unit's token id. */
function duelOfficer(scene, unitId) {
  return scene?.tokens.get(unitId)?.actor?.system?.officerActor ?? null;
}

/* ------------------------------------------------------------ run actions (GM only) */

/**
 * Run an engine action as a user. Adapter-only actions: startBattle (binds the
 * current scene), endBattle, armMarch.
 */
export function runAction(userId, action) {
  const job = queue.then(() => runActionNow(userId, action));
  queue = job.catch(() => {});
  // Initiative rolls itself (David, 2026-10-31): whenever an action leaves the battle at the start of a round (tactics
  // finished or skipped, a round ended), the GM's client starts the round, reinforcements due first as before.
  // The Start round button stays as a fallback.
  job.then(res => {
    const b = getBattle();
    if (res?.ok && action.type !== "startRound" && b.active && b.turn?.phase === "start" && !b.outcome)
      runAction(game.user.id, { type: "startRound" }).catch(e => console.warn("Qin | auto start round", e));
  }).catch(() => {});
  return job;
}

/**
 * Undo (David, 2026-11-18): the GM's client keeps the battle as it was before each of the last actions (the battle record
 * and every unit's position, men, morale, status and effects). "undoAction" puts the latest one back: units return to
 * where they stood, losses come back, and whose turn it is goes back too. Kept in memory only (a reload clears it);
 * starting, resetting or ending a battle clears it. Chat lines already posted stay, with a note that it was undone.
 */
const undoStack = [];
const UNDO_MAX = 15;
const UNDO_SKIP = new Set(["startBattle", "endBattle", "resetBattle", "undoAction"]);
export const undoInfo = () => { const u = undoStack.at(-1); return u ? { n: undoStack.length, label: u.label } : null; };
function undoLabel(s, action) {
  const nm = (id) => s.units.find(u => u.id === id)?.name ?? "a unit";
  const t = action.type;
  if (t === "moveTo" || t === "move" || t === "forcedMarch") return nm(action.unitId) + "'s move";
  if (/attack/i.test(t)) return nm(action.unitId) + "'s attack" + (action.targetId ? " on " + nm(action.targetId) : "");
  if (t === "useSkill") return nm(action.unitId) + "'s battlefield active";
  if (t === "endTurn") return nm(action.unitId) + " ending its turn";
  return (action.unitId ? nm(action.unitId) + ": " : "") + t.replace(/([A-Z])/g, " $1").toLowerCase();
}
async function undoLast() {
  const u = undoStack.pop();
  if (!u) return { ok: false, error: "Nothing to undo" };
  const scene = game.scenes.get(u.battle.sceneId);
  if (!scene) return { ok: false, error: "The battle scene is gone" };
  await writeBack(foundry.utils.deepClone(u.battle), foundry.utils.deepClone(u.s), scene);
  await Chat().create({ content: `<div class="qin-chat qin-battle-log"><b>Undone</b> (GM): ${foundry.utils.escapeHTML?.(u.label) ?? u.label}. The battle is back as it was before it.</div>`, speaker: { alias: "Battle" } });
  globalThis.Hooks?.callAll?.("qinBattleUndo", undoInfo());
  return { ok: true };
}

async function runActionNow(userId, action) {
  if (!game.user.isGM) return { ok: false, error: "Only the GM's client can run battle actions" };
  const user = game.users.get(userId);
  const actor = { id: user?.isGM ? "host" : userId, host: !!user?.isGM };
  let battle = getBattle();
  if (action.type === "undoAction") {
    if (!actor.host) return { ok: false, error: "Only the GM can undo" };
    return undoLast();
  }
  if (["startBattle", "endBattle", "resetBattle"].includes(action.type)) undoStack.length = 0;

  if (action.type === "startBattle") {
    if (!actor.host) return { ok: false, error: "Only the GM can start a battle" };
    const scene = game.scenes.get(action.sceneId) ?? canvas.scene;
    if (!scene) return { ok: false, error: "Open the battle scene first" };
    if (!unitTokens(scene).length) return { ok: false, error: "Place some Unit tokens on the scene first" };
    battle = emptyBattle();
    battle.active = true;
    battle.sceneId = scene.id;
  } else if (action.type === "endBattle") {
    if (!actor.host) return { ok: false, error: "Only the GM can end the battle" };
    // (Units no longer lose XP for their casualties when the battle ends: David, 2026-10-24.)
    // units that escaped come back: active again and visible (tokens on the scene, and any unit actor left Escaped)
    try {
      const sc = game.scenes.get(battle.sceneId);
      for (const tok of unitTokens(sc)) if (tok.actor?.system?.status === "escaped") {
        await tok.actor.update({ "system.status": "active" }, { qinBattle: true });
        if (tok.hidden) await tok.update({ hidden: false }, { qinBattle: true });
      }
      const left = (game.actors?.contents ?? []).filter(a => a.type === "unit" && a.system.status === "escaped");
      if (left.length) await Actor.updateDocuments(left.map(a => ({ _id: a.id, "system.status": "active" })), { qinBattle: true });
    } catch (e) { console.warn("Qin | restoring escaped units", e); }
    try { (await import("./reinforce.mjs")).clearReinforcements(game.scenes.get(battle.sceneId)); } catch (e) { console.warn("Qin | clearing reinforcements", e); }
    // officers who fought duels: non-player characters are healed when the battle ends (the slain stay dead)
    try {
      for (const uuid of battle.duelists ?? []) {
        const o = fromUuidSync(uuid);
        if (!o || ownerUserId(o) || o.system?.bol?.dead || !(o.system?.bol?.damage > 0)) continue;
        await o.update({ "system.bol.damage": 0 }, { qinBattle: true });
      }
    } catch (e) { console.warn("Qin | healing duelists", e); }
    // siege equipment: players lose what was used (ladders set up, engines left on the field, catapults burned)
    try {
      const sc = game.scenes.get(battle.sceneId), back = {};
      const plus = (o, k) => { (back[o] ??= { ladders: 0, engine: 0, catapult: 0 })[k]++; };
      for (const tok of unitTokens(sc)) { const c = battle.meta?.[tok.id]?.carry, o = tok.actor && ownerUserId(tok.actor); if (o && (c === "ladders" || c === "engine")) plus(o, c); }
      for (const c of battle.siege?.catapults ?? []) if (c.owner && c.owner !== "host" && !battle.siege?.burnt?.[c.x + "," + c.y]) plus(c.owner, "catapult");
      await settleSiegeLosses(battle, back);
    } catch (e) { console.warn("Qin | siege equipment after the battle", e); }
    await game.settings.set(SYSTEM_ID, SETTING, emptyBattle());
    return { ok: true };
  } else if (!battle.active) {
    return { ok: false, error: "No battle is running" };
  }

  if (action.type === "armMarch") {
    const ac = battle.turn.activation;
    const u = ac && game.scenes.get(battle.sceneId)?.tokens.get(ac.unitId)?.actor;
    if (!ac || ac.unitId !== action.unitId || !(actor.host || ownerUserId(u) === userId)) return { ok: false, error: "It isn't that unit's turn" };
    ac.armedMarch = !ac.armedMarch;
    await game.settings.set(SYSTEM_ID, SETTING, battle);
    return { ok: true };
  }

  // The GM ends a duel that has been fought: measure how far each officer fell on the Breath of Life track
  if (action.type === "duelEnd") {
    if (!actor.host) return { ok: false, error: "Only the GM can end the duel" };
    const p = battle.duels?.pending;
    if (!p || p.stage !== "fighting") return { ok: false, error: "No duel is being fought" };
    const sc = game.scenes.get(battle.sceneId);
    const A = duelOfficer(sc, p.from), B = duelOfficer(sc, p.to);
    const fromNow = bolStep(A), toNow = bolStep(B);
    action = { type: "duelResult", fromDrop: Math.max(0, fromNow - (p.startStep?.from ?? 0)), toDrop: Math.max(0, toNow - (p.startStep?.to ?? 0)),
      fromDead: !!A?.system?.bol?.dead, toDead: !!B?.system?.bol?.dead };
  }
  if (action.type === "placeTactic") {
    const sc = game.scenes.get(battle.sceneId);
    action = { ...action, highGround: !!sc && isHighGround(sc, action.x, action.y) };
  }
  // Reinforcements due this round arrive first, so the round starts with them on the field
  if (action.type === "startRound") { try { await (await import("./reinforce.mjs")).arriveDue(game.scenes.get(battle.sceneId), battle.turn?.round ?? 0); } catch (e) { console.warn("Qin | reinforcements", e); } }
  if (action.type === "resetBattle") { try { await (await import("./reinforce.mjs")).clearReinforcements(game.scenes.get(battle.sceneId)); } catch (e) { console.warn("Qin | reinforcements", e); } }
  const moving = ["move", "forcedMarch"].includes(action.type) ? action.unitId : null;
  const { s, scene } = buildState(battle, { useLastPosition: moving, terrainFor: action.type === "moveTo" ? action.unitId : null });
  if (action.type === "moveTo") s.freeMovement = false;
  const logLen = s.log.length;
  const before = Object.fromEntries(s.units.map(u => [u.id, { men: u.men, morale: u.morale, xp: u.xp || 0, status: u.status, buffs: (u.fx?.buffs ?? []).map(b => b.name) }]));
  E.setRng(() => CONFIG.Dice.randomUniform());
  const prevDuel = foundry.utils.deepClone(battle.duels?.pending ?? null);
  const snap = UNDO_SKIP.has(action.type) || !scene ? null : { battle: foundry.utils.deepClone(battle), s: foundry.utils.deepClone(s), label: undoLabel(s, action) };
  const res = E.act(s, actor, action.type === "startBattle" ? { type: "startBattle" } : action);
  if (res.ok && snap) { undoStack.push(snap); if (undoStack.length > UNDO_MAX) undoStack.shift(); globalThis.Hooks?.callAll?.("qinBattleUndo", undoInfo()); }
  if (!res.ok && action.type === "startBattle") return res;
  if (res.ok && action.type === "duelAnswer" && s.duels?.pending?.stage === "fighting") {
    const p = s.duels.pending, A = duelOfficer(scene, p.from), B = duelOfficer(scene, p.to);
    p.startStep = { from: bolStep(A), to: bolStep(B) };
    battle.duelists = [...new Set([...(battle.duelists ?? []), A?.uuid, B?.uuid].filter(Boolean))];
  }
  // an officer used a battlefield active: hold that unit's stand on every client until its activation animation
  // has played, so its morale cost and buff show after the banner, not before
  if (res.ok && scene) {
    const acts = s.log.slice(logLen).filter(e => e.detail?.type === "skill" && e.detail.active);
    // the other units the active buffs or debuffs wait too, so their bursts land after the banner (David, 2026-11-11)
    for (const e of acts) e.detail.touched = touchedBy(s, before, e.detail.skill, e.detail.unit);
    const acting = [...new Set(acts.flatMap(e => [e.detail.unit, ...e.detail.touched]))];
    if (acting.length) broadcastFreeze(scene.id, acting);
    broadcastAnimHold(scene.id); // the action menu waits until this action's animations have played
  }
  const rides = Object.fromEntries(s.log.slice(logLen).filter(e => e.detail?.type === "rideThrough" && e.detail.path?.length > 1).map(e => [e.detail.unit, e.detail.path[0]]));
  // units that walked a path (click-to-move, the AI) are held on their start square until their walk plays
  const walks = Object.fromEntries(s.log.slice(logLen).filter(e => e.detail?.type === "walk" && e.detail.path?.length > 1).map(e => [e.detail.unit, e.detail.path[0]]));
  // a finished duel: everyone goes back to the battle first (the zoom out), and only then do the morale changes land
  // on the units, in the chat and as floating numbers (David, 2026-11-17: they showed before the animation)
  let duelClosed = false;
  if (res.ok && (action.type === "duelResult" || action.type === "duelCancel") && prevDuel?.duelSceneId) {
    await (await import("./duel-scene.mjs")).closeDuelScene(prevDuel);
    await new Promise(r => setTimeout(r, 1200));                  // everyone's battle map has loaded again
    duelClosed = true;
  }
  await writeBack(battle, s, scene, rides, walks);
  if (s.skillRequests?.length) await skillRequests(s, scene).catch(e => console.warn("Qin | battlefield skill requests", e));
  await postLog(s.log.slice(logLen), s);
  // officer duels: an accepted duel moves to its close-up scene; a finished or cancelled one comes back
  if (res.ok && action.type === "duelAnswer" && s.duels?.pending?.stage === "fighting") (await import("./duel-scene.mjs")).openDuelScene();
  if (res.ok && !duelClosed && (action.type === "duelResult" || action.type === "duelCancel") && prevDuel?.duelSceneId) await (await import("./duel-scene.mjs")).closeDuelScene(prevDuel);
  if (res.ok) {
    const shown = animateChanges(scene, before, s, s.log.slice(logLen), action.type);
    // Units destroyed or surrendered this action: remove their tokens once the skull/flag and fade have played.
    // The unit itself stays in the Actors directory; linked units are remembered for the XP count at the end.
    const fallen = s.units.filter(u => before[u.id]?.status === "active" && u.status !== "active" && scene?.tokens.get(u.id));
    if (fallen.length) {
      const b2 = getBattle();
      b2.fallen ??= {};
      for (const u of fallen) { const tok = scene.tokens.get(u.id); b2.fallen[u.id] = { actorId: tok.actorLink ? tok.actorId : null, name: tok.name }; }
      await game.settings.set(SYSTEM_ID, SETTING, b2);
      Promise.resolve(shown).catch(() => {}).then(() =>
        scene.deleteEmbeddedDocuments("Token", fallen.map(u => u.id).filter(id => scene.tokens.get(id)), { qinBattle: true }).catch(e => console.warn("Qin | removing fallen units", e)));
    }
  }
  return res;
}

/** No longer used (David, 2026-10-24): after a battle, each unit lost XP equal to the casualties it suffered. */
// eslint-disable-next-line no-unused-vars
async function settleXpAfterBattle(battle) {
  const scene = game.scenes.get(battle.sceneId);
  if (!scene) return;
  const lines = [];
  // units still on the scene, and fallen units whose tokens were removed (linked ones: their actor remains)
  const entries = unitTokens(scene).map(tok => ({ id: tok.id, name: tok.name, actor: tok.actor }));
  for (const [id, f] of Object.entries(battle.fallen ?? {})) if (!entries.some(e => e.id === id) && f.actorId) entries.push({ id, name: f.name, actor: game.actors.get(f.actorId) });
  for (const tok of entries) {
    const start = battle.startMen?.[tok.id];
    if (start === undefined || !tok.actor || tok.actor.system.side !== "player") continue; // XP is for Player units only
    const sys = tok.actor.system;
    const lost = Math.max(0, start - sys.men.value);
    const xp = sys.xp?.value ?? 0;
    const after = Math.max(0, xp - lost);
    if (after !== xp) await tok.actor.update({ "system.xp.value": after }, { qinBattle: true });
    lines.push(`<li><b>${tok.name}</b>: ${lost} casualties${lost ? `, XP ${xp} → ${after}` : `, XP ${xp}`}</li>`);
  }
  if (lines.length) await Chat().create({ content: `<div class="qin-chat qin-battle-log"><h3>Battle over</h3><p>Units lose XP equal to the casualties they suffered.</p><ul>${lines.join("")}</ul></div>`, speaker: { alias: "Battle" } });
}

/** GM-side reaction to a token being dragged during a battle. */
export async function onTokenMoved(tokenDoc, change, options) {
  if (!game.user.isGM || game.users.activeGM?.id !== game.user.id) return;
  if (options?.qinBattle || !("x" in change || "y" in change)) return;
  const battle = getBattle();
  if (!battle.active || tokenDoc.parent?.id !== battle.sceneId || tokenDoc.actor?.type !== "unit") return;
  const size = tokenDoc.parent.grid.size;
  const x = Math.round((change.x ?? tokenDoc.x) / size), y = Math.round((change.y ?? tokenDoc.y) / size);
  const ac = battle.turn.activation;
  if (ac && ac.unitId === tokenDoc.id) {
    const type = ac.armedMarch ? "forcedMarch" : "move";
    if (ac.armedMarch) { ac.armedMarch = false; await game.settings.set(SYSTEM_ID, SETTING, battle); }
    return runAction(game.user.id, { type, unitId: tokenDoc.id, x, y });
  }
  // Moves outside the unit's own turn: just record the new position.
  return runAction(game.user.id, { type: "place", unitId: tokenDoc.id, x, y, silent: true });
}

