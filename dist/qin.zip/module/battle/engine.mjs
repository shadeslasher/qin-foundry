// Three Kingdoms Tactics rules engine. Pure game logic: no networking.
// All state lives in one plain object so it can be saved as JSON.

import * as data from './engine-data.mjs';
import { deployMoveCheck, zoneSet } from './deploy-rules.mjs';
import { evaluateObjectives, freshObjState, emptyObjectives } from './objectives.mjs';

// Four sides. Any two different sides are hostile; units of the same side never attack each other.
const SIDES = ['player', 'enemy', 'ally', 'neutral'];
const MAX_LOG = 400;

// ---------------------------------------------------------------- state

function newState() {
  return {
    version: 1,
    map: { image: null, cols: 24, rows: 16, tile: 48, offsetX: 0, offsetY: 0, terrain: {} },
    library: {
      unitTypes: clone(data.UNIT_TYPES),
      officers: clone(data.OFFICERS),
    },
    players: {},       // playerId -> { name, color }
    units: [],
    nextUnitId: 1,
    turn: freshTurn('setup', 0),
    log: [],
    objectives: emptyObjectives(), // victory / defeat conditions (from the scene)
    objState: freshObjState(),     // what the battle has done towards them
    objEval: null,                 // where each condition stands (for the tracker)
    outcome: null,                 // { result: 'victory' | 'defeat', round, at } once the battle is decided
    duels: freshDuels(),           // officer duels: the one waiting or being fought, and officers who refused
  };
}

function freshDuels() { return { pending: null, refused: [] }; }
function duels(s) { if (!s.duels) s.duels = freshDuels(); if (!s.duels.refused) s.duels.refused = []; return s.duels; }

function freshTurn(phase, round) {
  return {
    phase,            // setup | start (round start, waiting for the GM) | officer | officerless | final
    round,
    order: [],        // officer unit ids, highest initiative first
    init: {},         // unitId -> { total, yin, yang, fire }
    decided: [],      // officer units that have used their slot (acted / held / forfeited)
    held: [],         // officer units currently holding
    sideIdx: 0,       // officerless rotation pointer into SIDES
    claim: null,      // player id that claimed the player-side officerless turn
    activation: null, // { unitId, step: 'move'|'act', started, startedHidden, charge, interject }
  };
}

function clone(o) { return JSON.parse(JSON.stringify(o)); }

// ---------------------------------------------------------------- lookups

const typeOf = (s, u) => s.library.unitTypes.find(t => t.id === u.typeId) || null;
const officerOf = (s, u) => (u.officerId ? s.library.officers.find(o => o.id === u.officerId) || null : null);
const unitById = (s, id) => s.units.find(u => u.id === id) || null;
const alive = u => u.status === 'active';
const liveUnits = s => s.units.filter(alive);
const alliance = side => (side === 'ally' ? 'player' : side) || 'player'; // Ally units fight on the players' side: never enemies, never targets (fixed 2026-10-25)
const hostile = (a, b) => alliance(a.side) !== alliance(b.side);
const friendly = (a, b) => !hostile(a, b);
const passive = (s, u) => { const o = officerOf(s, u); return (o && o.passive && o.passive.effects) || {}; };
const unitAt = (s, x, y) => liveUnits(s).find(u => u.x === x && u.y === y) || null;
const terrainAt = (s, x, y) => s.map.terrain[x + ',' + y] || 'flat';
const inBounds = (s, x, y) => x >= 0 && y >= 0 && x < s.map.cols && y < s.map.rows;
/**
 * A square's terrain effects from the battle map (terrain + overlays, added together), or null when the scene
 * has no battle map (then the older region-based terrain applies).
 */
function tileRules(s, x, y) {
  let tile = s.map.tiles && s.map.tiles[x + ',' + y];
  if (!tile) return null;
  tile = burnState(s, x, y, tile); // fire: a burning square has the Fire overlay; a burnt one has turned to scorched ground or ruins
  let overlays = tile.overlays || [];
  const gate = overlays.includes('city-gate') ? gateAt(s, x, y) : null;
  if (gate && gate.state === 'burned') overlays = overlays.map(o => (o === 'city-gate' ? 'ruins' : o)); // burned gates are ruins
  // a camp palisade or timber wall with a road running out through it is the camp's gate: open ground, no wall defense
  const isCampSq = (o) => o === 'camp' || (o || '').startsWith('camp-');
  const campGate = overlays.includes('road') && overlays.some(o => o === 'camp-palisade' || o === 'camp-wall')
    && ORTHO.some(([dx, dy]) => { const n = s.map.tiles[(x + dx) + ',' + (y + dy)]; const no = (n && n.overlays) || []; return n && no.includes('road') && !no.some(isCampSq); });
  if (campGate) overlays = overlays.map(o => (o === 'camp-palisade' || o === 'camp-wall' ? 'camp-gate' : o));
  const parts = [data.MAP_TERRAIN[tile.terrain] || { name: tile.terrain }, ...overlays.map(o => data.MAP_OVERLAYS[o] || { name: o })];
  const r = { move: 0, meleeDef: 0, rangedDef: 0, range: 0, atk: 0, downhill: 0, high: false, command: 0, moraleTurn: 0, healthTurn: 0, campDef: 0,
    hides: false, noSurround: false, wall: false, water: false, flammable: false, names: [], camp: overlays.some(o => o === 'camp' || o.startsWith('camp-')),
    campEdge: overlays.some(o => o === 'camp-palisade' || o === 'camp-wall') }; // a rampart square: entered from inside the camp only
  let none = false, noCav = false, bridge = false;
  for (const p of parts) {
    for (const k of ['move', 'meleeDef', 'rangedDef', 'range', 'atk', 'downhill', 'command', 'moraleTurn', 'healthTurn', 'campDef']) r[k] += p[k] || 0;
    if (p.high || (p.wall && !p.gate)) r.high = true; // hills, walls and towers are high ground; gates are ground level
    if (p.pass === 'none') none = true;
    if (p.gate && (!gate || gate.state === 'locked')) none = true; // a locked gate: no one stands in it
    if (p.pass === 'noCavalry') noCav = true;
    if (p.bridge) bridge = true;
    if (p.hides) r.hides = true;
    if (p.rough) r.rough = true;
    if (p.noSurround) r.noSurround = true;
    if (p.flammable) { r.flammable = true; r.fireRes = Math.min(r.fireRes ?? 99, p.fireRes || 0); }
    if (p.wall) r.wall = true;
    if (p.water) r.water = true;
    if (p.name) r.names.push(p.name);
  }
  // cover only counts on open ground: a road, watchtower or any other overlay in a forest leaves the unit in view
  // (a hill keeps its trees)
  if (r.hides && overlays.some(o => o !== 'hill' && !(data.MAP_OVERLAYS[o] || {}).hides)) r.hides = false;
  // a road or bridge through rough ground lets cavalry ride it normally
  if (r.rough && overlays.some(o => o === 'road' || o === 'bridge')) r.rough = false;
  // walls, gates and towers hold units, but units don't walk onto them (until ladders and gates are in)
  r.pass = (none && !bridge) || r.wall ? 'none' : noCav ? 'noCavalry' : 'all';
  return r;
}
/** Can a unit walk into this square? (u: the mover, for "not cavalry" squares) */
function passable(s, x, y, u) {
  if (!inBounds(s, x, y)) return false;
  const r = tileRules(s, x, y);
  if (r) return r.pass === 'all' || (r.pass === 'noCavalry' && !(u && (typeOf(s, u) || {}).category === 'cavalry'));
  return (data.TERRAIN[terrainAt(s, x, y)] || data.TERRAIN.flat).passable;
}
/** Can a unit be in this square at all? (walls, towers and camp ramparts hold units even though they can't be walked onto from outside) */
function standable(s, x, y) {
  if (!inBounds(s, x, y)) return false;
  const r = tileRules(s, x, y);
  return r ? r.pass !== 'none' || r.wall || r.campEdge : passable(s, x, y);
}
/** From a camp rampart square a unit only steps to other squares of the camp (not down to the outside). */
function campEdgeDrop(s, x, y, nx, ny) {
  const from = tileRules(s, x, y);
  if (!from || !from.campEdge) return false;
  const to = tileRules(s, nx, ny);
  return !(to && to.camp);
}
/** A camp's palisade or timber wall square can be stepped onto from any other square of that camp (its defenders man the rampart), never from outside. */
function campEdgeStep(s, x, y, nx, ny) {
  const to = tileRules(s, nx, ny);
  if (!to || !to.campEdge || !inBounds(s, nx, ny)) return false;
  const from = tileRules(s, x, y);
  return !!(from && from.camp);
}
/** Extra movement a square adds (its Move modifier, never below 0; Woodsmen ignore forest and trees).
 * Cavalry pay +1 more on rough ground (forest, trees, marsh, rocky, sand, ford, tall grass). */
function surcharge(s, x, y, u) {
  const r = tileRules(s, x, y);
  if (!r) return 0;
  let move = r.move;
  const tile = s.map.tiles && s.map.tiles[x + ',' + y];
  if (u && tile && trait(u, 'frontier riders')) { const f = frontierRules(tile); return Math.max(0, f.move) + (f.rough && isCavalry(s, u) ? 1 : 0); }
  if (u && tile && trait(u, 'woodsmen')) {
    if (tile.terrain === 'forest') move -= (data.MAP_TERRAIN.forest.move || 0);
    if (tile.overlays?.includes('trees')) move -= (data.MAP_OVERLAYS.trees.move || 0);
  }
  return Math.max(0, move) + (r.rough && isCavalry(s, u) ? 1 : 0);
}
const isCavalry = (s, u) => !!u && (typeOf(s, u) || {}).category === 'cavalry';
/** Rough ground for this unit: cavalry can't charge across or onto it (a road through it is clear). */
const roughFor = (s, x, y, u) => {
  if (!isCavalry(s, u)) return false;
  const tile = s.map.tiles && s.map.tiles[x + ',' + y];
  if (tile && trait(u, 'frontier riders')) return frontierRules(tile).rough;
  return !!(tileRules(s, x, y) || {}).rough;
};
/** Frontier Riders (Qiang, David 2026-10-31): sand, tall grass and rocky ground cost no extra movement and don't stop a
 *  charge. Movement and roughness of a square with those parts left out (other terrain and overlays still count). */
const FRONTIER = new Set(['sand', 'tall-grass', 'rocky']);
function frontierRules(tile) {
  const overlays = tile.overlays || [];
  const parts = [[tile.terrain, data.MAP_TERRAIN[tile.terrain]], ...overlays.map(o => [o, data.MAP_OVERLAYS[o]])].filter(([k, p]) => p && !FRONTIER.has(k));
  let move = 0, rough = false;
  for (const [, p] of parts) { move += p.move || 0; if (p.rough) rough = true; }
  if (rough && overlays.some(o => o === 'road' || o === 'bridge')) rough = false;
  return { move, rough };
}

// ---------------------------------------------------------------- walls and siege
// Wall level: city walls and fortress towers (units stand on top). Gates are ground level and can't be entered.
const overlaysAt = (s, x, y) => { const t = s.map.tiles && s.map.tiles[x + ',' + y]; return (t && t.overlays) || []; };
const isWallTop = (s, x, y) => overlaysAt(s, x, y).some(o => o === 'city-wall' || o === 'fortress-tower');
const isWallish = (s, x, y) => overlaysAt(s, x, y).some(o => o === 'city-wall' || o === 'fortress-tower' || o === 'city-gate');
const onWall = (s, u) => isWallTop(s, u.x, u.y);
function siegeState(s) { if (!s.siege) s.siege = { ladders: [], dropped: [], gates: [] }; if (!s.siege.gates) s.siege.gates = []; return s.siege; }

// ---------------------------------------------------------------- fire
// A square that catches fire burns for its burn time (rounds, the longest of its flammable parts), then burns
// down: flammable parts turn into what they burn into (scorched ground, ruins, or nothing). Spreading comes later.
//   siege.fires: { "x,y": { left } }   siege.burnt: { "x,y": true }
const burnPart = (id, kind) => (kind === 'terrain' ? data.MAP_TERRAIN[id] : data.MAP_OVERLAYS[id]) || null;
/** The square as fire has left it: burning adds the Fire overlay, burnt replaces its flammable parts. */
function burnState(s, x, y, tile) {
  const sg = s.siege, k = x + ',' + y;
  if (!sg || (!sg.burnt?.[k] && !sg.fires?.[k])) return tile;
  let terrain = tile.terrain, overlays = [...(tile.overlays || [])];
  if (sg.burnt?.[k]) {
    const tp = burnPart(terrain, 'terrain');
    if (tp?.flammable) terrain = tp.burnsInto && data.MAP_TERRAIN[tp.burnsInto] ? tp.burnsInto : terrain === 'forest' ? 'scorched' : terrain;
    const out = [];
    for (const o of overlays) {
      const op = burnPart(o, 'overlay');
      if (!op?.flammable) { out.push(o); continue; }
      const into = op.burnsInto;
      if (into && data.MAP_OVERLAYS[into]) out.push(into);
      else if (into && data.MAP_TERRAIN[into]) terrain = into;
    }
    overlays = out;
  }
  if (sg.fires?.[k] && !overlays.includes('fire')) overlays.push('fire');
  return { ...tile, terrain, overlays };
}
/** Is this square flammable, and how long does it burn? null when it can't burn (or already burnt). */
function burnInfo(s, x, y) {
  const k = x + ',' + y, tile = s.map.tiles && s.map.tiles[k];
  if (!tile || s.siege?.burnt?.[k]) return null;
  const parts = [burnPart(tile.terrain, 'terrain'), ...(tile.overlays || []).map(o => burnPart(o, 'overlay'))].filter(p => p?.flammable);
  if (!parts.length) return null;
  return { burnTime: Math.max(1, ...parts.map(p => p.burnTime || 1)), name: parts.map(p => p.name).join(', ') };
}
/** Set a square alight. Returns false if it can't burn or is already burning. */
function igniteTile(s, x, y, why) {
  const info = burnInfo(s, x, y), k = x + ',' + y;
  if (!info) return false;
  const sg = siegeState(s); sg.fires = sg.fires || {}; sg.burnt = sg.burnt || {};
  if (sg.fires[k]) return false;
  sg.fires[k] = { left: info.burnTime };
  log(s, (why ? why + ': ' : '') + 'the ' + info.name.toLowerCase() + ' at ' + k + ' catches fire (burns for ' + info.burnTime + ' round' + (info.burnTime === 1 ? '' : 's') + ').', { type: 'setFire', x, y });
  return true;
}
/** End of a round: fires burn down. */
function burnRound(s) {
  const sg = s.siege; if (!sg?.fires) return;
  for (const [k, f] of Object.entries(sg.fires)) {
    f.left -= 1;
    if (f.left > 0) continue;
    const [x, y] = k.split(',').map(Number), info = burnInfo(s, x, y);
    delete sg.fires[k]; sg.burnt = sg.burnt || {}; sg.burnt[k] = true;
    log(s, 'The ' + (info ? info.name.toLowerCase() : 'square') + ' at ' + k + ' burns down.', { type: 'burntDown', x, y, gate: !!gateAt(s, x, y) });
  }
}
/** City gates: { id, squares: [[x, y]...], owner: 'friendly' | 'enemy', state: 'locked' | 'open' | 'broken' | 'burned' }. */
const gateAt = (s, x, y) => (s.siege && s.siege.gates ? s.siege.gates.find(g => g.squares.some(([gx, gy]) => gx === x && gy === y)) : null) || null;
const gateBlocks = (g) => !g || g.state === 'locked';
/** Gates next to the unit. */
const gatesNear = (s, u) => (s.siege && s.siege.gates ? s.siege.gates.filter(g => g.squares.some(([x, y]) => Math.abs(x - u.x) + Math.abs(y - u.y) === 1)) : []);
/** May this unit open or close that gate? Its owners from either side; anyone from inside the city. */
function gateKeyHolder(s, u, g) {
  if (insideCity(s, u.x, u.y)) return true;
  const side = alliance(u.side);
  return g.owner === 'enemy' ? side === 'enemy' : side === 'player' || side === 'ally';
}
const hasLadder = (s, x, y) => !!(s.siege && s.siege.ladders.includes(x + ',' + y));
/** Squares inside the city walls: everything the map edge can't reach without crossing a wall, gate or tower. */
function insideSet(s) {
  if (s._inside) return s._inside;
  const out = new Set();
  if (!s.map.tiles || !Object.values(s.map.tiles).some(t => (t.overlays || []).some(o => o === 'city-wall' || o === 'city-gate' || o === 'fortress-tower'))) return (s._inside = out);
  const { cols, rows } = s.map, seen = new Set(), q = [];
  for (let x = 0; x < cols; x++) for (const y of [0, rows - 1]) q.push([x, y]);
  for (let y = 0; y < rows; y++) for (const x of [0, cols - 1]) q.push([x, y]);
  while (q.length) {
    const [x, y] = q.pop(), k = x + ',' + y;
    if (seen.has(k) || !inBounds(s, x, y) || isWallish(s, x, y)) continue;
    seen.add(k);
    for (const [dx, dy] of ORTHO) q.push([x + dx, y + dy]);
  }
  for (let x = 0; x < cols; x++) for (let y = 0; y < rows; y++) { const k = x + ',' + y; if (!seen.has(k) && !isWallish(s, x, y)) out.add(k); }
  return (s._inside = out);
}
const insideCity = (s, x, y) => insideSet(s).has(x + ',' + y);
/**
 * Can these two adjacent units fight in melee? Same level always; a wall top and the city inside always;
 * a wall top and the ground outside only where a ladder stands on that wall square.
 */
function meleeLevelOk(s, a, b) {
  const wa = onWall(s, a), wb = onWall(s, b);
  if (wa === wb) return true;
  const g = wa ? b : a, w = wa ? a : b;
  return insideCity(s, g.x, g.y) || hasLadder(s, w.x, w.y);
}
/** A ranged shot from the ground stops at the walls: any wall, gate or tower between the two squares blocks it. */
function wallBlocksShot(s, a, d) {
  if (!s.map.tiles || onWall(s, a)) return false;
  const n = Math.max(Math.abs(d.x - a.x), Math.abs(d.y - a.y)) * 4;
  for (let i = 1; i < n; i++) {
    const x = Math.round(a.x + (d.x - a.x) * i / n), y = Math.round(a.y + (d.y - a.y) * i / n);
    if ((x === a.x && y === a.y) || (x === d.x && y === d.y)) continue;
    if (isWallTop(s, x, y) || (overlaysAt(s, x, y).includes('city-gate') && gateBlocks(gateAt(s, x, y)))) return true;
  }
  return false;
}
/** What siege equipment a unit carries: 'ladders' | 'engine' | null. */
const carrying = (u) => (u && u.carry) || null;
/** Drop a unit's equipment on its square (by choice, or when it falls). */
function dropEquipment(s, u, why) {
  const kind = carrying(u); if (!kind) return;
  siegeState(s).dropped.push({ x: u.x, y: u.y, kind });
  u.carry = null;
  log(s, u.name + (why || ' drops its ') + (kind === 'ladders' ? 'siege ladders' : 'siege engine') + '.', { type: 'dropEquipment', x: u.x, y: u.y, kind });
}
/** Pick up equipment lying on the unit's square (only with empty hands). */
function pickUpEquipment(s, u) {
  if (carrying(u) || !s.siege) return;
  const i = s.siege.dropped.findIndex(d => d.x === u.x && d.y === u.y);
  if (i < 0) return;
  const [d] = s.siege.dropped.splice(i, 1);
  u.carry = d.kind;
  log(s, u.name + ' picks up the ' + (d.kind === 'ladders' ? 'siege ladders' : 'siege engine') + '.', { type: 'pickUpEquipment', x: u.x, y: u.y, kind: d.kind });
}
/** Empty wall squares with a ladder next to the unit that it may climb (not cavalry, nor units carrying equipment). */
function climbTiles(s, u) {
  if (!s.siege || onWall(s, u) || carrying(u) || (typeOf(s, u) || {}).category === 'cavalry') return [];
  return ORTHO.map(([dx, dy]) => [u.x + dx, u.y + dy]).filter(([x, y]) => hasLadder(s, x, y) && !unitAt(s, x, y));
}
/** Wall squares next to the unit where it could set a ladder (carrying ladders, from the ground). */
function ladderTiles(s, u) {
  if (carrying(u) !== 'ladders' || onWall(s, u)) return [];
  return ORTHO.map(([dx, dy]) => [u.x + dx, u.y + dy]).filter(([x, y]) => isWallTop(s, x, y) && !hasLadder(s, x, y));
}
const manhattan = (a, b) => Math.abs(a.x - b.x) + Math.abs(a.y - b.y);
const sign = n => (n > 0 ? 1 : n < 0 ? -1 : 0);
const clamp = (n, lo, hi) => Math.max(lo, Math.min(hi, n));
const ORTHO = [[1, 0], [-1, 0], [0, 1], [0, -1]];

function log(s, text, detail) {
  s.log.push({ t: Date.now(), round: s.turn.round, text, detail: detail || null });
  if (s.log.length > MAX_LOG) s.log.splice(0, s.log.length - MAX_LOG);
}

/**
 * Can this unit use its officer's battlefield active now? (David, 2026-10-26)
 * - one officer skill per turn; the unit must have MORE morale than the cost (paying can't take it to 0)
 * - recharge: turns (battle rounds) to wait after a use, so used in round R with recharge N it is ready in R+N;
 *   perBattle: once per battle
 * - lastStand: only usable at 25 morale or less (no other morale requirement)
 */
function skillCheck(s, u, o) {
  const sk = o && o.skill;
  if (!sk) return { ok: false, reason: 'No officer skill' };
  if (u.round && u.round.skillUsed) return { ok: false, reason: 'Officer skill already used this turn' };
  const cost = Number(sk.moraleCost) || 0, round = (s.turn && s.turn.round) || 0;
  if (sk.perBattle && u.skillLastRound != null) return { ok: false, reason: 'Already used this battle' };
  const n = Number(sk.recharge) || 0;
  if (n && u.skillLastRound != null && round < u.skillLastRound + n) {
    const left = u.skillLastRound + n - round;
    return { ok: false, reason: 'Recharging: ' + left + ' turn' + (left === 1 ? '' : 's'), left };
  }
  if (sk.lastStand && u.morale > 25) return { ok: false, reason: 'Last stand: only at 25 morale or less' };
  if (cost && u.morale <= cost) return { ok: false, reason: 'Needs more than ' + cost + ' morale' };
  return { ok: true, reason: '' };
}

/** An enemy officer's passive "no rear attacks near me": attackers within 2 tiles of that unit get no rear bonus. */
function rearDenied(s, attacker) {
  return liveUnits(s).some(o => hostile(o, attacker) && passive(s, o).noRearNearby && manhattan(o, attacker) <= 2);
}

function moraleState(m) {
  if (m <= 0) return 'Surrendered';
  if (m <= 25) return 'Demoralized';
  if (m >= 75) return 'Encouraged';
  return 'Neutral';
}

// ---------------------------------------------------------------- traits
// A unit's traits come from its Traits tab as { "base name": tier }, tier 1 = base, 2 = "+", 3 = "++".
function trait(u, base) { const t = u && u.traitTiers; return (t && t[base]) || 0; }
/** Suppressing Fire (David, 2026-10-29): movement -2 (min 1); a suppressed unit loses Hold, Brace, Anti-Cavalry and Charge Reflection until it wears off. */
const suppressed = (u) => !!(u && u.fx && u.fx.suppressed);
/** Hybrid, or Throwing Axes (Hybrid without the melee Attack -2: David, 2026-10-29): a ranged unit that also fights adjacent enemies in melee. */
const hybridOf = (u) => !!(trait(u, 'hybrid') || trait(u, 'throwing axes') || trait(u, 'spear crossbow'));
const holdingNow = (u) => !!(u && u.round && u.round.holding) && !suppressed(u);
const tierVal = (tier, vals) => (tier ? vals[Math.min(tier, vals.length) - 1] : 0);
/** Lasting per-unit battle effects (poison, sunder, reload, slowed, stood still last turn). */
function fx(u) { if (!u.fx) u.fx = {}; return u.fx; }
/** Extra range from Range Up (if the unit stood still on its last turn). */
function rangeBonus(s, u) { return fx(u).stillLast ? tierVal(trait(u, 'range up'), [1, 2]) : 0; }

// ---------------------------------------------------------------- tactics
// Placed before initiative by each side's tactician; hidden until they fire (once), then active for their duration.
const TACTIC_SIDES = ['player', 'ally', 'enemy'];
const SIDE_LABEL = { player: 'Player', ally: 'Ally', enemy: 'Enemy', neutral: 'Neutral' };
const tacticDef = key => data.TACTICS.find(t => t.key === key) || null;
const inTacticArea = (t, u) => Math.abs(u.x - t.x) <= t.size && Math.abs(u.y - t.y) <= t.size;
const tacticLive = (s, t) => t.state === 'active' && (t.untilRound === undefined || s.turn.round <= t.untilRound);
/** Active tactics of these keys helping unit u right now (only ever units of the side that placed them). */
function tacticsOn(s, u, keys) {
  const T = s.tactics; if (!T || !u) return [];
  const ks = [].concat(keys);
  return T.placed.filter(t => ks.includes(t.key) && t.side === u.side && tacticLive(s, t) &&
    (tacticDef(t.key).bound ? t.unitId === u.id : inTacticArea(t, u)));
}
const hasTactic = (s, u, k) => tacticsOn(s, u, k).length > 0;
/** A hidden tactic of u's side with this trigger that covers u (it would fire). */
const pendingTactic = (s, u, trigger) => !!(s.tactics && s.tactics.phase === 'battle' && s.tactics.placed.some(t =>
  t.state === 'hidden' && t.side === u.side && tacticDef(t.key).trigger === trigger && (t.key === 'raiseFlag' ? t.x === u.x && t.y === u.y : inTacticArea(t, u))));

function triggerTactic(s, t, u) {
  const def = tacticDef(t.key);
  t.state = def.turns ? 'active' : 'spent';
  t.firedRound = s.turn.round;
  t.untilRound = def.turns ? s.turn.round + def.turns - 1 : s.turn.round;
  if (def.bound && u) t.unitId = u.id;
  log(s, SIDE_LABEL[t.side] + ' tactic: ' + def.name + '!' + (t.tactician ? ' (' + t.tactician + ')' : '') + ' ' + def.text,
    { type: 'tactic', tactic: { id: t.id, key: t.key, name: def.name, side: t.side, x: t.x, y: t.y, size: t.size, tactician: t.tactician || null } });
}
/** Fire every hidden tactic of u's side whose trigger is `event` and whose square holds u. */
function fireTactics(s, event, u) {
  const T = s.tactics;
  if (!T || T.phase !== 'battle' || !u) return [];
  const fired = [];
  for (const t of T.placed) {
    if (t.state !== 'hidden' || t.side !== u.side) continue;
    const def = tacticDef(t.key);
    if (!def || def.trigger !== event) continue;
    if (t.key === 'raiseFlag' ? !(u.x === t.x && u.y === t.y) : !inTacticArea(t, u)) continue;
    triggerTactic(s, t, u);
    fired.push(t);
  }
  return fired;
}
/** The officer's skill in the unit's weapon; two-weapon units (skill2, e.g. Azure Dragons) use the higher (David, 2026-10-28). */
function officerWeaponLevel(o, t) {
  if (!o || !t) return 0;
  const sk = o.skills || {}, get = (k) => Number(sk[k] ?? sk[String(k || '').toLowerCase()]) || 0;
  return Math.max(get(t.skill), t.skill2 ? get(t.skill2) : 0);
}
const heroOfficer = (s, u) => { const o = officerOf(s, u), t = typeOf(s, u); return !!(o && t && officerWeaponLevel(o, t) >= 5); };

function movementOf(s, u) {
  const t = typeOf(s, u);
  const slowed = fx(u).slow ? 1 : 0; // Barbed Arrows
  const load = carrying(u) === 'ladders' ? 1 : carrying(u) === 'engine' ? 2 : 0; // siege equipment is heavy
  const saddle = saddleOf(u) >= 3 ? 1 : 0; // Saddle++: movement +1
  // whatever slows it, a unit can always move at least 1 tile (David, 2026-10-25)
  const supp = suppressed(u) ? 2 : 0; // Suppressing Fire: movement -2 (still at least 1)
  return Math.max(1, (t ? t.move : 4) + (passive(s, u).moveBonus || 0) - slowed - load + saddle - supp);
}

/** Heroic actions in battles are off for now (David, 2026-10-25); the code stays for later. */
const HEROIC_ENABLED = false;

function newRoundFlags() {
  return { activated: false, moved: false, cannotMove: false, holding: false, attacked: false,
    skillUsed: false, heroicUsed: false, meleeTarget: null, meleeAttacker: null,
    madeAttack: false, wasAttacked: false, // for facing: has it attacked / been attacked this round
    attacksTaken: 0, rangedTaken: 0 }; // attacks against it this round; ranged ones for Deflect
}

// ---------------------------------------------------------------- dice

let rng = Math.random;
function setRng(fn) { rng = fn; }
function d10() { return Math.floor(rng() * 10); }
// Campaign homebrew: a double counts as its face value (double 8 = 8), not 0.
function yinYang() { const yin = d10(), yang = d10(); return { yin, yang, value: yin === yang ? yin : Math.abs(yin - yang) }; }

// ---------------------------------------------------------------- movement

/** Could `u` step from (x,y) to (nx,ny) as far as the ground goes (other units ignored)? Wall tops: along the wall,
 * and to and from the city inside (not down to the outside); camp ramparts only from inside the camp. */
function terrainStep(s, u, x, y, nx, ny) {
  const fromWall = isWallTop(s, x, y), toWall = isWallTop(s, nx, ny);
  const ok = fromWall && toWall ? true : fromWall ? insideCity(s, nx, ny) && passable(s, nx, ny, u)
    : toWall ? insideCity(s, x, y) : passable(s, nx, ny, u) || campEdgeStep(s, x, y, nx, ny);
  return ok && !campEdgeDrop(s, x, y, nx, ny);
}

// Tiles reachable by `u` with `budget` movement. Units block movement.
// Campaign rule (David, 2026-10-27): a move costs 1 per square walked plus the single biggest surcharge
// on the path, paid once (three forest squares cost 3 + 1 = 4, not 6).
function reachable(s, u, budget) {
  // Units may move through friendly units (not stop on them); Heavy units, and all enemies, block.
  // The cheapest path wins; on a tie, one clear of rough ground, then the longer walk (for a charge).
  // out: "x,y" -> movement spent (empty squares only); out.steps: squares walked; out.rough: keys whose path crossed or ended on rough ground.
  const out = new Map(), steps = new Map(), rough = new Set(); const key = (x, y) => x + ',' + y;
  const start = key(u.x, u.y);
  const seen = new Map(); // "x,y,m,r" -> fewest squares walked to reach that square with max surcharge m and rough flag r
  const bestAt = new Map(); // "x,y" -> [cost, rough, steps] of the best path so far
  const better = (a, b) => !b || a[0] < b[0] || (a[0] === b[0] && (a[1] < b[1] || (a[1] === b[1] && a[2] > b[2])));
  bestAt.set(start, [0, 0, 0]); steps.set(start, 0);
  const q = [[u.x, u.y, 0, 0, 0]]; // x, y, squares walked, max surcharge, rough
  seen.set(start + ',0,0', 0);
  while (q.length) {
    let bi = 0;
    for (let i = 1; i < q.length; i++) if (q[i][2] + q[i][3] < q[bi][2] + q[bi][3]) bi = i;
    const [x, y, n, m, rf] = q.splice(bi, 1)[0];
    if (seen.get(key(x, y) + ',' + m + ',' + rf) < n) continue;
    for (const [dx, dy] of ORTHO) {
      const nx = x + dx, ny = y + dy, k = key(nx, ny);
      if (k === start) continue;
      if (!terrainStep(s, u, x, y, nx, ny)) continue;
      const nn = n + 1, nm = Math.max(m, surcharge(s, nx, ny, u)), nr = rf || (roughFor(s, nx, ny, u) ? 1 : 0);
      if (nn + nm > budget) continue;
      const sk = k + ',' + nm + ',' + nr;
      if (seen.has(sk) && seen.get(sk) <= nn) continue;
      const o = unitAt(s, nx, ny);
      if (o && (trait(o, 'heavy') || !stealthFriends(alliance(o.side), alliance(u.side)))) continue;
      seen.set(sk, nn); q.push([nx, ny, nn, nm, nr]);
      if (o) continue; // pass through friends, never stop on them
      const cand = [nn + nm, nr, nn];
      if (better(cand, bestAt.get(k))) {
        bestAt.set(k, cand); out.set(k, cand[0]); steps.set(k, nn);
        if (nr) rough.add(k); else rough.delete(k);
      }
    }
  }
  out.steps = steps; out.rough = rough;
  return out;
}

/**
 * Everywhere a unit threatens this turn: tiles it can move to (normal move), plus the tiles it could attack
 * from any of them (range bonuses, minimum range and Hybrid melee included). Keys are "x,y".
 */
function threatArea(s, u) {
  const key = (x, y) => x + ',' + y;
  const move = movementOf(s, u);
  const moveSet = new Set(move ? reachable(s, u, move).keys() : []);
  const t = typeOf(s, u), ranged = t.weapon === 'ranged';
  const bands = [[t.rangeMin || 1, (t.rangeMax || 1) + (ranged ? rangeBonus(s, u) : 0)]];
  if (ranged && hybridOf(u)) bands.push([1, 1]);
  const attack = new Set();
  const origins = [[u.x, u.y], ...[...moveSet].map(k => k.split(',').map(Number))];
  for (const [ox, oy] of origins) for (const [lo, hi] of bands) {
    for (let dx = -hi; dx <= hi; dx++) {
      const r = hi - Math.abs(dx);
      for (let dy = -r; dy <= r; dy++) {
        if (Math.abs(dx) + Math.abs(dy) < lo) continue;
        const x = ox + dx, y = oy + dy, k = key(x, y);
        if (standable(s, x, y) && !moveSet.has(k)) attack.add(k);
      }
    }
  }
  attack.delete(key(u.x, u.y));
  return { move: moveSet, attack };
}

/**
 * Where a unit can go this turn. blue: normal move (keeps its action). red: forced march
 * (another move's worth, 5 morale per extra tile, never down to 0 morale; ends the turn).
 */
function moveOptions(s, u) {
  const blue = new Map(), red = new Map(), climb = new Set(), rough = new Set();
  const ac = s.turn.activation;
  if (!u || !ac || ac.unitId !== u.id || ac.step !== 'move' || u.round.cannotMove) return { blue, red, climb, rough };
  const move = movementOf(s, u);
  if (!move) return { blue, red, climb, rough };
  // up a ladder onto an empty wall square: takes all its movement
  for (const [x, y] of climbTiles(s, u)) { blue.set(x + ',' + y, 1); climb.add(x + ',' + y); }
  const canForce = !!officerOf(s, u); // only units led by an officer can force-march
  const reach = reachable(s, u, canForce ? move * 2 : move);
  for (const [k, d] of reach) {
    const n = reach.steps.get(k);
    if (d <= move) { blue.set(k, n); if (reach.rough.has(k)) rough.add(k); }
    else if (canForce) {
      const cost = forcedMarchCost(s, u) * Math.ceil(d - move);
      if (u.morale - cost > 0) red.set(k, { dist: n, cost });
    }
  }
  return { blue, red, climb, rough }; // rough: blue squares whose path crosses or ends on rough ground (no charge)
}

/** Morale per extra tile of forced march: 5, or 2 under Rapid Advance, Swift Retreat (active, or about to fire). */
function forcedMarchCost(s, u) { return hasTactic(s, u, 'rapidAdvance') || pendingTactic(s, u, 'forcedMarch') ? 2 : 5; }

/** Enemy units this unit could attack right now. */
function attackTargets(s, u) {
  return liveUnits(s).filter(d => hostile(u, d) && visibleTo(s, d, alliance(u.side)) && rangeOk(s, u, d));
}

/** Outrider: after a normal move, the empty tiles it could ride on to (1, Outrider+ 2) instead of attacking. */
function outriderTiles(s, u) {
  const ac = s.turn.activation, n = trait(u, 'outrider');
  if (!n || !ac || ac.unitId !== u.id || !ac.movedThisActivation || ac.forcedMarched || u.round.attacked || ac.outrode) return [];
  const reach = reachable(s, u, n >= 2 ? 2 : 1);
  return [...reach.keys()].map(k => k.split(',').map(Number)).filter(([x, y]) => !(x === u.x && y === u.y) && !unitAt(s, x, y));
}

/** What the Fire Emblem-style action menu may offer the active unit. */
// ---------------------------------------------------------------- officer duels (David, 2026-10-28)
// An officer unit next to an enemy officer unit can challenge it instead of attacking (it may move first).
// The challenged side accepts or refuses. Refusing: its unit loses 15 morale and can't be challenged again this
// battle. Accepting: the two officers fight one round of personal combat, mounted (actions from their weapon
// skill, whatever their Horsemanship), outside the engine; the result comes back as duelResult.
const DUEL_REFUSE_MORALE = 15, DUEL_LOSE_MORALE = 25, DUEL_WIN_MORALE = 15, DUEL_DEATH_MORALE = 50, DUEL_KILL_MORALE = 25;

/** Enemy officer units this unit's officer can challenge now. */
function duelTargets(s, u) {
  if (!hasOfficer(u)) return [];
  const D = duels(s);
  return liveUnits(s).filter(d => hostile(u, d) && hasOfficer(d) && manhattan(u, d) === 1 && visibleTo(s, d, alliance(u.side)) && !D.refused.includes(d.id));
}

function actionMenu(s, u) {
  const ac = s.turn.activation;
  const none = { move: false, attack: false, hold: false, ability: false, heroic: false, endTurn: false };
  if (!u || !ac || ac.unitId !== u.id || !alive(u)) return none;
  const o = officerOf(s, u);
  const opts = moveOptions(s, u);
  const canStillAct = !u.round.attacked && !ac.forcedMarched;
  const reloading = !!fx(u).reload;
  const skillOk = !!(o && o.skill && skillCheck(s, u, o).ok);
  const artOk = !!(o && o.battleArt && !u.round.skillUsed && moraleState(u.morale) === 'Encouraged');
  return {
    move: opts.blue.size + opts.red.size > 0,
    attack: canStillAct && !reloading && attackTargets(s, u).length > 0, reloading,
    reload: reloading && !u.round.attacked,
    raiseFlag: canStillAct && pendingTactic(s, u, 'raiseFlag'),
    placeLadder: canStillAct && ladderTiles(s, u).length > 0,
    drop: !!carrying(u),
    reinvigorate: canStillAct && hornReady(s, u) && hornTargets(s, u).length > 0,
    pickUp: canStillAct && !carrying(u) && !!(s.siege && s.siege.dropped.some(d => d.x === u.x && d.y === u.y)),
    openGate: canStillAct && gatesNear(s, u).some(g => g.state === 'locked' && gateKeyHolder(s, u, g)),
    closeGate: canStillAct && gatesNear(s, u).some(g => g.state === 'open' && gateKeyHolder(s, u, g) && !g.squares.some(([x, y]) => unitAt(s, x, y))),
    setFire: canStillAct && pendingTactic(s, u, 'setFire'),
    hold: canStillAct,
    duel: canStillAct && duelTargets(s, u).length > 0,
    outrider: canStillAct && outriderTiles(s, u).length > 0,
    overwatch: canStillAct && !reloading && typeOf(s, u).weapon === 'ranged',
    ability: skillOk || artOk, skill: skillOk, art: artOk,
    heroic: HEROIC_ENABLED && !!(o && (o.heroicActions || []).length && !u.round.heroicUsed && (u.heroicUsed || 0) < (o.fire || 0)),
    undo: !!ac.undo,
    takeBack: !!ac.takeBack,
    endTurn: true,
  };
}

// ---------------------------------------------------------------- facing

/** Turn to face a target: only up, down, left or right. Off the straight lines the longer way wins
 * (2 right, 1 down = right; 2 down, 1 left = down); on a perfect diagonal, left or right. */
function faceToward(u, target) {
  const ddx = target.x - u.x, ddy = target.y - u.y;
  if (!ddx && !ddy) return;
  u.facing = Math.abs(ddx) >= Math.abs(ddy) ? { dx: sign(ddx), dy: 0 } : { dx: 0, dy: sign(ddy) };
}

// Facing: a unit has no facing until it attacks (it turns to its target) or is first attacked in a round before
// it has attacked (it turns to that attacker). Moving doesn't turn it; every facing clears when the round ends.
// Rear: the attacker is behind the defender relative to its facing (never when it has no facing).
function isRear(s, attacker, defender) {
  const f = defender.facing;
  if (!f) return false;
  const dot = (attacker.x - defender.x) * f.dx + (attacker.y - defender.y) * f.dy;
  return dot < 0;
}
function isFront(s, attacker, defender) {
  const f = defender.facing;
  if (!f) return true; // no facing yet: whoever comes at it is in front of it
  return (attacker.x - defender.x) * f.dx + (attacker.y - defender.y) * f.dy > 0;
}

// ---------------------------------------------------------------- visibility

// Can units of alliance `viewerAlliance` see unit `u`?
function visibleTo(s, u, viewerAlliance) {
  // Hidden units can't be seen by other sides (players and their NPC allies share what they see).
  // They're only revealed by attacking, ending their turn next to a hostile unit, or an ability/the GM.
  if (!u.hidden) return true;
  return stealthFriends(alliance(u.side), viewerAlliance);
}
/** Sides that share sight and don't reveal each other: the same side, or Player with Ally. */
function stealthFriends(a, b) {
  if (a === b) return true;
  return (a === 'player' && b === 'ally') || (a === 'ally' && b === 'player');
}
/** A unit that moves next to hidden hostile units reveals them (Scouts: within 3 tiles). */
function revealAround(s, u) {
  const reach = trait(u, 'scouts') ? 3 : 1; // Scouts: 3 tiles (David, 2026-10-30; was 2)
  for (const o of liveUnits(s)) {
    if (o.hidden && !stealthFriends(alliance(o.side), alliance(u.side)) && manhattan(o, u) <= reach) {
      o.hidden = false;
      log(s, o.name + ' is spotted by ' + u.name + '.', { type: 'revealed', unit: o.id });
    }
  }
}
/** Scouts: hostile Scouts within 3 tiles of this unit (they reveal it, and it can't hide there). */
function scoutNear(s, u) {
  return liveUnits(s).find(o => o !== u && trait(o, 'scouts') && !stealthFriends(alliance(o.side), alliance(u.side)) && manhattan(o, u) <= 3) || null;
}
/** Scouts reveal every hidden enemy within 3 tiles of them. */
function scoutSweep(s) {
  for (const u of liveUnits(s)) {
    if (!u.hidden) continue;
    const sc = scoutNear(s, u);
    if (sc) { u.hidden = false; log(s, u.name + ' is spotted by ' + sc.name + ' (Scouts).', { type: 'revealed', unit: u.id }); }
  }
}
/** Hostile troops next to this unit (they stop it hiding and reveal it at the end of its turn). */
function hostileAdjacent(s, u) {
  return liveUnits(s).some(o => o !== u && !stealthFriends(alliance(o.side), alliance(u.side)) && manhattan(o, u) === 1);
}
/** Other enemies next to the unit it can see (Dual Weapons' second attack). */
function secondTargets(s, u, first) {
  return liveUnits(s).filter(o => o !== first && hostile(u, o) && manhattan(o, u) === 1 && visibleTo(s, o, alliance(u.side))).map(o => o.id);
}
/** Empty, passable tiles next to the defender (Wedge's follow-up move). */
function repositionTiles(s, d, u) {
  const out = [];
  for (const [dx, dy] of ORTHO) {
    const x = d.x + dx, y = d.y + dy;
    if (!passable(s, x, y)) continue;
    const o = unitAt(s, x, y);
    if (o && o !== u) continue;
    if (o === u) continue; // already there
    out.push([x, y]);
  }
  return out;
}
/** Stalk (David, 2026-10-30): the unit can also hide in tall grass, plains and farmland (open squares with no road or building on them). */
const STALK_TERRAIN = new Set(['tall-grass', 'plains', 'farmland']);
/** Does terrain hide a unit that ends its turn there? (forests, tall grass; Stalk adds plains and farmland) */
function hidesIn(s, u) {
  const r = tileRules(s, u.x, u.y);
  if (r ? r.hides : terrainAt(s, u.x, u.y) === 'trees') return true;
  if (!trait(u, 'stalk')) return false;
  const t = s.map.tiles && s.map.tiles[u.x + ',' + u.y];
  if (!t) return false;
  const now = burnState(s, u.x, u.y, t);
  return STALK_TERRAIN.has(now.terrain) && !(now.overlays || []).length;
}

// ---------------------------------------------------------------- combat

function rangeOk(s, attacker, defender) {
  const t = typeOf(s, attacker); const d = manhattan(attacker, defender);
  const tr = t.weapon === 'ranged' ? tileRules(s, attacker.x, attacker.y) : null;
  const bonus = t.weapon === 'ranged' ? rangeBonus(s, attacker) + (tr ? tr.range : 0) : 0;
  // Hybrid units may fight next to them in melee
  if (d === 1 && t.weapon === 'ranged' && hybridOf(attacker)) return meleeLevelOk(s, attacker, defender);
  if (!(d >= (t.rangeMin || 1) && d <= Math.max(1, (t.rangeMax || 1) + bonus))) return false;
  if (t.weapon !== 'ranged') return meleeLevelOk(s, attacker, defender); // walls: melee needs the same level or a ladder
  return !wallBlocksShot(s, attacker, defender);
}

/**
 * Casualty checkpoints (David, 2026-10-24): every fifth of a unit's full health lost costs 5 morale, once per battle
 * per checkpoint (80%, 60%, 40%, 20%; a unit wiped out loses nothing more). Call after its health has changed;
 * returns the morale to take off and remembers the checkpoints passed (fx.checkpoints).
 */
const CHECKPOINT_MORALE = 5;
/** Morale lost when surrounded by four enemy units; 10 less for each side closed by impassable ground instead
 * (David, 2026-10-27; 50 until v0.53.0, 25 with four enemy units only until v0.79.0). */
const SURROUND_MORALE = 40;
const SURROUND_PER_BLOCK = 10;
function checkpointsPassed(u) {
  const full = u.maxMen || 100, men = Math.max(0, u.men);
  if (men <= 0) return 4;
  return [0.8, 0.6, 0.4, 0.2].filter(t => men <= t * full).length;
}
function checkpointMorale(u) {
  const now = Math.min(4, checkpointsPassed(u)), before = fx(u).checkpoints || 0;
  if (now <= before) return 0;
  fx(u).checkpoints = now;
  if (trait(u, 'disciplined') >= 4) return 0; // Disciplined EX: no morale loss from casualties (David, 2026-10-29)
  if (trait(u, 'northern steel')) return 0; // Northern Steel (Northern army, David 2026-11-01): no morale loss from casualties
  return u.men > 0 ? (now - before) * CHECKPOINT_MORALE : 0;
}

/**
 * Casualties from one hit (David, 2026-10-25, Total War style): armor pen is extra damage that always goes through;
 * the hit's damage (base + the roll margin) gets through only where it beats the armor.
 *   casualties = pen + max(0, damage - armor), then Evasion ignores a share of it (melee only).
 *   8 dmg, pen 1, armor 11 -> 1;  12 dmg, pen 1, armor 11 -> 1 (over the armor) + 1 (pen) = 2.
 * No damage at all (a negated roll) means no pen either.
 */
function casualtiesOf(dmg, armor, pen, reduce, evade) {
  if (!(dmg > 0)) return 0;
  const over = Math.max(0, dmg - Math.max(0, armor || 0) - (reduce || 0));
  return evadeCasualties(Math.max(0, pen || 0) + over, evade);
}
/** Evasion: the share of melee casualties ignored — 25% / 40% / 55%, Evasion EX 70%. */
const EVASION_PCT = [0, 25, 40, 55, 70];
/** Evasion step from the unit's Evasion trait. Shielded adds nothing here: the Evasion trait already accounts for the unit's
 * shield (David, 2026-10-30); Shielded only gives ranged defense. `breaker` is kept for callers and ignored. */
function evasionOf(u, breaker) { return EVASION_PCT[trait(u, 'evasion ex') ? 4 : Math.min(4, trait(u, 'evasion'))]; }
/** What is left of a hit after Evasion ignores `pct` percent of it; the damage taken rounds up. */
function evadeCasualties(cas, pct) { return pct > 0 && cas > 0 ? Math.ceil(cas * (100 - pct) / 100 - 1e-9) : cas; }

// ---- Equipment (David, 2026-10-25): carried pieces are read like traits
/** War Drums: the best Command bonus from allied drummers within reach (2 tiles, 3 for +/++; +1, ++ gives +2), the carrier included. */
function warDrumsBonus(s, u) {
  let best = 0;
  for (const o of liveUnits(s)) {
    const d = trait(o, 'war drums'); if (!d || !friendly(o, u)) continue;
    const reach = d >= 2 ? 3 : 2, bonus = d >= 3 ? 2 : 1;
    if (manhattan(o, u) <= reach) best = Math.max(best, bonus);
  }
  return best;
}
/** Rallying Banner: at the end of the carrier's turn, adjacent allies gain 1 / 2 / 3 morale (David, 2026-10-25). */
/** Imperial Solidarity (David, 2026-10-31): another allied unit with the trait within 2 tiles gives melee defense +2,
 *  pen +1 and +4 morale at the end of the round. Never from itself; several imperial units nearby count once. */
function imperialAura(s, u) {
  return liveUnits(s).find(o => o !== u && friendly(o, u) && trait(o, 'imperial solidarity') && manhattan(o, u) <= 2) || null;
}
const penOf = (s, t, u) => (t.armorPen || 0) + (imperialAura(s, u) ? 1 : 0);

function rallyingBanner(s, u) {
  const b = trait(u, 'rallying banner'); if (!b || !alive(u)) return;
  for (const o of liveUnits(s)) if (o !== u && friendly(o, u) && manhattan(o, u) === 1 && o.morale < 100) {
    o.morale = Math.min(100, o.morale + b);
    log(s, o.name + ' gains ' + b + ' morale (Rallying Banner of ' + u.name + ').');
  }
}
/** Saddle: Attack +1; Saddle+ also melee defense +1; Saddle++ also movement +1. */
const saddleOf = (u) => trait(u, 'saddle');
/** War Horn: may this unit sound it now? (one use, then a round to recharge) */
function hornReady(s, u) {
  if (!trait(u, 'war horn')) return false;
  const used = fx(u).hornRound;
  return used === undefined || s.turn.round - used >= 2;
}
/** Allies next to `u` that have already taken their turn this round (Reinvigorate targets). */
function hornTargets(s, u) {
  return liveUnits(s).filter(o => o !== u && friendly(o, u) && manhattan(o, u) === 1 && o.round.activated && !(s.turn.activation && s.turn.activation.unitId === o.id));
}

/** Disciplined: the unit's resting morale is 50 + 5/10/15 (set on the sheet; the engine doesn't add it). */
function disciplinedBonus(u) { return tierVal(trait(u, 'disciplined'), [5, 10, 15, 20]); }

// Build one side's roll. role: 'attacker' | 'defender'.
function buildRoll(s, unit, role, ctx) {
  const t = typeOf(s, unit), o = officerOf(s, unit), p = passive(s, unit);
  const other = role === 'attacker' ? ctx.defender : ctx.attacker;
  const dice = yinYang();
  const parts = [['Yin/Yang (' + dice.yin + ' vs ' + dice.yang + ')', dice.value]];
  parts.push(['Command', o ? o.command : 0]); // the officer's Command at full value (Fire and weapon skill don't add to the roll)
  parts.push(['Unit Value', t.unitValue || 0]);

  if (role === 'attacker') {
    if (ctx.ranged && unit.round.moved && !trait(unit, 'moving shot')) parts.push(['Attacker bonus (lost: moved before shooting)', 0]);
    else parts.push(['Attacker bonus', 2]);
    // Officer leading with his own weapon (David, 2026-10-28): Attack +1 per level of the unit's weapon skill above Competent (2):
    // Expert +1, Master +2, Legendary +3, Godlike +4. Two-weapon units use his higher skill. Only on the unit's own attacks.
    if (o) { const lv = officerWeaponLevel(o, t); if (lv > 2) parts.push(["Officer's weapon (" + (lv === officerWeaponLevel(o, { skill: t.skill }) ? t.skill : t.skill2) + ' ' + lv + ')', lv - 2]); }
    if (ctx.charge) parts.push(['Cavalry charge (' + ctx.tilesMoved + ' tiles moved)', ctx.chargeBase]);
    if (ctx.charge && ctx.fierceBonus) parts.push([FIERCE_NAMES[Math.min(4, ctx.fierce)], ctx.fierceBonus]);
    if (ctx.charge && p.chargeAttackBonus) parts.push(['Officer passive: charge', p.chargeAttackBonus]);
    if (trait(unit, 'sharpened weapons')) parts.push(['Sharpened Weapons', tierVal(trait(unit, 'sharpened weapons'), [1, 2, 3])]);
    if (saddleOf(unit)) parts.push(['Saddle', 1]);
    // Charging Strike +2/+4/+6 after moving 2+ tiles; Charging Strike EX +8 after moving 1+ tile (David, 2026-10-29)
    if (!ctx.ranged && trait(unit, 'charging strike') && ctx.tilesMoved >= (trait(unit, 'charging strike') >= 4 ? 1 : 2)) parts.push(['Charging Strike (moved ' + ctx.tilesMoved + (ctx.tilesMoved === 1 ? ' tile)' : ' tiles)'), tierVal(trait(unit, 'charging strike'), [2, 4, 6, 8])]);
    if (ctx.hybridMelee && !trait(unit, 'throwing axes') && !trait(unit, 'spear crossbow')) parts.push(['Hybrid: melee attack', -2]); // Throwing Axes: no penalty
    if (ctx.second) parts.push(['Second attack (Dual Weapons)', -2]);
    if (trait(unit, 'hefty weapon') && unit.round.moved) parts.push(['Hefty Weapon (moved)', -2]);
    // Precision: ranged attacks only (not a Hybrid's melee attack), when the unit hasn't moved; Precision++ +6 (David, 2026-10-28/29)
    if (ctx.ranged && !unit.round.moved && trait(unit, 'precision')) parts.push(['Precision', tierVal(trait(unit, 'precision'), [2, 4, 6])]);
    if (trait(unit, 'swarm') && liveUnits(s).some(o => o !== unit && friendly(o, unit) && manhattan(o, other) === 1))
      parts.push(['Swarm', tierVal(trait(unit, 'swarm'), [1, 2])]);
    // Volley Fire: +1 against a unit already shot at this round. Volley Fire+ (David, 2026-10-28): its ranged attacks get
    // Attack +1 for every ranged attack already made on the defender this round
    if (trait(unit, 'volley fire') >= 2) { const n = ctx.ranged ? (other.round?.rangedTaken || 0) : 0; if (n) parts.push(['Volley Fire+ (' + n + ' shot' + (n > 1 ? 's' : '') + ' before)', n]); }
    else if (trait(unit, 'volley fire') && other.round && other.round.hitByRanged) parts.push(['Volley Fire', 1]);
    if (ctx.rear) parts.push(['Rear attack', 2]);
    if (ctx.ambush) parts.push(trait(unit, 'ambusher') ? ['Attacking from hiding (Ambusher)', 4] : ['Attacking from hiding', 2]);
    if (trait(unit, 'shock troop') && !fx(unit).attackedOnce) parts.push(['Shock Troop (first attack of the battle)', tierVal(trait(unit, 'shock troop'), [2, 4, 6, 8])]);
    if (fx(unit).suppressed) parts.push(['Suppressed (Suppressing Fire)', -1]);
    for (const tc of tacticsOn(s, unit, ['attack', 'flanking', 'ambush'])) parts.push(['Tactic: ' + tacticDef(tc.key).name, 2]);
    // Cavalry Charge: only an attack that is a cavalry charge gains it
    if (ctx.charge) for (const tc of tacticsOn(s, unit, ['cavalryCharge'])) parts.push(['Tactic: ' + tacticDef(tc.key).name + ' (charging)', 4]);
    if (ctx.ranged && hasTactic(s, unit, 'divineWinds')) parts.push(['Tactic: Divine Winds', 2]);
    if (unit.round.moved && hasTactic(s, unit, 'clearPath')) parts.push(['Tactic: Clear a Path (attacking after moving)', 8]);
    if (ctx.phoenixWon) parts.push(['Tactic: Fury of a Phoenix (won the first attack)', 1]);
  } else {
    // Defense bonuses: everything that makes a unit harder to hit is added to the defender's roll
    if (!ctx.ranged && holdingNow(unit)) parts.push(['Holding: melee defense', 1]); // +1 (David, 2026-10-30; was +2). Hold doesn't help against ranged attacks
    if (!ctx.ranged && holdingNow(unit) && trait(unit, 'brace')) parts.push(['Brace' + '+'.repeat(Math.min(2, trait(unit, 'brace') - 1)) + ': melee defense', tierVal(trait(unit, 'brace'), [1, 2, 3])]); // Brace +1, Brace+ +2, Brace++ +3 (David, 2026-10-30)
    if (!ctx.ranged && suppressed(unit)) parts.push(['Suppressed: melee defense (Hold, Brace, Anti-Cavalry and Charge Reflection lost)', -1]);
    // Hold the Line (trait): an adjacent allied unit that is holding gives infantry Melee defense +1/+2 (the best one counts)
    if (!ctx.ranged && t.category === 'infantry') {
      const htl = Math.max(0, ...liveUnits(s).filter(o => o !== unit && friendly(o, unit) && manhattan(o, unit) === 1 && holdingNow(o))
        .map(o => tierVal(trait(o, 'hold the line'), [1, 2])));
      if (htl) parts.push(['Hold the Line (holding ally): melee defense', htl]);
    }
    if (!ctx.ranged && imperialAura(s, unit)) parts.push(['Imperial Solidarity (' + imperialAura(s, unit).name + '): melee defense', 2]);
    if (trait(unit, 'shielded') && ctx.ranged) parts.push(['Shielded: ranged defense', tierVal(trait(unit, 'shielded'), [2, 4, 6])]); // ranged defense only; in melee the unit's Evasion trait already covers its shield (2026-10-30)
    if (ctx.ranged && trait(unit, 'shield battery') && fx(unit).stillLast) parts.push(['Shield Battery: ranged defense', 2]);
    if (!ctx.ranged && saddleOf(unit) >= 2) parts.push(['Saddle+: melee defense', 1]);
    // Deflect: ranged defense +3 against the first ranged attack each round; Deflect+ the first two; Deflect++ the first three (David 2026-11-01; no melee bonus since v0.83.0)
    if (ctx.ranged && trait(unit, 'deflect') && (unit.round.rangedTaken || 0) < tierVal(trait(unit, 'deflect'), [1, 2, 3]))
      parts.push(['Deflect' + '+'.repeat(Math.min(2, trait(unit, 'deflect') - 1)) + ': ranged defense', 3]);
    if (fx(unit).poison) parts.push(['Poisoned: melee & ranged defense', -fx(unit).poison]);
    if (hasTactic(s, unit, 'defend')) parts.push(['Tactic: Defend (melee & ranged defense)', 2]);
    if (ctx.ranged && t.weapon === 'ranged' && hasTactic(s, unit, 'divineWinds')) parts.push(['Tactic: Divine Winds (ranged defense)', 2]);
    if (holdingNow(unit) && s.tactics && s.tactics.placed.some(tc => tc.key === 'holdTheLine' && tc.side === unit.side && tacticLive(s, tc) &&
      tc.anchor && (tc.anchor === unit.id || (unitById(s, tc.anchor) && manhattan(unitById(s, tc.anchor), unit) === 1))))
      parts.push(['Tactic: Hold the Line (' + (ctx.ranged ? 'ranged' : 'melee') + ' defense)', ctx.ranged ? 2 : 3]);
  }
  { const wd = warDrumsBonus(s, unit); if (wd) parts.push(['War Drums', wd]); }
  if (hasTactic(s, unit, 'heroNeeded')) parts.push(['Tactic: A Hero is Needed', 4]);
  if (hasTactic(s, unit, 'warrior1000')) parts.push(['Tactic: A Warrior Worth 1000', 5]);
  if (hasTactic(s, unit, 'fear')) parts.push(['Tactic: Surrounded by Fear', 4]);

  const oc = (typeOf(s, other) || {}).category;
  // Cavalry: Command +1 in melee against infantry, attacking or defending (David, 2026-10-25)
  if (!ctx.ranged && t.category === 'cavalry' && oc === 'infantry') parts.push(['Cavalry vs infantry', 1]);
  // Anti-Cavalry (David, 2026-10-28): Defense +2 / +4 / +6 when cavalry attack it in melee from the front or sides (never the rear);
  // no bonus on its own attacks. Anti-Infantry (+1/+2/+4) only counts on the unit's own attacks.
  if (role === 'defender' && oc === 'cavalry' && !ctx.ranged && !ctx.rear && trait(unit, 'anti-cavalry') && !suppressed(unit))
    parts.push(['Anti-Cavalry: defense against cavalry', tierVal(trait(unit, 'anti-cavalry'), [2, 4, 6])]);
  // ...and Attack +1 / +2 / +3 on its own melee attacks against cavalry (David, 2026-10-29)
  if (role === 'attacker' && oc === 'cavalry' && !ctx.ranged && trait(unit, 'anti-cavalry') && !suppressed(unit)) // melee only
    parts.push(['Anti-Cavalry: attacking cavalry', tierVal(trait(unit, 'anti-cavalry'), [1, 2, 3])]);
  if (role === 'attacker' && oc === 'infantry' && trait(unit, 'anti-infantry')) parts.push(['Anti-Infantry', tierVal(trait(unit, 'anti-infantry'), [1, 2, 4])]);
  // Ruthless Pursuit (Wei, David 2026-11-01): Attack +2 against an enemy at 50 morale or less
  // Opportunists (Xianbei, David 2026-11-01): Attack +2 against an enemy already next to another friendly unit
  if (role === 'attacker' && trait(unit, 'opportunists') && other && liveUnits(s).some(f => f.id !== unit.id && friendly(f, unit) && manhattan(f, other) === 1))
    parts.push(['Opportunists (enemy already engaged)', 2]);
  if (role === 'attacker' && trait(unit, 'ruthless pursuit') && (other.morale ?? 100) <= 50) parts.push(['Ruthless Pursuit (target at 50 morale or less)', 2]);
  let ms = moraleState(unit.morale);
  if (ms === 'Surrendered' && trait(unit, 'fanatic')) ms = 'Demoralized'; // Fanatic: fights on at 0 morale
  if (ms === 'Encouraged') parts.push(['Encouraged', 2]);
  const steady = p.ignoreMoralePenalty ? 'officer passive' : trait(unit, 'unwavering') ? 'Unwavering' : null;
  // Misplaced Devotion (Qingzhou, David 2026-10-31): at 25 morale or less the unit ignores Demoralized and instead
  // gets Attack +3 on its own attacks and melee defense -3 (ranged defense unchanged)
  if (ms === 'Demoralized' && trait(unit, 'misplaced devotion')) {
    if (role === 'attacker') parts.push(['Misplaced Devotion (morale 25 or less): attack', 3]);
    else if (!ctx.ranged) parts.push(['Misplaced Devotion (morale 25 or less): melee defense', -3]);
  } else if (ms === 'Demoralized' && trait(unit, 'zealot')) parts.push(['Zealot (morale 25 or less)', tierVal(trait(unit, 'zealot'), [1, 2, 3])]);
  else if (ms === 'Demoralized') parts.push(['Demoralized' + (steady ? ' (ignored: ' + steady + ')' : ''), steady ? 0 : -2]);
  // Strength penalties scale with the unit's full health (cavalry have 50)
  const full = unit.maxMen || 100;
  // Strength penalties follow the soldier figures on the token (one per 20% of full strength):
  // 2 soldiers left (21-40%) -1, 1 soldier left (1-20%) -2
  const figures = soldierFigures(unit.men, full);
  const grit = trait(unit, 'northern steel'); // Northern Steel (David 2026-11-01): ignores the strength penalties
  if (figures === 1) parts.push(['One soldier left (1-20% strength)' + (grit ? ' (ignored: Northern Steel)' : ''), grit ? 0 : -2]);
  else if (figures === 2) parts.push(['Two soldiers left (21-40% strength)' + (grit ? ' (ignored: Northern Steel)' : ''), grit ? 0 : -1]);
  // terrain of the square the unit stands on
  const tr = tileRules(s, unit.x, unit.y);
  if (tr) {
    const where = tr.names.join(', ');
    if (tr.command) parts.push(['Terrain (' + where + '): command', tr.command]);
    if (role === 'attacker' && tr.atk) parts.push(['Terrain (' + where + '): attack', tr.atk]);
    if (tr.downhill) { // on a hill against a lower unit, attacking or attacked (not against units on a hill, wall or tower)
      const dr = tileRules(s, other.x, other.y);
      if (!(dr && dr.high)) parts.push(['Terrain (' + where + '): ' + (role === 'attacker' ? 'attacking downhill' : 'attacked from below'), tr.downhill]);
    }
    if (role === 'defender') {
      const def = ctx.ranged ? tr.rangedDef : tr.meleeDef;
      if (def) parts.push(['Terrain (' + where + '): ' + (ctx.ranged ? 'ranged' : 'melee') + ' defense', def]);
      const ar = tileRules(s, other.x, other.y);
      if (tr.campDef && !(ar && ar.camp)) parts.push(['Camp defences (attacked from outside)', tr.campDef]);
    }
  }
  for (const m of unit.mods || []) parts.push(['Modifier: ' + m.label, Number(m.value) || 0]);

  const total = parts.reduce((a, [, v]) => a + v, 0);
  return { total, parts, dice };
}

const FIERCE_NAMES = ['', 'Fierce Charge', 'Fierce Charge+', 'Fierce Charge++', 'Fierce Charge EX'];

/** Soldier figures a unit shows: one per 20% of its full strength (matches the token). */
function soldierFigures(men, full) {
  if (!(men > 0)) return 0;
  return Math.max(1, Math.min(5, Math.ceil((5 * men) / (full || 100) - 1e-9)));
}

function damageValue(s, u) {
  return Math.max(0, typeOf(s, u).damage || 0);
}

// Resolve an attack. Returns a result object (also logged). Mutates state.
function resolveAttack(s, attacker, defender, opts) {
  const at = typeOf(s, attacker), dt = typeOf(s, defender);
  // Hybrid: a ranged unit may fight an adjacent enemy in melee (Attack -2)
  const hybridMelee = at.weapon === 'ranged' && !!hybridOf(attacker) && manhattan(attacker, defender) === 1;
  const ranged = at.weapon === 'ranged' && !hybridMelee;
  // Charge: a cavalry unit's melee attack gains +1 for every tile it moved this turn past the first (2 tiles = +1)
  const tilesMoved = opts.movedThisActivation ? (opts.tilesMoved || 0) : 0;
  // Fierce Charge trait on a charge attack: Fierce Charge +2, Fierce Charge+ +4, Fierce Charge++ +4 and the enemy behind takes half damage
  const fierce = attacker.fierceCharge || 0;
  const chargeBase = !ranged && at.category === 'cavalry' ? Math.max(0, tilesMoved - 1) : 0;
  const fierceBonus = chargeBase > 0 ? [0, 2, 4, 4, 4][Math.min(4, fierce)] : 0; // EX: +4, and the unit behind takes full damage
  const rawCharge = chargeBase + fierceBonus;
  const chargeBonus = rawCharge;
  const charge = chargeBonus > 0;
  let rear = isRear(s, attacker, defender) && !passive(s, defender).noRearAgainst && !rearDenied(s, attacker);
  const ambush = !!opts.ambush;
  const free = !!opts.free; // a tactic's free attack: no strike back, doesn't use the unit's action
  const ctx = { attacker, defender, ranged, charge, chargeBonus, chargeBase, fierceBonus, tilesMoved, fierce, rear, ambush, hybridMelee, second: !!opts.second, phoenixWon: !!opts.phoenixWon };
  // Tactics this attack sets off (they count for this attack already)
  let allOut = [];
  if (!opts.noTactics) {
    fireTactics(s, 'attack', attacker);
    fireTactics(s, 'attacked', defender);
    fireTactics(s, ranged ? 'rangedAttack' : 'meleeAttack', attacker);
    if (rear) fireTactics(s, 'rearAttack', attacker);
    if (ambush) fireTactics(s, 'ambush', attacker);
    if (charge) fireTactics(s, 'charge', attacker);
    if (heroOfficer(s, attacker)) fireTactics(s, 'heroAttack', attacker);
    if (liveUnits(s).some(o => o !== attacker && o.side === attacker.side && manhattan(o, defender) === 1)) allOut = fireTactics(s, 'flankedAttack', attacker);
  }

  const A = buildRoll(s, attacker, 'attacker', ctx);
  const D = buildRoll(s, defender, 'defender', ctx);
  const diff = Math.abs(A.total - D.total);
  const winner = A.total > D.total ? 'attacker' : D.total > A.total ? 'defender' : null;
  const aNeg = A.total <= 0, dNeg = D.total <= 0;

  // Who deals damage
  let dmgToDef = 0, dmgToAtt = 0, canCounter = false; // canCounter: the defender may strike back at all
  const base = (u) => damageValue(s, u);
  const winBonus = (side) => (winner === side ? diff : 0);
  if (!ranged) {
    if (!aNeg) dmgToDef = base(attacker) + winBonus('attacker');
    // ranged defenders deal no return damage against melee attackers
    canCounter = (dt.weapon !== 'ranged' || !!hybridOf(defender)) && meleeLevelOk(s, defender, attacker);
    if (!dNeg && canCounter) dmgToAtt = base(defender) + winBonus('defender');
    if (ambush) { dmgToAtt = 0; canCounter = false; } // attacked from hiding: the defender rolls but can't strike back
  } else {
    if (!aNeg) dmgToDef = base(attacker) + winBonus('attacker'); // like melee: base damage, + the difference on a win
    const canReturn = dt.weapon === 'ranged' ? rangeOk(s, defender, attacker) && !trait(defender, 'reload') // crossbows (Reload) never shoot back
      : manhattan(attacker, defender) === 1 && meleeLevelOk(s, defender, attacker);
    canCounter = !!canReturn;
    if (!dNeg && canReturn) dmgToAtt = base(defender) + winBonus('defender');
    if (ambush) { dmgToAtt = 0; canCounter = false; }
  }
  if (free) { dmgToAtt = 0; canCounter = false; }
  // A charged unit can't strike back unless it has Anti-Cavalry; never against a charge into its rear
  if (charge && (rear || !trait(defender, 'anti-cavalry') || suppressed(defender))) { dmgToAtt = 0; canCounter = false; }
  // Winning the exchange while defending: Counter-Attack and Charge Reflection hit back harder
  if (winner === 'defender' && dmgToAtt > 0) {
    dmgToAtt += tierVal(trait(defender, 'counter-attack'), [2, 4]);
  }
  // Charge Reflection (David, 2026-10-30): a holding unit charged by cavalry adds the charge bonus to its strike back, win or lose,
  // whenever it can strike back at all (never in the rear; Anti-Cavalry needed to strike back at a charge; not while Suppressed)
  if (charge && at.category === 'cavalry' && canCounter && dmgToAtt > 0 && holdingNow(defender) && trait(defender, 'charge reflection')) dmgToAtt += chargeBonus;
  if (trait(attacker, 'duelist')) { dmgToAtt = 0; canCounter = false; } // Duelist: ignores counter-strike damage

  // Casualties = armor pen + what the damage leaves after armor, less Evasion in melee.
  // Armor is lowered by Sunder, and Shield Breaker ignores the armor a unit gets from shields.
  // Shield Breaker (David, 2026-10-30): against a unit with a shield (its weapon includes a shield) ignore 1 / 2 / 3 / 4 armor
  // for Shield Breaker / + / ++ / EX
  const armorOf = (t, u, breaker) => Math.max(0, (t.armor ?? t.defense ?? 0) + tierVal(trait(u, 'reinforced armor'), [1, 2, 3]) - (fx(u).sunder || 0) - (breaker && t.shield ? tierVal(breaker, [1, 2, 3, 4]) : 0));
  const evDef = ranged ? 0 : evasionOf(defender, trait(attacker, 'shield breaker'));
  const returnRanged = dt.weapon === 'ranged' && !(!ranged && hybridOf(defender)); // a ranged unit's strike back is a shot, unless it's a Hybrid in melee
  const evAtt = returnRanged ? 0 : evasionOf(attacker, trait(defender, 'shield breaker'));
  const hitDef = (dmg, pen) => casualtiesOf(dmg, armorOf(dt, defender, trait(attacker, 'shield breaker')), pen, 0, 0);
  // Repeating: the attack lands as two hits of half damage (and half pen) each; armor counts against each hit. Evasion then takes its share of the total.
  const repeating = !!trait(attacker, 'repeating') && dmgToDef > 0;
  const casDef = evadeCasualties(repeating ? hitDef(Math.ceil(dmgToDef / 2), Math.ceil(penOf(s, at, attacker) / 2)) + hitDef(Math.floor(dmgToDef / 2), Math.floor(penOf(s, at, attacker) / 2)) : hitDef(dmgToDef, penOf(s, at, attacker)), evDef);
  const casAtt = casualtiesOf(dmgToAtt, armorOf(at, attacker, trait(defender, 'shield breaker')), penOf(s, dt, defender), 0, evAtt);

  // Morale loss for the loser
  // An attacker that can't be struck back (ranged out of reach, charges, Duelist, ambushes...) loses no morale for losing the roll
  let moraleLoss = 0, mult = 1, loser = null;
  if (winner && !(winner === 'defender' && !canCounter)) {
    loser = winner === 'attacker' ? defender : attacker;
    const base = Math.max(0, diff - 1); // the loser of the roll loses the difference - 1
    moraleLoss = base;
    if (winner === 'attacker') {
      mult = 1; // charges and rear attacks don't multiply morale loss
      moraleLoss = base * mult + (passive(s, attacker).extraMoraleLossOnWin || 0);
      const terror = trait(defender, 'four generations') ? 0 : trait(attacker, 'terror'); // Terror: +2 morale loss; Terror+: double it. Four Generations (Song): immune
      if (terror === 1) moraleLoss += 2; else if (terror >= 2) moraleLoss *= 2;
      if (ranged && trait(attacker, 'fire arrows')) moraleLoss += 3; // Fire Arrows: a hit costs 3 more morale
      // Trample: a winning charge against infantry costs the defender 5 more morale
      if (charge && trait(attacker, 'trample') && dt.category === 'infantry') moraleLoss += 5;
      if (rear && trait(defender, 'cowardly')) moraleLoss *= 2; // Cowardly: rear attacks cause double morale loss
    } else {
      moraleLoss = base + (passive(s, defender).extraMoraleLossOnWin || 0);
    }
    // Fragile -5 / Fragile- -4 / Fragile-- -3 extra morale on losing a contested roll (the strongest one counts)
    { const fr = trait(loser, 'fragile') ? 5 : trait(loser, 'fragile-') ? 4 : trait(loser, 'fragile--') ? 3 : 0; moraleLoss += fr; }
  }

  // Apply simultaneously
  const menBefore = { d: defender.men, a: attacker.men };
  defender.men = Math.max(0, defender.men - casDef);
  attacker.men = Math.max(0, attacker.men - casAtt);
  // Fierce Charge++: the enemy unit right behind the defender (in the charge's direction) takes half the damage
  let trample = null;
  // Shock (David, 2026-10-31, a cavalry rule): any cavalry charge that wins the roll against foot troops leaves them
  // shocked: they can't move on their next activation.
  if (charge && winner === 'attacker' && dt.category !== 'cavalry' && alive(defender) && !fx(defender).shocked) {
    fx(defender).shocked = true;
    log(s, defender.name + ' is shocked by the charge and cannot move on its next activation.', { type: 'shocked', unit: defender.id });
  }
  // Fierce Charge++ / EX: only a successful charge (the attacker wins the roll) hits the unit behind (David, 2026-10-31)
  if (charge && fierce >= 3 && winner === 'attacker' && dmgToDef > 0) {
    const ddx = defender.x - attacker.x, ddy = defender.y - attacker.y;
    const dir = Math.abs(ddx) >= Math.abs(ddy) ? { x: sign(ddx), y: 0 } : { x: 0, y: sign(ddy) };
    const b = unitAt(s, defender.x + dir.x, defender.y + dir.y);
    if (b && b !== attacker && alive(b) && hostile(attacker, b)) {
      const bt = typeOf(s, b);
      const full = fierce >= 4; // Fierce Charge EX (David, 2026-10-31): full damage instead of half; armor and Evasion still apply
      const cas = casualtiesOf(full ? dmgToDef : Math.floor(dmgToDef / 2), armorOf(bt, b, false), full ? penOf(s, at, attacker) : Math.floor(penOf(s, at, attacker) / 2), 0, evasionOf(b));
      b.men = Math.max(0, b.men - cas);
      b.morale = clamp(b.morale - checkpointMorale(b), 0, 100);
      trample = { unit: b.id, casualties: cas };
      log(s, (full ? 'Fierce Charge EX: ' : 'Fierce Charge++: ') + b.name + ', behind ' + defender.name + ', takes ' + (full ? 'the full' : 'half the') + ' damage (-' + cas + ').', { type: 'trample', unit: b.id, casualties: cas });
    }
  }
  // Splash Attack (David, 2026-10-28): when the attack lands, every other enemy unit next to the defender takes
  // 2 casualties (Splash Attack) or 4 (Splash Attack+), flat
  const splash = trait(attacker, 'splash attack');
  if (splash && casDef > 0) {
    const n = tierVal(splash, [2, 4, 6]); // Splash Attack++ 6 (David, 2026-10-29)
    for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
      const b = unitAt(s, defender.x + dx, defender.y + dy);
      if (!b || b === attacker || b === defender || !alive(b) || !hostile(attacker, b)) continue;
      const cas = Math.min(n, b.men);
      b.men = Math.max(0, b.men - cas);
      b.morale = clamp(b.morale - checkpointMorale(b), 0, 100);
      log(s, ('Splash Attack' + '+'.repeat(Math.min(2, splash - 1)) + ': ') + b.name + ', next to ' + defender.name + ', takes ' + cas + ' casualties.', { type: 'splash', unit: b.id, casualties: cas });
    }
  }
  if (loser) loser.morale = clamp(loser.morale - moraleLoss, 0, 100);
  // Cutthroat (bandits, David 2026-10-28): the unit that wins the contested roll, attacking or defending, gains 1 / 2 / 3 morale
  if (winner) { const w = winner === 'attacker' ? attacker : defender, bl = trait(w, 'cutthroat'); if (bl) w.morale = clamp(w.morale + tierVal(bl, [1, 2, 3]), 0, 100); }
  // casualties cost morale at checkpoints: -5 the first time each fifth of the unit's health is lost this battle
  const cmD = checkpointMorale(defender), cmA = checkpointMorale(attacker);
  if (cmD) defender.morale = clamp(defender.morale - cmD, 0, 100);
  if (cmA) attacker.morale = clamp(attacker.morale - cmA, 0, 100);

  let suppressedNow = false; // Suppressing Fire landed: the UI plays the Suppressed animation
  // Lasting effects of a successful attack (the attacker won the roll)
  if (winner === 'attacker') {
    const pz = trait(attacker, 'poison'), sd = trait(attacker, 'sunder');
    if (pz) fx(defender).poison = Math.max(fx(defender).poison || 0, tierVal(pz, [1, 2]));   // doesn't stack; Poison+ replaces Poison
    if (sd) fx(defender).sunder = Math.max(fx(defender).sunder || 0, tierVal(sd, [2, 4, 6]));   // doesn't stack; Sunder+ / Sunder++ (-6, David 2026-10-29) replace Sunder
    // Suppressing Fire (ranged): Attack -1, melee defense -1, movement -2 (min 1), no Hold/Brace/Anti-Cavalry/Charge Reflection until the end of its next turn
    if (ranged && trait(attacker, 'suppressing fire')) { fx(defender).suppressed = true; suppressedNow = true; }
  }
  fx(attacker).attackedOnce = true;                                                        // Shock Troop: only the first attack of the battle
  if (casDef > 0 && trait(attacker, 'barbed arrows')) fx(defender).slow = true;          // -1 movement on its next turn
  if (ranged) defender.round.hitByRanged = true;                                          // for Volley Fire
  // Fire Arrows, on a hit: the target's flammable square loses 1 burn resistance, or catches fire once it has none left
  if (ranged && winner === 'attacker' && trait(attacker, 'fire arrows')) {
    const tr = tileRules(s, defender.x, defender.y), key = defender.x + ',' + defender.y;
    if (tr && tr.flammable) {
      const sg = siegeState(s); sg.scorch = sg.scorch || {};
      const left = Math.max(0, (tr.fireRes || 0) - (sg.scorch[key] || 0));
      if (left <= 0) { delete sg.scorch[key]; igniteTile(s, defender.x, defender.y, attacker.name + "'s fire arrows"); }
      else { sg.scorch[key] = (sg.scorch[key] || 0) + 1; log(s, attacker.name + "'s fire arrows scorch " + defender.name + "'s square (burn resistance " + (left - 1) + ' left).'); }
    }
  }
  if (trait(attacker, 'reload')) fx(attacker).reload = 'empty';                           // must take the Reload action before attacking again

  // Facing and memory for this round (a free attack doesn't use up the unit's attack)
  if (!free) attacker.round.attacked = true;
  if (!ranged) {
    attacker.round.meleeTarget = defender.id;
    defender.round.meleeAttacker = attacker.id;
  }
  // attacking turns a unit to its target; being attacked turns it to the attacker only the first time this round,
  // and only if it hasn't attacked this round itself (then it keeps looking where it attacked)
  faceToward(attacker, defender);
  if (!defender.round.wasAttacked && !defender.round.madeAttack) faceToward(defender, attacker);
  attacker.round.madeAttack = true;
  defender.round.wasAttacked = true;
  defender.round.attacksTaken = (defender.round.attacksTaken || 0) + 1;
  if (ranged) defender.round.rangedTaken = (defender.round.rangedTaken || 0) + 1;
  if (attacker.hidden) attacker.hidden = false;

  const result = {
    attacker: attacker.id, defender: defender.id, ranged, charge, rear, ambush, suppressed: suppressedNow,
    attackRoll: A, defendRoll: D, diff, winner,
    damageToDefender: dmgToDef, damageToAttacker: dmgToAtt,
    casualtiesDefender: casDef, casualtiesAttacker: casAtt,
    moraleLoss, moraleMultiplier: mult, loser: loser ? loser.id : null, casualtyMorale: { defender: cmD, attacker: cmA },
  };
  const tags = [ranged ? 'ranged' : 'melee', charge && 'cavalry charge', rear && 'rear', ambush && 'from hiding', free && 'free attack'].filter(Boolean).join(', ');
  const wtxt = winner ? (winner === 'attacker' ? attacker.name : defender.name) + ' wins by ' + diff : 'Tie';
  log(s, attacker.name + ' attacks ' + defender.name + ' (' + tags + '): ' + A.total + ' vs ' + D.total + '. ' + wtxt +
    '. Casualties: ' + defender.name + ' -' + casDef + ', ' + attacker.name + ' -' + casAtt +
    (loser ? '. ' + loser.name + ' loses ' + moraleLoss + ' morale' + (mult > 1 ? ' (x' + mult + ')' : '') : '') +
    (cmD || cmA ? '. Losses cost morale: ' + [cmD && defender.name + ' -' + cmD, cmA && attacker.name + ' -' + cmA].filter(Boolean).join(', ') : '') + '.',
    { type: 'attack', result });

  // XP: casualties inflicted x (enemy tier / own tier), rounded down
  // (only the men the enemy actually had count)
  result.xpAttacker = gainXp(s, attacker, (menBefore.d - defender.men) * (dt.tier || 1) / (at.tier || 1), 'casualties dealt');
  result.xpDefender = gainXp(s, defender, (menBefore.a - attacker.men) * (at.tier || 1) / (dt.tier || 1), 'casualties dealt');
  // Killing blows: morale 5 x enemy tier, XP 25 x (enemy tier / own tier)
  if (defender.men <= 0 && attacker.men > 0) { result.killedBy = attacker.id; result.killMorale = trait(defender, 'expendable') ? 0 : gainMorale(s, attacker, 5 * (dt.tier || 1), 'killing blow'); result.xpAttacker += gainXp(s, attacker, 25 * (dt.tier || 1) / (at.tier || 1), 'killing blow'); }
  if (result.killedBy === attacker.id) killTactics(s, attacker, defender);
  if (attacker.men <= 0 && defender.men > 0) { result.killedBy = defender.id; result.killMorale = trait(attacker, 'expendable') ? 0 : gainMorale(s, defender, 5 * (at.tier || 1), 'killing blow'); result.xpDefender += gainXp(s, defender, 25 * (at.tier || 1) / (dt.tier || 1), 'killing blow'); }
  if (result.killedBy === defender.id) killTactics(s, defender, attacker);
  settle(s);
  // All Out Attack: every unit of the side in the area that can reach the enemy attacks it for free
  for (const tc of allOut) {
    for (const o of liveUnits(s)) {
      if (!alive(defender)) break;
      if (o === attacker || o.side !== tc.side || !inTacticArea(tc, o) || !rangeOk(s, o, defender) || !visibleTo(s, defender, alliance(o.side))) continue;
      resolveAttack(s, o, defender, { free: true, noTactics: true });
    }
  }
  return result;
}

/** Tactics set off when `killer` destroys `victim`: Brutalize, Inspiring the Army. */
function killTactics(s, killer, victim) {
  for (const tc of fireTactics(s, 'destroy', killer)) {
    for (const o of liveUnits(s)) if (o.men > 0 && alliance(o.side) !== alliance(tc.side) && inTacticArea(tc, o)) o.morale = clamp(o.morale - 25, 0, 100);
    log(s, 'Brutalize: enemy units in the area lose 25 morale.');
  }
  if (killer.officerId && victim.officerId) for (const tc of fireTactics(s, 'officerKill', killer)) {
    for (const o of liveUnits(s)) if (o.men > 0 && o.side === tc.side) o.morale = clamp(o.morale + 25, 0, 100);
    log(s, 'Inspiring the Army: every ' + SIDE_LABEL[tc.side].toLowerCase() + ' unit gains 25 morale.');
  }
}

const XP_PER_LEVEL = 100;
export const MAX_LEVEL = 5; // level cap (David, 2026-10-29)
function gainXp(s, u, amount, why) {
  if (u.side !== 'player' || trait(u, 'mercenary')) return 0; // only Player units earn XP; Mercenaries never do
  if ((u.level || 1) >= MAX_LEVEL) return 0;                  // level 5 is the cap: no more XP
  const n = Math.floor(amount);
  if (n <= 0) return 0;
  u.xp = (u.xp || 0) + n;
  log(s, u.name + ' gains ' + n + ' XP (' + why + ').', { type: 'xp', unit: u.id, amount: n });
  // Every 100 XP is a level (tier doesn't change; levels feed the promotion tree later)
  while (u.xp >= XP_PER_LEVEL && (u.level || 1) < MAX_LEVEL) {
    u.xp -= XP_PER_LEVEL;
    u.level = (u.level || 1) + 1;
    log(s, u.name + ' reaches level ' + u.level + '!', { type: 'levelUp', unit: u.id, level: u.level });
  }
  if ((u.level || 1) >= MAX_LEVEL) u.xp = 0; // at the cap the bar stays empty
  return n;
}

function gainMorale(s, u, n, why) {
  const before = u.morale;
  u.morale = clamp(u.morale + n, 0, 100); // kill morale may exceed the 75 regen cap
  log(s, u.name + ' gains ' + (u.morale - before) + ' morale (' + why + ').', { type: 'moraleGain', unit: u.id });
  return u.morale - before;
}

// Apply defeats, surrenders, adjacency penalties and encirclement until stable.
function settle(s, opts = {}) {
  s._settleDepth = (s._settleDepth || 0) + 1;
  try { settleLoop(s, opts); } finally { s._settleDepth--; }
  if (!s._settleDepth) { processFear(s); delete s._settleDepth; checkOutcome(s); }
}

// ---------------------------------------------------------------- victory and defeat
const objState = (s) => { if (!s.objState) s.objState = freshObjState(); return s.objState; };
const BATTLE_PHASES = ['tactics', 'start', 'officer', 'officerless', 'final'];
/** A unit's turn ends: the square counts as seized by its side; a unit that must escape leaves from an extraction square. */
function trackEndOfTurn(s, u) {
  if (!alive(u)) return;
  const st = objState(s), k = u.x + ',' + u.y;
  if (u.side === 'player') st.playerEnded[k] = true;
  if (u.side === 'enemy') st.enemyEnded[k] = true;
  const mustEscape = (s.objectives?.victory ?? []).some(c => c.type === 'escape' && (c.unitIds ?? []).includes(u.id));
  if (mustEscape && (s.objectives?.extraction ?? []).includes(k)) {
    u.status = 'escaped';
    if (!st.escaped.includes(u.id)) st.escaped.push(u.id);
    removeFromTurn(s, u.id);
    log(s, u.name + ' escapes the battlefield.', { type: 'escaped', unit: u.id });
  }
}
/** Re-check every condition; once the battle is decided it ends (phase 'over'). */
function checkOutcome(s) {
  if (s.outcome || !BATTLE_PHASES.includes(s.turn.phase)) return;
  const ev = evaluateObjectives(s.objectives, s.units.map(u => ({ id: u.id, side: u.side, status: u.status })), objState(s),
    { burnt: s.siege?.burnt ?? {}, fires: s.siege?.fires ?? {} });
  s.objEval = ev;
  if (!ev.result) return;
  s.outcome = { result: ev.result, round: s.turn.round, at: Date.now() };
  log(s, ev.result === 'victory' ? 'Victory! Every victory condition is met.' : 'Defeat.', { type: 'outcome', result: ev.result });
  s.turn = freshTurn('over', s.turn.round);
}
function settleLoop(s, opts) {
  for (let guard = 0; guard < 50; guard++) {
    let changed = false;
    for (const u of liveUnits(s)) {
      let ended = null;
      if (u.men <= 0) { u.status = 'defeated'; ended = 'is destroyed'; }
      // Surrounded by Fear and Fanatic: never surrenders (it fights until destroyed)
      else if (u.morale <= 0 && !hasTactic(s, u, 'fear') && !trait(u, 'fanatic')) { u.status = 'surrendered'; ended = 'surrenders'; }
      if (!ended) continue;
      changed = true;
      log(s, u.name + ' ' + ended + '.', { type: 'defeat', unit: u.id });
      if (u.status === 'surrendered') surrenderTactics(s, u);
      if (carrying(u)) dropEquipment(s, u, ' falls, leaving its ');
      for (const tc of s.tactics ? s.tactics.placed : []) if (tc.key === 'fear' && tc.unitId === u.id && tc.state === 'active') tc.state = 'spent';
      removeFromTurn(s, u.id);
      // Levy: loses 5 morale when an adjacent ally surrenders or is destroyed (other units don't)
      for (const n of liveUnits(s)) {
        if (trait(n, 'levy') && friendly(n, u) && manhattan(n, u) === 1) {
          n.morale = clamp(n.morale - 5, 0, 100);
          log(s, n.name + ' loses 5 morale (Levy: adjacent ally ' + ended.replace('is ', '') + ').');
        }
      }
      // Plunderers (Xiongnu, David 2026-11-01): when an enemy unit within 3 squares surrenders or is destroyed, gain 3 x that unit's tier in morale
      const loot = 3 * (Number(typeOf(s, u)?.unitValue) || 1);
      for (const n of liveUnits(s)) {
        if (trait(n, 'plunderers') && !friendly(n, u) && manhattan(n, u) <= 3) {
          n.morale = clamp(n.morale + loot, 0, 100);
          log(s, n.name + ' gains ' + loot + ' morale (Plunderers: enemy ' + ended.replace('is ', '') + ' nearby).', { type: 'plunderers', unit: n.id, gain: loot });
        }
      }
    }
    // a normal (undoable) move waits: encirclement is only applied once the move is committed
    if (!opts.deferEncirclement && checkEncirclement(s)) changed = true;
    if (!changed) return;
  }
}

/** Surround the Enemy: a surrender in its square costs every enemy unit 5 morale (10 if it had an officer). */
function surrenderTactics(s, v) {
  const T = s.tactics; if (!T || T.phase !== 'battle') return;
  for (const tc of T.placed) {
    if (tc.key !== 'surround' || alliance(tc.side) === alliance(v.side) || !inTacticArea(tc, v)) continue;
    if (tc.state === 'hidden') triggerTactic(s, tc, null); else if (!tacticLive(s, tc)) continue;
    const n = v.officerId ? 10 : 5;
    for (const o of liveUnits(s)) if (alliance(o.side) !== alliance(tc.side)) o.morale = clamp(o.morale - n, 0, 100);
    log(s, 'Surround the Enemy: every enemy unit loses ' + n + ' morale.');
  }
}

/** Surrounded by Fear: the unit strikes its attackers for free until one of them is destroyed. */
function processFear(s) {
  const q = s._fearQueue; delete s._fearQueue;
  for (const id of q || []) {
    const u = unitById(s, id);
    for (let i = 0; i < 12 && u && alive(u); i++) {
      const foes = liveUnits(s).filter(o => hostile(o, u) && manhattan(o, u) === 1).sort((a, b) => a.men - b.men);
      if (!foes.length) break;
      resolveAttack(s, u, foes[0], { free: true, noTactics: true });
      if (!alive(foes[0])) {
        for (const tc of s.tactics.placed) if (tc.key === 'fear' && tc.unitId === u.id) tc.state = 'spent';
        log(s, u.name + ' breaks out: Surrounded by Fear ends.');
        break;
      }
    }
  }
}

/**
 * Surrounding (David, 2026-10-27): every side of the unit is an enemy unit or ground it couldn't step onto
 * (river, cliffs, walls from the ground, a locked gate...), with at least one enemy unit. Allied units and the
 * map edge break the ring. Stalwart units and units on forts, command tents or town halls can't be surrounded.
 * Returns { surrounded, enemies, blocked }.
 */
function surroundInfo(s, u) {
  const none = { surrounded: false, enemies: 0, blocked: 0 };
  if (trait(u, 'stalwart')) return none;
  const tr = tileRules(s, u.x, u.y);
  if (tr && tr.noSurround) return none;
  let enemies = 0, blocked = 0;
  for (const [dx, dy] of ORTHO) {
    const nx = u.x + dx, ny = u.y + dy;
    if (!inBounds(s, nx, ny)) return none;                 // the map edge never closes a ring
    const o = unitAt(s, nx, ny);
    if (o) { if (hostile(o, u)) { enemies++; continue; } return none; } // an ally next to it keeps the ring open
    if (terrainStep(s, u, u.x, u.y, nx, ny)) return none;  // open ground
    blocked++;
  }
  return { surrounded: enemies >= 1, enemies, blocked };
}

/** Keeps each unit's surrounded status up to date (the icon, and Surrounded by Fear). Morale is lost in surroundAfterTurn. */
function checkEncirclement(s) {
  for (const u of liveUnits(s)) {
    const now = surroundInfo(s, u).surrounded;
    if (now && !u.surrounded) {
      u.surrounded = true;
      if (fireTactics(s, 'surrounded', u).length) {
        log(s, u.name + ' is surrounded but will not surrender!');
        (s._fearQueue = s._fearQueue || []).push(u.id);
      }
    } else if (!now && u.surrounded) u.surrounded = false;
  }
  return false;
}

/**
 * When a unit ends its turn, each enemy unit next to it that is surrounded (or still surrounded) loses
 * 40 morale, 10 less per side closed by impassable ground. At most once per round per unit.
 */
function surroundAfterTurn(s, actor) {
  if (!actor) return;
  let hit = false;
  for (const v of liveUnits(s)) {
    if (!hostile(v, actor) || manhattan(v, actor) !== 1 || v.round.surroundedHit) continue;
    const info = surroundInfo(s, v);
    if (!info.surrounded) continue;
    v.round.surroundedHit = true;
    if (hasTactic(s, v, 'fear')) { log(s, v.name + ' is surrounded but will not surrender!'); continue; }
    if (passive(s, v).ignoreEncirclement) { log(s, v.name + ' is surrounded but its officer ignores the morale loss.'); continue; }
    const loss = Math.max(0, SURROUND_MORALE - SURROUND_PER_BLOCK * info.blocked);
    v.morale = clamp(v.morale - loss, 0, 100); hit = true;
    log(s, v.name + ' is surrounded' + (info.blocked ? ' (' + info.enemies + ' enemy unit' + (info.enemies === 1 ? '' : 's') + ', ' + info.blocked + ' side' + (info.blocked === 1 ? '' : 's') + ' blocked)' : ' on all four sides') + ': -' + loss + ' morale.', { type: 'surrounded', unit: v.id, loss });
  }
  if (hit) settle(s);
}

function removeFromTurn(s, id) {
  const t = s.turn;
  t.held = t.held.filter(x => x !== id);
  if (t.activation && t.activation.unitId === id) { t.activation = null; t.pendingFinish = id; }
}

// ---------------------------------------------------------------- turn system

function hasOfficer(u) { return !!u.officerId; }
function rankOf(s, id) { const i = s.turn.order.indexOf(id); return i < 0 ? Infinity : i; }

function rollInitiative(s) {
  const t = s.turn; t.init = {};
  const officers = liveUnits(s).filter(hasOfficer);
  for (const u of officers) {
    const o = officerOf(s, u); const d = yinYang();
    t.init[u.id] = { total: d.value + (o ? o.fire : 0), yin: d.yin, yang: d.yang, fire: o ? o.fire : 0, tiebreak: rng() };
  }
  const sideRank = u => (u.side === 'player' ? 0 : 1);
  officers.sort((a, b) => {
    const A = t.init[a.id], B = t.init[b.id];
    return (B.total - A.total) || (B.fire - A.fire) || (sideRank(a) - sideRank(b)) || (A.tiebreak - B.tiebreak);
  });
  t.order = officers.map(u => u.id);
  log(s, 'Round ' + t.round + ' initiative: ' + officers.map(u => u.name + ' ' + t.init[u.id].total).join(', ') +
    (officers.length ? '' : '(no officers)') + '.');
}

// What the game is waiting for right now.
// Returns { kind, unitId?, side?, rank } where kind is one of:
//  'setup' | 'start' | 'decide' (act/hold) | 'final' (act/forfeit) |
//  'claim' (player side officerless) | 'host-pick' (enemy/ally officerless) |
//  'pick' (claimer picks a unit) | 'activation' | 'idle'
function prompt(s) {
  const t = s.turn;
  if (t.phase === 'setup') return { kind: 'setup', rank: -1 };
  if (t.phase === 'tactics') return { kind: 'tactics', rank: -1 };
  if (t.phase === 'formations') t.phase = 'start'; // battles saved before formations were removed (2026-10-29)
  if (t.phase === 'start') return { kind: 'start', rank: -1 };
  if (t.phase === 'over') return { kind: 'over', rank: -1 }; // decided: victory or defeat
  if (t.activation) {
    const u = unitById(s, t.activation.unitId);
    return { kind: 'activation', unitId: t.activation.unitId, rank: hasOfficer(u) ? rankOf(s, u.id) : Infinity };
  }
  if (t.phase === 'officer') {
    const id = t.order.find(id => !t.decided.includes(id) && alive(unitById(s, id)));
    if (id !== undefined) return { kind: 'decide', unitId: id, rank: rankOf(s, id) };
    return { kind: 'idle', rank: Infinity };
  }
  if (t.phase === 'officerless') {
    const side = currentOfficerlessSide(s);
    if (!side) return { kind: 'idle', rank: Infinity };
    if (side === 'player') return t.claim ? { kind: 'pick', side, player: t.claim, rank: Infinity } : { kind: 'claim', side, rank: Infinity };
    return { kind: 'host-pick', side, rank: Infinity };
  }
  if (t.phase === 'final') {
    const id = finalQueue(s)[0];
    if (id !== undefined) return { kind: 'final', unitId: id, rank: rankOf(s, id) };
    return { kind: 'idle', rank: Infinity };
  }
  return { kind: 'idle', rank: Infinity };
}

function officerlessRemaining(s, side) {
  return liveUnits(s).filter(u => !hasOfficer(u) && u.side === side && !u.round.activated);
}
function currentOfficerlessSide(s) {
  for (let i = 0; i < SIDES.length; i++) {
    const side = SIDES[(s.turn.sideIdx + i) % SIDES.length];
    if (officerlessRemaining(s, side).length) return side;
  }
  return null;
}
function finalQueue(s) {
  // held officers, lowest initiative first
  return s.turn.held.filter(id => alive(unitById(s, id))).sort((a, b) => rankOf(s, b) - rankOf(s, a));
}

// Move the turn forward through empty phases.
function advance(s) {
  const t = s.turn;
  if (t.phase === 'over') return;
  for (let guard = 0; guard < 20; guard++) {
    if (t.activation) return;
    const p = prompt(s);
    if (p.kind !== 'idle') return;
    if (t.phase === 'officer') { t.phase = 'officerless'; t.sideIdx = 0; t.claim = null; log(s, 'Officer-less phase.'); continue; }
    if (t.phase === 'officerless') { t.phase = 'final'; if (t.held.length) log(s, 'Final pass for held officers.'); continue; }
    if (t.phase === 'final') { endRound(s); return; }
    return;
  }
}

function endRound(s) {
  const next = s.turn.round + 1;
  objState(s).roundsDone = s.turn.round; // rounds survived / held / used up
  burnRound(s); // fires burn down
  for (const u of s.units) u.facing = null; // every unit's facing clears when the round ends
  // Inspiration: at the end of the round, allied units next to it gain 2 morale; Inspiration+ 4 (David, 2026-10-28).
  // Traits of the same name don't stack (David, 2026-10-31): a unit next to several inspiring units gains once, the best.
  // Imperial Solidarity: allies within 2 tiles of another unit with it gain 4 morale (once, however many are near).
  for (const o of liveUnits(s)) {
    let best = 0, from = null;
    for (const u of liveUnits(s)) if (u !== o && friendly(o, u) && manhattan(o, u) === 1 && trait(u, 'inspiration')) {
      const g = tierVal(trait(u, 'inspiration'), [2, 4]); if (g > best) { best = g; from = u; }
    }
    if (best && o.morale < 100) { o.morale = Math.min(100, o.morale + best); log(s, o.name + ' gains ' + best + ' morale (Inspiration' + (best > 2 ? '+' : '') + ' from ' + from.name + ').'); }
    const imp = imperialAura(s, o);
    if (imp && o.morale < 100) { o.morale = Math.min(100, o.morale + 4); log(s, o.name + ' gains 4 morale (Imperial Solidarity from ' + imp.name + ').'); }
  }
  // Hiding: a unit in cover (forest, tall grass) at the end of the round hides, unless an enemy is next to it
  for (const u of liveUnits(s)) if (!u.hidden && hidesIn(s, u) && !hostileAdjacent(s, u) && !scoutNear(s, u)) {
    u.hidden = true;
    log(s, u.name + ' disappears into cover.', { type: 'hidden', unit: u.id });
  }
  log(s, 'Round ' + s.turn.round + ' ends.');
  for (const tc of s.tactics ? s.tactics.placed : []) if (tc.state === 'active' && tc.untilRound !== undefined && tc.untilRound < next) tc.state = 'spent';
  s.turn = freshTurn('start', next);
  // Hold lasts until the unit's next activation (David, 2026-10-27), so it carries over the round change
  for (const u of s.units) u.round = Object.assign(newRoundFlags(), { holding: !!(u.round && u.round.holding) });
  log(s, 'Round ' + next + ' begins.');
  checkOutcome(s); // rounds survived / time limits / holds
}

function startActivation(s, u, extra) {
  if (u.round && u.round.holding) u.round.holding = false; // Hold ends when the unit acts again
  if (u.fx && u.fx.shocked) { // shocked by a charge: no movement this activation
    delete u.fx.shocked; u.round.cannotMove = true;
    log(s, u.name + ' is shocked and cannot move this turn.', { type: 'shocked', unit: u.id });
  }
  if (u.overwatch) { delete u.overwatch; log(s, u.name + ' stands down from overwatch.', { type: 'overwatch', unit: u.id, on: false }); }
  s.turn.activation = Object.assign({ unitId: u.id, step: 'move', started: false, startedHidden: !!u.hidden,
    movedThisActivation: false, tilesMoved: 0, roughPath: false, forcedMarched: false, interject: false, from: { x: u.x, y: u.y } }, extra || {});
}

/** Tiles that count for a charge. Any cavalry that moved 2+ tiles and attacks charges, even if it started next to
 *  the target (David, 2026-10-30, for clarity; replaces the "no stepping out and back in" rule). */
function chargeTiles(ac, target) { // eslint-disable-line no-unused-vars
  if (ac.roughPath) return 0; // cavalry that rode across or onto rough ground get no charge
  return ac.tilesMoved || 0;
}

function finishActivation(s, u, opts) {
  const t = s.turn;
  // End-of-turn morale regen for units with an officer (up to 75), only on a turn the unit didn't fight
  const o = officerOf(s, u);
  if (o && alive(u) && u.morale < 75 && !u.round.attacked && !u.round.wasAttacked) {
    const before = u.morale;
    u.morale = Math.min(75, u.morale + o.fire + o.command);
    if (u.morale !== before) log(s, u.name + ' regains ' + (u.morale - before) + ' morale (officer Fire + Command).');
  }
  // terrain where it ends its turn: command tents and supply depots lift morale, fire burns
  const tr = alive(u) ? tileRules(s, u.x, u.y) : null;
  if (tr && (tr.moraleTurn || tr.healthTurn)) {
    if (tr.moraleTurn) u.morale = clamp(u.morale + tr.moraleTurn, 0, 100);
    if (tr.healthTurn) u.men = Math.max(0, u.men + tr.healthTurn);
    log(s, u.name + ' ends its turn on ' + tr.names.join(', ') + ':' + (tr.moraleTurn ? ' ' + (tr.moraleTurn > 0 ? '+' : '') + tr.moraleTurn + ' morale' : '') +
      (tr.healthTurn ? ' ' + tr.healthTurn + ' troops' : '') + '.');
  }
  rallyingBanner(s, u);
  if (alive(u)) {
    const f = fx(u);
    f.stillLast = !u.round.moved;                       // Shield Battery, Range Up: "ended its last turn without moving"
    delete f.slow;                                      // Barbed Arrows lasts one turn
  }
  // Stealth: ending the turn in a forest hides the unit; ending it next to a hostile unit reveals it
  if (alive(u)) {
    if (u.hidden && hostileAdjacent(s, u)) {
      u.hidden = false;
      log(s, u.name + ' is spotted (ended its turn next to an enemy).', { type: 'revealed', unit: u.id });
    } else if (u.hidden && !hidesIn(s, u)) { // left its cover: out in the open, it's seen
      u.hidden = false;
      log(s, u.name + ' leaves cover and is seen.', { type: 'revealed', unit: u.id });
    }
  } else u.hidden = false;
  scoutSweep(s); // Scouts: hidden enemies within 2 tiles of a scout are revealed
  // Suppressing Fire lasts until the end of the suppressed unit's next turn
  if (alive(u) && fx(u).suppressed) { delete fx(u).suppressed; }
  // Overwatch: enemy ranged units watching shoot a unit that ends its turn in their range
  if (alive(u)) overwatchFire(s, u);
  if (t.pendingFinish === u.id) t.pendingFinish = null;
  bookkeep(s, u);
  t.activation = null;
  if (alive(u)) log(s, u.name + ' ends its turn.');
  trackEndOfTurn(s, u); // seizing squares, escaping
  settle(s);
  if (alive(u)) surroundAfterTurn(s, u); // enemies it leaves surrounded lose morale
  if (!(opts && opts.noAdvance)) advance(s);
}

// Mark a unit's turn as used and move the rotation on.
function bookkeep(s, u) {
  const t = s.turn;
  u.round.activated = true;
  if (hasOfficer(u)) {
    if (!t.decided.includes(u.id)) t.decided.push(u.id);
    t.held = t.held.filter(x => x !== u.id);
  } else {
    t.sideIdx = (SIDES.indexOf(u.side) + 1) % SIDES.length;
    t.claim = null;
  }
}

// ---------------------------------------------------------------- actions

// actor: { id: playerId | 'host', host: bool }
function controls(s, actor, u) {
  if (!u) return false;
  if (actor.host) return true;
  return u.owner === actor.id;
}

const ok = (extra) => Object.assign({ ok: true }, extra || {});
const err = (error) => ({ ok: false, error });

function act(s, actor, a) {
  try {
    const fn = ACTIONS[a && a.type];
    if (!fn) return err('Unknown action');
    const hostOnly = HOST_ONLY.has(a.type);
    if (hostOnly && !actor.host) return err('Only the host can do that');
    if (s.duels && s.duels.pending && !DUEL_ACTIONS.has(a.type) && !actor.host) return err('Waiting for the duel to finish');
    // Take back: starting a unit's turn (Take turn, or Act for an officer) can be taken back until the unit does anything
    const starting = a.type === 'begin' || (a.type === 'decide' && a.choice === 'act');
    const snap = starting ? takeBackSnapshot(s) : null;
    const res = fn(s, actor, a) || ok();
    if (res.ok && s.turn.activation && a.type !== 'moveTo' && a.type !== 'undoMove') delete s.turn.activation.undo;
    if (res.ok && s.turn.activation && a.type !== 'takeBack') delete s.turn.activation.takeBack;
    if (res.ok && snap && s.turn.activation) s.turn.activation.takeBack = snap;
    // A unit that died during its own turn still hands the turn on.
    if (s.turn.pendingFinish) {
      const u = unitById(s, s.turn.pendingFinish); s.turn.pendingFinish = null;
      if (u) bookkeep(s, u);
      advance(s);
    }
    return res;
  } catch (e) {
    return err('Rules error: ' + e.message);
  }
}

/** What a Take back restores: everything the rules change, not the map or the library (too big, never changed by starting a turn). */
const TAKE_BACK_KEYS = ['units', 'turn', 'tactics', 'siege', 'objState', 'objEval', 'outcome'];
function takeBackSnapshot(s) {
  const o = {};
  for (const k of TAKE_BACK_KEYS) if (s[k] !== undefined) o[k] = JSON.parse(JSON.stringify(s[k]));
  return o;
}

const DUEL_ACTIONS = new Set(['duelAnswer', 'duelResult', 'duelCancel']);
const HOST_ONLY = new Set(['duelResult', 'duelCancel', 'triggerAllTactics', 'setGate', 'setHidden', 'setMap', 'paintTerrain', 'setLibrary', 'addUnit', 'editUnit', 'removeUnit',
  'startBattle', 'resetBattle', 'startRound', 'skipPrompt', 'addMod', 'removeMod', 'adjust', 'setFacing',
  'setTactician', 'finishTactics', 'skipTactics', 'declareOutcome']);

const ACTIONS = {
  // ---------- host / GM
  setMap(s, actor, a) {
    const m = s.map;
    for (const k of ['image', 'cols', 'rows', 'tile', 'offsetX', 'offsetY']) if (a[k] !== undefined) m[k] = a[k];
    m.cols = clamp(Math.round(m.cols) || 1, 1, 200); m.rows = clamp(Math.round(m.rows) || 1, 1, 200);
    m.tile = clamp(Number(m.tile) || 48, 8, 400);
  },
  paintTerrain(s, actor, a) {
    if (!data.TERRAIN[a.terrain]) return err('Unknown terrain');
    for (const [x, y] of a.cells || []) {
      if (!inBounds(s, x, y)) continue;
      if (a.terrain === 'flat') delete s.map.terrain[x + ',' + y]; else s.map.terrain[x + ',' + y] = a.terrain;
    }
  },
  setLibrary(s, actor, a) {
    if (!['unitTypes', 'officers'].includes(a.key) || !Array.isArray(a.data)) return err('Bad library data');
    for (const item of a.data) if (!item || typeof item.id !== 'string') return err('Every entry needs a string "id"');
    s.library[a.key] = a.data;
    log(s, 'Host updated the ' + a.key + ' library.');
  },
  addUnit(s, actor, a) {
    const t = s.library.unitTypes.find(x => x.id === a.typeId); if (!t) return err('Unknown unit type');
    if (a.officerId && !s.library.officers.find(o => o.id === a.officerId)) return err('Unknown officer');
    if (!SIDES.includes(a.side)) return err('Bad side');
    if (!inBounds(s, a.x, a.y) || unitAt(s, a.x, a.y)) return err('Tile is occupied or off the map');
    const o = a.officerId ? s.library.officers.find(o => o.id === a.officerId) : null;
    const u = {
      id: 'u' + s.nextUnitId++, typeId: t.id, officerId: a.officerId || null,
      name: a.name || (o ? o.name + "'s " : '') + t.name,
      side: a.side, owner: a.owner || null, x: a.x, y: a.y, men: 100,
      morale: a.morale !== undefined ? clamp(a.morale, 0, 100) : 50,
      facing: null, hidden: false,
      status: 'active', mods: [], heroicUsed: 0, lastHeroic: null, surrounded: false, round: newRoundFlags(),
    };
    s.units.push(u);
    log(s, 'Host placed ' + u.name + ' (' + u.side + ').');
    return ok({ unitId: u.id });
  },
  editUnit(s, actor, a) {
    const u = unitById(s, a.unitId); if (!u) return err('No such unit');
    const p = a.patch || {};
    for (const k of ['name', 'typeId', 'officerId', 'side', 'owner', 'men', 'morale', 'hidden', 'status']) {
      if (p[k] !== undefined) u[k] = p[k];
    }
    u.men = clamp(Number(u.men) || 0, 0, 999); u.morale = clamp(Number(u.morale) || 0, 0, 100);
    if (u.officerId === '') u.officerId = null;
    if (u.owner === '') u.owner = null;
    settle(s);
  },
  removeUnit(s, actor, a) {
    const i = s.units.findIndex(u => u.id === a.unitId); if (i < 0) return err('No such unit');
    removeFromTurn(s, a.unitId); s.turn.order = s.turn.order.filter(x => x !== a.unitId);
    log(s, 'Host removed ' + s.units[i].name + '.');
    s.units.splice(i, 1); advance(s);
  },
  adjust(s, actor, a) {
    const u = unitById(s, a.unitId); if (!u) return err('No such unit');
    if (a.men) u.men = clamp(u.men + a.men, 0, 999);
    if (a.morale) u.morale = clamp(u.morale + a.morale, 0, 100);
    log(s, 'Host adjusted ' + u.name + (a.men ? ' men ' + (a.men > 0 ? '+' : '') + a.men : '') +
      (a.morale ? ' morale ' + (a.morale > 0 ? '+' : '') + a.morale : '') + (a.reason ? ' (' + a.reason + ')' : '') + '.');
    settle(s);
  },
  addMod(s, actor, a) {
    const u = unitById(s, a.unitId); if (!u) return err('No such unit');
    u.mods.push({ id: 'm' + Date.now() + Math.floor(rng() * 1000), label: String(a.label || 'Modifier'), value: Number(a.value) || 0 });
    log(s, u.name + ' gains roll modifier ' + a.label + ' ' + (a.value > 0 ? '+' : '') + a.value + '.');
  },
  removeMod(s, actor, a) {
    const u = unitById(s, a.unitId); if (!u) return err('No such unit');
    u.mods = u.mods.filter(m => m.id !== a.modId);
  },
  setFacing(s, actor, a) {
    const u = unitById(s, a.unitId); if (!u) return err('No such unit');
    u.facing = { dx: sign(a.dx), dy: sign(a.dy) };
  },
  place(s, actor, a) { // sandbox placement: host any time; players their own units onto free deployment squares during the tactics phase
    const u = unitById(s, a.unitId); if (!u) return err('No such unit');
    if (!inBounds(s, a.x, a.y)) return err('Off the map');
    const o = unitAt(s, a.x, a.y);
    if (!actor.host) {
      if (!controls(s, actor, u)) return err('You can only place your own units');
      const chk = deployMoveCheck({ phase: s.turn.phase, isGM: false, zones: zoneSet(s.deployZones), occupied: !!(o && o !== u),
        vanguard: !!trait(u, 'vanguard'), enemies: liveUnits(s).filter(d => hostile(u, d)) }, a.x, a.y);
      if (!chk.ok) return err(chk.reason);
    }
    if (o && o !== u) return err('Tile occupied');
    u.x = a.x; u.y = a.y; settle(s);
  },
  startBattle(s) {
    if (s.turn.phase !== 'setup') return err('Battle already started');
    s.duels = freshDuels();
    // Tactics come first: before initiative or anything else
    s.turn = freshTurn('tactics', 1);
    s.tactics = { phase: 'setup', sides: { player: null, ally: null, enemy: null }, placed: [], nextId: 1 };
    for (const u of s.units) u.round = newRoundFlags();
    for (const u of s.units) u.facing = null; // no facing until a unit attacks or is attacked
    log(s, 'Battle begins. Tacticians, choose your tactics.');
    for (const u of s.units) { if (u.fx) delete u.fx.checkpoints; fx(u).checkpoints = Math.min(4, checkpointsPassed(u)); } // checkpoints already passed before the battle don't cost morale
    s.objState = freshObjState(); s.outcome = null; s.objEval = null;
    s.introAt = Date.now(); // every client plays the tour of the conditions once
    checkOutcome(s); // the tracker starts with every condition open
  },
  resetBattle(s) {
    s.turn = freshTurn('setup', 0);
    s.duels = freshDuels();
    s.tactics = null;
    s.objState = freshObjState(); s.outcome = null; s.objEval = null;
    for (const u of s.units) u.round = newRoundFlags();
    log(s, 'Host returned to setup.');
  },
  startRound(s, actor) {
    if (s.turn.phase === 'tactics') ACTIONS.finishTactics(s, actor); // starting the round ends the tactics phase as it stands
    if (s.turn.phase === 'formations') s.turn.phase = 'start'; // saved before formations were removed
    if (s.turn.phase !== 'start') return err('Not at the start of a round');
    s.turn.phase = 'officer'; s.turn.decided = []; s.turn.held = [];
    rollInitiative(s); advance(s);
  },
  gmSetFire(s, actor, a) { // GM test control: set any flammable square alight
    if (!actor.host) return err('Only the GM can start a fire');
    if (!inBounds(s, a.x, a.y)) return err('Off the map');
    if (!igniteTile(s, a.x, a.y, 'GM')) return err("That square can't burn, or is already burning");
    settle(s);
  },
  declareOutcome(s, actor, a) { // the GM ends the battle at once with a victory or a defeat
    if (!['victory', 'defeat', 'stalemate'].includes(a.result)) return err('Victory, defeat or stalemate?');
    if (s.outcome) return err('The battle is already over');
    if (!BATTLE_PHASES.includes(s.turn.phase)) return err('No battle is running');
    s.outcome = { result: a.result, round: s.turn.round, at: Date.now(), declared: true };
    log(s, { victory: 'Victory! The GM ends the battle.', defeat: 'Defeat. The GM ends the battle.', stalemate: 'Stalemate. The GM ends the battle.' }[a.result], { type: 'outcome', result: a.result });
    s.turn = freshTurn('over', s.turn.round);
  },
  skipPrompt(s) { // host safety valve: skip whoever the game is waiting on
    const p = prompt(s), t = s.turn;
    if (p.kind === 'activation') { const u = unitById(s, p.unitId); log(s, 'Host ended ' + u.name + "'s turn."); finishActivation(s, u); return; }
    if (p.kind === 'decide') { t.decided.push(p.unitId); t.held.push(p.unitId); log(s, 'Host made ' + unitById(s, p.unitId).name + ' hold.'); }
    else if (p.kind === 'final') { const u = unitById(s, p.unitId); u.round.activated = true; t.held = t.held.filter(x => x !== u.id); log(s, 'Host forfeited ' + u.name + "'s turn."); }
    else if (p.kind === 'claim' || p.kind === 'pick' || p.kind === 'host-pick') {
      for (const u of officerlessRemaining(s, p.side)) u.round.activated = true;
      t.claim = null; log(s, 'Host skipped the remaining ' + p.side + ' officer-less turns.');
    } else return err('Nothing to skip');
    advance(s);
  },

  // ---------- tactics phase (before the first round)
  setTactician(s, actor, a) { // a.tactician: { id, name, img, aow, kind: 'player'|'officer', userId } or null
    const T = s.tactics;
    if (!T || T.phase !== 'setup') return err('Tacticians are chosen before the battle starts');
    if (!TACTIC_SIDES.includes(a.side)) return err('Bad side');
    const tac = a.tactician || null;
    if (tac && a.side === 'player' && !(Number(tac.aow) >= 1)) return err(tac.name + ' has no Art of War, so cannot lead the player tactics');
    T.sides[a.side] = tac ? { id: tac.id, name: tac.name, img: tac.img || null, aow: Number(tac.aow) || 0, kind: tac.kind || 'officer', userId: tac.userId || null } : null;
    T.placed = T.placed.filter(p => p.side !== a.side); // a new tactician starts with a clean slate
  },
  placeTactic(s, actor, a) { // a: { side, key, x, y, id? (move an existing one), highGround? }
    const T = s.tactics;
    if (!T || T.phase !== 'setup') return err('Tactics are placed before the battle starts');
    if (!TACTIC_SIDES.includes(a.side)) return err('Bad side');
    const tac = T.sides[a.side], def = tacticDef(a.key);
    if (!def) return err('Unknown tactic');
    if (!tacticPlacer(s, actor, a.side)) return err('Only the tactician places these tactics');
    if (!inBounds(s, a.x, a.y)) return err('Off the map');
    const existing = a.id ? T.placed.find(p => p.id === a.id && p.side === a.side) : null;
    if (a.side === 'player' && !(actor.host && !tac)) { // the GM may place player tactics freely with no tactician (testing)
      if (!tac) return err('Choose a tactician first');
      if (def.aow > tac.aow) return err(def.name + ' needs Art of War ' + def.aow);
      const others = T.placed.filter(p => p.side === 'player' && p !== existing);
      if (others.length >= tac.aow + 1) return err('No tactics left to place (Art of War ' + tac.aow + ' + 1 = ' + (tac.aow + 1) + ')');
      if (others.some(p => p.key === a.key)) return err(def.name + ' is already placed');
    }
    if (def.highGround && !a.highGround) return err(def.name + ' must be placed on high ground (hill, city wall, fort or command tent)');
    if (existing) { existing.x = a.x; existing.y = a.y; return ok({ tacticId: existing.id }); }
    const id = 't' + T.nextId++;
    T.placed.push({ id, key: a.key, side: a.side, x: a.x, y: a.y, size: def.size, state: 'hidden', tactician: tac ? tac.name : null });
    return ok({ tacticId: id });
  },
  removeTactic(s, actor, a) {
    const T = s.tactics;
    if (!T || T.phase !== 'setup') return err('Tactics are placed before the battle starts');
    const p = T.placed.find(x => x.id === a.id); if (!p) return err('No such tactic');
    if (!tacticPlacer(s, actor, p.side)) return err('Only the tactician places these tactics');
    T.placed = T.placed.filter(x => x !== p);
  },
  finishTactics(s) {
    const T = s.tactics;
    if (s.turn.phase !== 'tactics' || !T) return err('Not in the tactics phase');
    T.phase = 'battle';
    s.turn.phase = 'start';
    const n = T.placed.length;
    log(s, n ? n + ' tactic' + (n === 1 ? ' is' : 's are') + ' set. Round 1 is ready to start.' : 'No tactics placed. Round 1 is ready to start.');
  },
  skipTactics(s) {
    const T = s.tactics;
    if (s.turn.phase !== 'tactics' || !T) return err('Not in the tactics phase');
    T.placed = []; T.phase = 'battle';
    s.turn.phase = 'start';
    log(s, 'Tactics skipped. Round 1 is ready to start.');
  },

  // ---------- GM: set off every tactic still waiting, now
  // Area tactics take effect for their duration; tactics tied to one unit go to the side's unit nearest the
  // centre of the area; Brutalize and Inspiring the Army take effect at once. Raise Flag and Set Aflame stay
  // waiting: they are used by taking their action.
  triggerAllTactics(s) {
    const T = s.tactics;
    if (!T || T.phase !== 'battle') return err('Tactics can be set off once the battle has started');
    const waiting = T.placed.filter(t => t.state === 'hidden' && !['raiseFlag', 'setAflame'].includes(t.key));
    if (!waiting.length) return err('No tactics are waiting to be set off');
    for (const t of waiting) {
      const def = tacticDef(t.key);
      const holder = def.bound ? liveUnits(s).filter(u => u.side === t.side && inTacticArea(t, u))
        .sort((a, b) => manhattan(a, t) - manhattan(b, t))[0] || null : null;
      triggerTactic(s, t, holder);
      if (t.key === 'brutalize') {
        for (const o of liveUnits(s)) if (o.men > 0 && alliance(o.side) !== alliance(t.side) && inTacticArea(t, o)) o.morale = clamp(o.morale - 25, 0, 100);
        log(s, 'Brutalize: enemy units in the area lose 25 morale.');
      } else if (t.key === 'inspiring') {
        for (const o of liveUnits(s)) if (o.men > 0 && o.side === t.side) o.morale = clamp(o.morale + 25, 0, 100);
        log(s, 'Inspiring the Army: every ' + SIDE_LABEL[t.side].toLowerCase() + ' unit gains 25 morale.');
      } else if (def.bound && !holder) log(s, def.name + ': no ' + SIDE_LABEL[t.side].toLowerCase() + ' unit in its area to take it.');
    }
    log(s, 'The GM sets off every waiting tactic.');
    settle(s);
  },

  // ---------- GM: hide or reveal a unit (abilities, landmarks, rulings)
  setHidden(s, actor, a) {
    const u = unitById(s, a.unitId);
    if (!u || !alive(u)) return err('No such unit');
    u.hidden = !!a.hidden;
    log(s, u.name + (u.hidden ? ' is now hidden.' : ' is revealed.'), { type: u.hidden ? 'hidden' : 'revealed', unit: u.id });
  },

  // ---------- turn order
  decide(s, actor, a) {
    const p = prompt(s), t = s.turn, u = unitById(s, a.unitId);
    if (!controls(s, actor, u)) return err('Not your unit');
    if (p.kind === 'decide' && p.unitId === u.id) {
      if (a.choice === 'act') { startActivation(s, u); return; }
      if (a.choice === 'hold') { t.decided.push(u.id); t.held.push(u.id); log(s, u.name + ' holds its turn.'); advance(s); return; }
    }
    if (p.kind === 'final' && p.unitId === u.id) {
      if (a.choice === 'act') { startActivation(s, u); return; }
      if (a.choice === 'forfeit') { u.round.activated = true; t.held = t.held.filter(x => x !== u.id); log(s, u.name + ' gives up its turn.'); advance(s); return; }
    }
    return err("It isn't that unit's decision right now");
  },
  takeBack(s, actor, a) { // undo Take turn / Act before the unit has done anything
    const ac = s.turn.activation, u = ac && unitById(s, ac.unitId);
    if (!ac || !ac.takeBack || (a.unitId && a.unitId !== ac.unitId)) return err('This turn can no longer be taken back');
    if (!controls(s, actor, u)) return err('Not your unit');
    const snap = ac.takeBack;
    for (const k of TAKE_BACK_KEYS) if (snap[k] !== undefined) s[k] = snap[k];
    log(s, u.name + ': turn taken back.');
  },
  claim(s, actor) {
    const p = prompt(s);
    if (p.kind !== 'claim') return err('No player-side turn to claim right now');
    const mine = officerlessRemaining(s, 'player').filter(u => controls(s, { id: actor.id, host: false }, u) || (actor.host && !u.owner));
    if (!mine.length) return err('You have no officer-less units left to move');
    s.turn.claim = actor.id;
    log(s, (actor.host ? 'Host' : (s.players[actor.id] || {}).name || 'A player') + ' claims the player-side turn.');
  },
  begin(s, actor, a) { // pick which officer-less unit takes the turn
    let p = prompt(s); const u = unitById(s, a.unitId);
    if (!u || hasOfficer(u) || u.round.activated || !alive(u)) return err('Pick an officer-less unit that has not acted');
    // the player-side turn goes to whoever takes a turn with one of their units first (no separate claim)
    if (p.kind === 'claim' && u.side === 'player' && (u.owner === actor.id || (actor.host && !u.owner))) {
      s.turn.claim = actor.id;
      p = prompt(s);
    }
    if (p.kind === 'pick') {
      if (actor.id !== s.turn.claim) return err('Another player claimed this turn');
      if (u.side !== 'player' || !(u.owner === actor.id || (actor.host && !u.owner))) return err('Pick one of your own units');
    } else if (p.kind === 'host-pick') {
      if (!actor.host) return err('The host moves ' + p.side + ' units');
      if (u.side !== p.side) return err('It is the ' + p.side + " side's turn");
    } else return err('Not an officer-less turn');
    startActivation(s, u);
  },
  interject(s, actor, a) {
    const t = s.turn, u = unitById(s, a.unitId);
    if (!controls(s, actor, u)) return err('Not your unit');
    if (!t.held.includes(u.id) || u.round.activated) return err('Only a held officer can interject');
    if (t.activation && t.activation.started) return err('Wait until the current unit finishes its turn');
    const p = prompt(s);
    if (!['decide', 'final', 'claim', 'pick', 'host-pick', 'activation'].includes(p.kind)) return err('Nothing to interject before');
    if (!(rankOf(s, u.id) < p.rank)) return err(u.name + ' does not have higher initiative than the unit about to act');
    if (t.activation) { // the unit about to act hasn't started: it waits
      const waiting = unitById(s, t.activation.unitId);
      if (t.activation.interject) { t.held.push(waiting.id); }
      t.activation = null;
      log(s, waiting.name + ' waits.');
    }
    t.held = t.held.filter(x => x !== u.id);
    log(s, u.name + ' interjects!');
    startActivation(s, u, { interject: true });
  },

  // ---------- officer duels
  duel(s, actor, a) {
    const r = activeUnit(s, actor, a.unitId); if (r.error) return r;
    const { u, act: ac } = r;
    if (u.round.attacked || ac.forcedMarched) return err('Already acted this turn');
    const d = unitById(s, a.targetId);
    if (!d || !duelTargets(s, u).includes(d)) return err("Can't challenge that unit");
    const D = duels(s);
    if (D.pending) return err('A duel is already under way');
    u.round.attacked = true; ac.started = true; ac.step = 'duel';
    D.pending = { from: u.id, to: d.id, stage: 'asked', round: s.turn.round };
    const on = officerOf(s, u), dn = officerOf(s, d);
    log(s, (on ? on.name : u.name) + ' challenges ' + (dn ? dn.name : d.name) + ' to a duel!', { type: 'duel', stage: 'asked', from: u.id, to: d.id });
  },
  duelAnswer(s, actor, a) {
    const D = duels(s), p = D.pending;
    if (!p || p.stage !== 'asked') return err('No duel is waiting for an answer');
    const u = unitById(s, p.from), d = unitById(s, p.to);
    if (!controls(s, actor, d)) return err('Only the challenged side can answer');
    const dn = officerOf(s, d);
    if (!a.accept) {
      d.morale = clamp(d.morale - DUEL_REFUSE_MORALE, 0, 100);
      D.refused.push(d.id);
      D.pending = null;
      log(s, (dn ? dn.name : d.name) + ' refuses the duel: ' + d.name + ' loses ' + DUEL_REFUSE_MORALE + ' morale, and no one can challenge it again this battle.', { type: 'duel', stage: 'refused', from: p.from, to: p.to });
      settle(s);
      if (alive(u) && s.turn.activation && s.turn.activation.unitId === u.id) finishActivation(s, u);
      return;
    }
    p.stage = 'fighting';
    log(s, (dn ? dn.name : d.name) + ' accepts the duel!', { type: 'duel', stage: 'accepted', from: p.from, to: p.to });
  },
  /** The duel's outcome: Breath of Life levels each officer dropped, and whether either died. */
  duelResult(s, actor, a) {
    const D = duels(s), p = D.pending;
    if (!p || p.stage !== 'fighting') return err('No duel is being fought');
    const u = unitById(s, p.from), d = unitById(s, p.to);
    const on = officerOf(s, u), dn = officerOf(s, d);
    const name = (unit, o) => (o ? o.name : unit.name);
    const shift = (unit, n, why) => { if (!n || !unit) return; unit.morale = clamp(unit.morale + n, 0, 100); log(s, unit.name + ' ' + (n > 0 ? 'gains ' : 'loses ') + Math.abs(n) + ' morale (' + why + ').', { type: 'duel', stage: 'morale', unit: unit.id, change: n }); };
    const fromDead = !!a.fromDead, toDead = !!a.toDead;
    if (fromDead || toDead) {
      if (fromDead) { shift(u, -DUEL_DEATH_MORALE, name(u, on) + ' fell in the duel'); u.officerId = null; }
      if (toDead) { shift(d, -DUEL_DEATH_MORALE, name(d, dn) + ' fell in the duel'); d.officerId = null; }
      if (fromDead && !toDead) shift(d, DUEL_KILL_MORALE, name(d, dn) + ' slew ' + name(u, on));
      if (toDead && !fromDead) shift(u, DUEL_KILL_MORALE, name(u, on) + ' slew ' + name(d, dn));
    } else {
      const f = Math.max(0, a.fromDrop || 0), t = Math.max(0, a.toDrop || 0);
      if (f === t) log(s, 'The duel ends even: ' + name(u, on) + ' and ' + name(d, dn) + ' part with neither gaining the upper hand.', { type: 'duel', stage: 'even', from: p.from, to: p.to });
      else {
        const [win, wo, lose, lo] = f < t ? [u, on, d, dn] : [d, dn, u, on];
        log(s, name(win, wo) + ' wins the duel against ' + name(lose, lo) + '.', { type: 'duel', stage: 'won', winner: win.id, loser: lose.id });
        shift(lose, -DUEL_LOSE_MORALE, 'lost the duel');
        shift(win, DUEL_WIN_MORALE, 'won the duel');
      }
    }
    D.pending = null;
    settle(s);
    if (u && alive(u) && s.turn.activation && s.turn.activation.unitId === u.id) finishActivation(s, u);
  },
  /** The GM calls the duel off: nobody gains or loses anything; the challenger's turn ends. */
  duelCancel(s) {
    const D = duels(s), p = D.pending;
    if (!p) return err('No duel to cancel');
    D.pending = null;
    log(s, 'The duel is called off.', { type: 'duel', stage: 'cancelled' });
    const u = unitById(s, p.from);
    if (u && alive(u) && s.turn.activation && s.turn.activation.unitId === u.id) finishActivation(s, u);
  },

  // ---------- activation steps
  move(s, actor, a) { return doMove(s, actor, a, false); },
  moveTo(s, actor, a) { // click-to-move: blue tile = move, red tile = forced march (ends the turn)
    const r = activeUnit(s, actor, a.unitId); if (r.error) return r;
    const { u, act: ac } = r;
    const k = a.x + ',' + a.y;
    const { blue, red, climb, rough } = moveOptions(s, u);
    const forced = !blue.has(k) && red.has(k);
    if (!blue.has(k) && !forced) return err("Can't move there");
    const from = { x: u.x, y: u.y };
    const prevFacing = u.facing ? { ...u.facing } : null, prevHidden = !!u.hidden, prevStarted = !!ac.started, prevCarry = carrying(u);
    // Backs Turned: enemies it leaves behind may strike it as it goes
    const struck = backsTurned(s, u, { x: a.x, y: a.y });
    if (!alive(u)) return;
    if (forced) fireTactics(s, 'forcedMarch', u);
    u.x = a.x; u.y = a.y; u.round.moved = true;
    ac.started = true; ac.movedThisActivation = true; ac.step = 'act';
    revealAround(s, u);
    if (heroOfficer(s, u)) fireTactics(s, 'heroMove', u);
    if (forced) {
      const { cost, dist } = red.get(k);
      ac.forcedMarched = true;
      u.morale = clamp(u.morale - cost, 0, 100);
      log(s, u.name + ' force-marches ' + dist + ' tiles (-' + cost + ' morale).');
      settle(s);
      if (alive(u)) finishActivation(s, u);
      return;
    }
    ac.tilesMoved = blue.get(k); ac.roughPath = rough.has(k);
    if (climb && climb.has(k)) {
      ac.tilesMoved = 0; // climbing is no charge, and can't be taken back
      log(s, u.name + ' climbs the ladder onto the wall.', { type: 'climb', unit: u.id });
      settle(s);
      return;
    }
    if (!struck) ac.undo = { from, facing: prevFacing, hidden: prevHidden, started: prevStarted };
    log(s, u.name + ' moves ' + blue.get(k) + ' tile' + (blue.get(k) === 1 ? '' : 's') + '.');

    settle(s, { deferEncirclement: true });
  },
  undoMove(s, actor, a) { // only a normal (blue) move, and only if nothing else happened since
    const r = activeUnit(s, actor, a.unitId); if (r.error) return r;
    const { u, act: ac } = r;
    if (!ac.undo) return err('Nothing to undo');
    if (unitAt(s, ac.undo.from.x, ac.undo.from.y) && unitAt(s, ac.undo.from.x, ac.undo.from.y) !== u) return err('Its old tile is taken');
    u.x = ac.undo.from.x; u.y = ac.undo.from.y; u.facing = ac.undo.facing; u.hidden = ac.undo.hidden;
    u.round.moved = false; ac.step = 'move'; ac.movedThisActivation = false; ac.tilesMoved = 0; ac.roughPath = false; ac.started = ac.undo.started;
    delete ac.undo;
    log(s, u.name + ' takes back its move.');
  },
  forcedMarch(s, actor, a) { return doMove(s, actor, a, true); },
  skipMove(s, actor, a) {
    const r = activeUnit(s, actor, a.unitId); if (r.error) return r;
    if (r.act.step !== 'move') return err('Already past movement');
    r.act.step = 'act'; r.act.started = true;
  },
  swap(s, actor, a) {
    const r = activeUnit(s, actor, a.unitId); if (r.error) return r;
    const { u, act: ac } = r; const o = unitById(s, a.targetId);
    if (ac.step !== 'move') return err('Swapping replaces movement');
    if (!o || !alive(o) || !friendly(u, o) || manhattan(u, o) !== 1) return err('Pick an adjacent allied unit');
    if (u.round.moved || o.round.moved) return err('Both units must not have moved this round');
    [u.x, o.x] = [o.x, u.x]; [u.y, o.y] = [o.y, u.y];
    u.round.moved = o.round.moved = true; u.round.cannotMove = o.round.cannotMove = true;
    ac.step = 'act'; ac.started = true;
    log(s, u.name + ' swaps places with ' + o.name + '.');
    revealAround(s, u); revealAround(s, o);
    settle(s);
  },
  overwatch(s, actor, a) { // ranged: end the turn, and shoot the first enemy that ends its turn in range before its next turn
    const r = activeUnit(s, actor, a.unitId); if (r.error) return r;
    const { u, act: ac } = r;
    if (typeOf(s, u).weapon !== 'ranged') return err('Only ranged units can overwatch');
    if (u.round.attacked || ac.forcedMarched) return err('Too late to overwatch this turn');
    if (fx(u).reload) return err('Reload first');
    u.overwatch = true;
    log(s, u.name + ' takes up overwatch.', { type: 'overwatch', unit: u.id, on: true });
    finishActivation(s, u);
  },
  outrider(s, actor, a) { // Outrider: after moving, ride on 1 tile (Outrider+ 2) instead of attacking; ends the turn after
    const r = activeUnit(s, actor, a.unitId); if (r.error) return r;
    const { u, act: ac } = r;
    if (!trait(u, 'outrider')) return err('Only Outrider units can ride on');
    if (!ac.movedThisActivation) return err('Outrider rides on after a move');
    if (u.round.attacked || ac.forcedMarched || ac.outrode) return err('Too late to ride on this turn');
    const tiles = outriderTiles(s, u);
    if (!tiles.length) return err('No empty tile to ride on to');
    settle(s); // riding on commits the first move
    if (!alive(u)) return;
    delete ac.undo;
    ac.outrode = true; u.round.attacked = true; // instead of attacking
    ac.step = 'reposition'; ac.reposition = { skirmish: true, outrider: true, tiles };
    log(s, u.name + ' may ride on: move up to ' + (trait(u, 'outrider') >= 2 ? 2 : 1) + ' more tile' + (trait(u, 'outrider') >= 2 ? 's' : '') + '.');
  },
  holdPosition(s, actor, a) {
    const r = activeUnit(s, actor, a.unitId); if (r.error) return r;
    if (r.u.round.attacked || r.act.forcedMarched) return err('Too late to hold this turn');
    r.u.round.holding = true;
    log(s, r.u.name + ' holds position (+1 melee defense until its next turn).');
    for (const tc of fireTactics(s, 'hold', r.u)) tc.anchor = r.u.id; // Hold the Line: this unit and adjacent holders
    finishActivation(s, r.u);
  },
  attack(s, actor, a) {
    const r = activeUnit(s, actor, a.unitId); if (r.error) return r;
    const { u, act: ac } = r; const d = unitById(s, a.targetId);
    if (ac.forcedMarched) return err('A forced march replaces the attack');
    if (u.round.attacked) return err('Already attacked');
    if (fx(u).reload) return err('This unit must reload before it can attack again');
    if (!d || !alive(d) || !hostile(u, d)) return err('Pick an enemy unit');
    if (!visibleTo(s, d, alliance(u.side))) return err('You cannot see that unit');
    if (!rangeOk(s, u, d)) return err('Target out of range');
    // attacking commits the move: apply any encirclement it caused first
    settle(s);
    if (!alive(d)) { log(s, d.name + ' gave up before the attack landed.'); if (alive(u)) finishActivation(s, u); return; }
    ac.lastTargetId = d.id; // Hit and Fade rides away from this unit
    const res = resolveAttack(s, u, d, { movedThisActivation: ac.movedThisActivation, tilesMoved: chargeTiles(ac, d), ambush: !!u.hidden });
    if (!alive(u)) return;
    // Clear a Path: destroying an enemy after moving lets the unit move and attack again
    if (res && res.killedBy === u.id && ac.movedThisActivation && hasTactic(s, u, 'clearPath')) {
      u.round.attacked = false; u.round.moved = false;
      Object.assign(ac, { step: 'move', movedThisActivation: false, tilesMoved: 0, roughPath: false, forcedMarched: false, from: { x: u.x, y: u.y } }); // a fresh move: it may charge again
      log(s, u.name + ' clears a path: it may move and attack again.');
      return;
    }
    if (offerSecond(s, u, ac, d, res.winner === 'attacker', !res.ranged)) return;
    endAfterAttack(s, u, ac);
  },
  secondAttack(s, actor, a) { // Dual Weapons follow-up: attack one of the offered enemies, or skip (no targetId)
    const r = activeUnit(s, actor, a.unitId); if (r.error) return r;
    const { u, act: ac } = r;
    if (ac.step !== 'second' || !ac.second) return err('No second attack available');
    const kind = ac.second.kind || 'dual';
    let won = false, melee = true, target = null;
    if (a.targetId) {
      if (!ac.second.targets.includes(a.targetId)) return err('Pick one of the marked enemies');
      target = unitById(s, a.targetId);
      if (target && alive(target)) {
        const res = resolveAttack(s, u, target, kind === 'phoenix'
          ? { phoenixWon: !!ac.second.won, movedThisActivation: ac.movedThisActivation, tilesMoved: chargeTiles(ac, target) }
          : { second: true, movedThisActivation: ac.movedThisActivation, tilesMoved: chargeTiles(ac, target) });
        won = res.winner === 'attacker'; melee = !res.ranged;
      }
    }
    delete ac.second;
    if (kind === 'dual') ac.dualDone = true;
    if (alive(u) && kind === 'dual' && offerSecond(s, u, ac, target, won, melee)) return;
    if (alive(u)) endAfterAttack(s, u, ac);
  },
  reposition(s, actor, a) { // Wedge follow-up: pick one of the offered tiles, or stay (no x/y)
    const r = activeUnit(s, actor, a.unitId); if (r.error) return r;
    const { u, act: ac } = r;
    if (ac.step !== 'reposition' || !ac.reposition) return err('Nothing to reposition');
    if (a.x !== undefined && a.y !== undefined) {
      if (!ac.reposition.tiles.some(([x, y]) => x === a.x && y === a.y)) return err('Pick one of the marked tiles');
      u.x = a.x; u.y = a.y;
      log(s, u.name + (ac.reposition.outrider ? ' rides on.' : ac.reposition.fade ? ' fades away.' : ac.reposition.skirmish ? ' skirmishes back.' : ' moves up beside the enemy.'));
      revealAround(s, u);
    }
    const { targetId, won, melee, skirmish } = ac.reposition;
    delete ac.reposition;
    if (skirmish) { settle(s); if (alive(u)) finishActivation(s, u); return; }
    // Wedge + Dual Weapons (or Fury of a Phoenix): after moving up, the next attack comes from the new tile
    if (offerSecond(s, u, ac, unitById(s, targetId), won, melee !== false)) return;
    endAfterAttack(s, u, ac);
  },
  reload(s, actor, a) { // Reload trait: reloads the weapon; allowed after moving, ends the turn
    const r = activeUnit(s, actor, a.unitId); if (r.error) return r;
    const { u } = r;
    if (!fx(u).reload) return err('Nothing to reload');
    if (u.round.attacked) return err('Already attacked this turn');
    delete fx(u).reload;
    log(s, u.name + ' reloads.');
    finishActivation(s, u);
  },
  placeLadder(s, actor, a) { // Siege Ladders: set a ladder against an adjacent city wall square; ends the turn
    const r = activeUnit(s, actor, a.unitId); if (r.error) return r;
    const { u, act: ac } = r;
    if (u.round.attacked || ac.forcedMarched) return err('Placing a ladder is the unit\'s action for the turn');
    if (carrying(u) !== 'ladders') return err('This unit has no siege ladders');
    if (!ladderTiles(s, u).some(([x, y]) => x === a.x && y === a.y)) return err('Pick a city wall square next to the unit without a ladder');
    siegeState(s).ladders.push(a.x + ',' + a.y);
    u.carry = null; // the ladders are up
    u.round.attacked = true;
    log(s, u.name + ' sets ladders against the wall.', { type: 'ladder', x: a.x, y: a.y });
    finishActivation(s, u);
  },
  pickUpEquipment(s, actor, a) { // the unit's action: take up equipment lying on its square (empty-handed); ends the turn
    const r = activeUnit(s, actor, a.unitId); if (r.error) return r;
    const { u, act: ac } = r;
    if (u.round.attacked || ac.forcedMarched) return err('Picking up equipment is the unit\'s action for the turn');
    if (carrying(u)) return err('This unit already carries siege equipment');
    if (!(s.siege && s.siege.dropped.some(d => d.x === u.x && d.y === u.y))) return err('Nothing to pick up here');
    pickUpEquipment(s, u);
    u.round.attacked = true;
    finishActivation(s, u);
  },
  openGate(s, actor, a) { return gateAction(s, actor, a, 'open'); },
  closeGate(s, actor, a) { return gateAction(s, actor, a, 'locked'); },
  setGate(s, actor, a) { // GM: who owns a gate, and its state (locked, open, broken, burned)
    const g = s.siege && s.siege.gates.find(x => x.id === a.gateId); if (!g) return err('No such gate');
    if (a.owner) { if (!['friendly', 'enemy'].includes(a.owner)) return err('Bad owner'); g.owner = a.owner; }
    if (a.state) { if (!['locked', 'open', 'broken', 'burned'].includes(a.state)) return err('Bad state'); g.state = a.state; }
    log(s, 'GM: gate ' + g.id + ' is ' + g.state + ' (' + g.owner + ').', { type: 'gate', gate: g.id, state: g.state });
    settle(s);
  },
  reinvigorate(s, actor, a) { // War Horn: an adjacent ally that has acted takes another turn at once; this unit's turn ends
    const r = activeUnit(s, actor, a.unitId); if (r.error) return r;
    const { u, act: ac } = r;
    if (u.round.attacked || ac.forcedMarched) return err('Sounding the horn replaces the attack');
    if (!hornReady(s, u)) return err('The war horn is still recharging');
    const targets = hornTargets(s, u);
    const target = targets.find(o => o.id === a.targetId) || (targets.length === 1 ? targets[0] : null);
    if (!target) return err(targets.length ? 'Pick which adjacent ally to reinvigorate' : 'No adjacent ally has taken its turn yet');
    fx(u).hornRound = s.turn.round;
    log(s, u.name + ' sounds the war horn: ' + target.name + ' is reinvigorated and acts again!', { type: 'reinvigorate', unit: u.id, target: target.id });
    u.round.attacked = true;
    finishActivation(s, u, { noAdvance: true }); // the round must not roll over before the ally's extra turn
    if (s.turn.phase === 'over' || !alive(target)) { advance(s); return; }
    // a fresh turn for the ally, right now
    target.round = Object.assign(newRoundFlags(), { wasAttacked: target.round.wasAttacked });
    startActivation(s, target, { interject: true });
  },
  dropEquipment(s, actor, a) { // free: put down siege ladders or a siege engine on the unit's square
    const r = activeUnit(s, actor, a.unitId); if (r.error) return r;
    if (!carrying(r.u)) return err('Nothing to drop');
    dropEquipment(s, r.u);
  },
  raiseFlag(s, actor, a) { // Raise Flag tactic: instead of attacking, from the tactic's centre tile
    const r = activeUnit(s, actor, a.unitId); if (r.error) return r;
    const { u, act: ac } = r;
    if (u.round.attacked || ac.forcedMarched) return err('Raising the flag replaces the attack');
    const fired = fireTactics(s, 'raiseFlag', u);
    if (!fired.length) return err('No Raise Flag tactic on this tile');
    for (const tc of fired) {
      const reach = tacticDef(tc.key).reach ?? tc.size; // the flag stands on one tile; its rally covers a wider square
      for (const o of liveUnits(s)) if (o.side === tc.side && Math.abs(o.x - tc.x) <= reach && Math.abs(o.y - tc.y) <= reach && o.morale < 50) o.morale = 50;
    }
    log(s, u.name + ' raises the flag: allied units around it below 50 morale rally to 50.');
    u.round.attacked = true;
    finishActivation(s, u);
  },
  setFire(s, actor, a) { // Set Aflame tactic: instead of attacking, set an adjacent flammable tile alight
    const r = activeUnit(s, actor, a.unitId); if (r.error) return r;
    const { u, act: ac } = r;
    if (u.round.attacked || ac.forcedMarched) return err('Setting a fire replaces the attack');
    if (Math.abs(a.x - u.x) + Math.abs(a.y - u.y) !== 1) return err('Pick a tile next to the unit');
    if (!burnInfo(s, a.x, a.y) || s.siege?.fires?.[a.x + ',' + a.y]) return err("That tile can't catch fire");
    if (!fireTactics(s, 'setFire', u).length) return err('No Set Aflame tactic covers this unit');
    igniteTile(s, a.x, a.y, u.name + ' (Set Aflame)');
    u.round.attacked = true;
    finishActivation(s, u);
  },
  endTurn(s, actor, a) {
    const r = activeUnit(s, actor, a.unitId); if (r.error) return r;
    finishActivation(s, r.u);
  },
  useSkill(s, actor, a) {
    const r = activeUnit(s, actor, a.unitId); if (r.error) return r;
    const o = officerOf(s, r.u); if (!o || !o.skill) return err('No officer skill');
    const chk = skillCheck(s, r.u, o); if (!chk.ok) return err(chk.reason);
    const cost = Number(o.skill.moraleCost) || 0;
    r.u.morale -= cost; r.u.round.skillUsed = true; r.u.skillLastRound = (s.turn && s.turn.round) || 0; r.act.started = true;
    log(s, r.u.name + ' uses ' + o.skill.name + (cost ? ' (-' + cost + ' morale)' : '') + ': ' + o.skill.text, { type: 'skill' });
    settle(s);
  },
  heroic(s, actor, a) {
    if (!HEROIC_ENABLED) return err('Heroic actions are not used in battles for now');
    const r = activeUnit(s, actor, a.unitId); if (r.error) return r;
    const o = officerOf(s, r.u); const h = o && o.heroicActions && o.heroicActions[a.index];
    if (!h) return err('No such heroic action');
    if (r.u.heroicUsed >= o.fire) return err('No heroic actions left (limit = Fire ' + o.fire + ')');
    if (r.u.round.heroicUsed) return err('Only one heroic action per turn');
    if (r.u.lastHeroic === h.name) return err("Can't use the same heroic action twice in a row");
    r.u.heroicUsed++; r.u.lastHeroic = h.name; r.u.round.heroicUsed = true; r.act.started = true;
    log(s, r.u.name + ' heroic action: ' + h.name + ' (' + r.u.heroicUsed + '/' + o.fire + '). ' + (h.text || ''), { type: 'heroic' });
    fireTactics(s, 'heroic', r.u);
  },
  battleArt(s, actor, a) {
    const r = activeUnit(s, actor, a.unitId); if (r.error) return r;
    const o = officerOf(s, r.u); if (!o || !o.battleArt) return err('No battle art');
    if (moraleState(r.u.morale) !== 'Encouraged') return err('Battle arts need Encouraged morale (75+)');
    if (r.u.round.skillUsed) return err('Officer skill already used this turn');
    r.u.round.skillUsed = true; r.act.started = true;
    log(s, r.u.name + ' battle art: ' + o.battleArt.name + '. ' + (o.battleArt.text || ''), { type: 'skill' });
  },
};

/** May this participant place/move/remove tactics for that side? The GM always; a player only for themselves. */
function tacticPlacer(s, actor, side) {
  if (actor.host) return true;
  const tac = s.tactics && s.tactics.sides[side];
  return side === 'player' && !!tac && tac.kind === 'player' && tac.userId === actor.id;
}

/** Overwatch: enemy ranged units on overwatch shoot `u` when it ends its turn in their range (one shot each,
 *  then the overwatch ends). Returns true if any fired. */
function overwatchFire(s, u) {
  let fired = false;
  for (const h of liveUnits(s)) {
    if (!alive(u) || u.hidden) break;
    if (!h.overwatch || !hostile(h, u)) continue;
    if (!rangeOk(s, h, u)) continue;
    delete h.overwatch;
    log(s, h.name + ' fires on overwatch: ' + u.name + ' ended its turn in range!', { type: 'overwatch', unit: h.id, on: false, fired: true });
    resolveAttack(s, h, u, { free: true, overwatch: true, ambush: !!h.hidden, noTactics: true });
    fired = true;
  }
  return fired;
}

/** Backs Turned: hostile units next to `u` that it moves away from strike it for free. Returns true if any did. */
function backsTurned(s, u, to) {
  let struck = false;
  for (const h of liveUnits(s)) {
    if (!alive(u)) break;
    if (!hostile(h, u) || manhattan(h, u) !== 1 || manhattan(h, to) <= 1) continue;
    if (!hasTactic(s, h, 'backsTurned') && !fireTactics(s, 'backsTurned', h).length) continue;
    log(s, h.name + ' strikes as ' + u.name + ' turns its back!');
    resolveAttack(s, h, u, { free: true, noTactics: true });
    struck = true;
  }
  return struck;
}

/** The end of an attacking turn: Skirmisher (move 1 tile, Skirmisher+ 2) after attacking, else the turn ends. */
function endAfterAttack(s, u, ac) {
  // Hit and Fade (Xianbei, David 2026-11-01): after attacking, the unit may use its remaining movement,
  // as long as it ends farther from the enemy it attacked. Replaces Skirmisher when it reaches farther.
  if (alive(u) && trait(u, 'hit and fade') && !ac.faded) {
    ac.faded = true;
    const left = Math.max(0, movementOf(s, u) - (ac.movedThisActivation ? (ac.tilesMoved || 0) : 0));
    const t = unitById(s, ac.lastTargetId);
    if (left > 0) {
      const reach = reachable(s, u, left);
      const from = t ? manhattan(u, t) : 0;
      const tiles = [...reach.keys()].map(k => k.split(',').map(Number))
        .filter(([x, y]) => !(x === u.x && y === u.y) && !unitAt(s, x, y) && (!t || !alive(t) || Math.abs(x - t.x) + Math.abs(y - t.y) > from));
      if (tiles.length) {
        ac.skirmished = true;
        ac.step = 'reposition'; ac.reposition = { skirmish: true, fade: true, tiles };
        log(s, u.name + ' may hit and fade: ride up to ' + left + ' tile' + (left === 1 ? '' : 's') + ' away.');
        return;
      }
    }
  }
  const sk = trait(u, 'skirmisher');
  if (alive(u) && sk && !ac.skirmished) {
    ac.skirmished = true;
    const reach = reachable(s, u, sk >= 2 ? 2 : 1);
    const tiles = [...reach.keys()].map(k => k.split(',').map(Number)).filter(([x, y]) => !(x === u.x && y === u.y) && !unitAt(s, x, y));
    if (tiles.length) {
      ac.step = 'reposition'; ac.reposition = { skirmish: true, tiles };
      log(s, u.name + ' may skirmish: move up to ' + (sk >= 2 ? 2 : 1) + ' tile' + (sk >= 2 ? 's' : '') + '.');
      return;
    }
  }
  finishActivation(s, u);
}

/** After an attack: Dual Weapons (once), then Fury of a Phoenix (once a round). Sets up the 'second' step. */
function offerSecond(s, u, ac, first, won, melee) {
  if (!alive(u)) return false;
  if (trait(u, 'dual weapons') && !ac.dualDone) {
    const targets = secondTargets(s, u, first);
    if (targets.length) { ac.step = 'second'; ac.second = { targets, kind: 'dual' }; log(s, u.name + ' may strike a second enemy.'); return true; }
  }
  if (melee && !u.round.phoenixUsed && hasTactic(s, u, 'phoenix')) {
    const targets = liveUnits(s).filter(o => hostile(o, u) && manhattan(o, u) === 1 && visibleTo(s, o, alliance(u.side))).map(o => o.id);
    if (targets.length) {
      u.round.phoenixUsed = true;
      ac.step = 'second'; ac.second = { targets, kind: 'phoenix', won: !!won };
      log(s, u.name + ' may make a second melee attack (Fury of a Phoenix).');
      return true;
    }
  }
  return false;
}

/** Open or close (lock) a gate next to the unit: its action for the turn. */
function gateAction(s, actor, a, to) {
  const r = activeUnit(s, actor, a.unitId); if (r.error) return r;
  const { u, act: ac } = r;
  if (u.round.attacked || ac.forcedMarched) return err('Working a gate is the unit\'s action for the turn');
  const g = gatesNear(s, u).find(x => !a.gateId || x.id === a.gateId);
  if (!g) return err('No gate next to this unit');
  if (!gateKeyHolder(s, u, g)) return err("This side can't work that gate from outside the city");
  if (to === 'open' && g.state !== 'locked') return err('The gate is already open');
  if (to === 'locked') {
    if (g.state !== 'open') return err(g.state === 'locked' ? 'The gate is already shut' : 'The gate is ' + g.state + ' and can no longer be shut');
    if (g.squares.some(([x, y]) => unitAt(s, x, y))) return err('Units are in the gateway');
  }
  g.state = to;
  log(s, u.name + (to === 'open' ? ' opens the gate.' : ' shuts the gate.'), { type: 'gate', gate: g.id, state: to, by: u.id });
  u.round.attacked = true;
  finishActivation(s, u);
}

function activeUnit(s, actor, unitId) {
  const ac = s.turn.activation;
  if (!ac || ac.unitId !== unitId) return err("It isn't that unit's turn");
  const u = unitById(s, unitId);
  if (!controls(s, actor, u)) return err('Not your unit');
  return { u, act: ac };
}

function doMove(s, actor, a, forced) {
  const r = activeUnit(s, actor, a.unitId); if (r.error) return r;
  const { u, act: ac } = r;
  if (forced) {
    if (!officerOf(s, u)) return err('Only units led by an officer can force-march');
    if (ac.step !== 'act' || u.round.attacked || ac.forcedMarched) return err('Forced march comes after moving, instead of attacking');
  } else if (ac.step !== 'move') return err('Already moved');
  if (u.round.cannotMove) return err('This unit cannot move this round');
  const budget = movementOf(s, u);
  let warning = null;
  if (s.freeMovement) {
    // On a virtual tabletop the token has already been dragged: record it, warn if too far.
    const dist = Math.abs(a.x - u.x) + Math.abs(a.y - u.y);
    if (dist > budget) warning = u.name + ' moved ' + dist + ' tiles; its movement is ' + budget + '.';
  } else {
    const reach = reachable(s, u, budget);
    if (!reach.has(a.x + ',' + a.y)) return err('Out of movement range or blocked');
  }
  backsTurned(s, u, { x: a.x, y: a.y });
  if (!alive(u)) return ok();
  if (forced) fireTactics(s, 'forcedMarch', u);
  const from = { x: u.x, y: u.y };
  const path = s.freeMovement ? null : reachable(s, u, budget), pk = a.x + ',' + a.y;
  const tiles = path ? (path.steps.get(pk) ?? 0) : Math.abs(a.x - u.x) + Math.abs(a.y - u.y);
  const roughPath = path ? path.rough.has(pk) : roughFor(s, a.x, a.y, u); // dragged token: only the end square is known
  u.x = a.x; u.y = a.y; u.round.moved = true;
  ac.started = true; ac.movedThisActivation = true;
  revealAround(s, u);
  if (!forced) { ac.tilesMoved = tiles; ac.roughPath = roughPath; }
  if (forced) {
    ac.forcedMarched = true;
    const fc = forcedMarchCost(s, u);
    u.morale = clamp(u.morale - fc, 0, 100);
    log(s, u.name + ' force-marches (-' + fc + ' morale).');
  } else ac.step = 'act';
  if (warning) log(s, 'Warning: ' + warning, { type: 'warning' });
  settle(s);
  if (forced && alive(u)) finishActivation(s, u);
  return ok(warning ? { warning } : {});
}

// ---------------------------------------------------------------- views

// State as seen by one participant: hidden enemy units are removed.
function viewFor(s, viewer) {
  const v = clone(s);
  if (!viewer.host) {
    v.units = v.units.filter(u => visibleTo(s, unitById(s, u.id), 'player'));
    // Never leak hidden-unit details through the log
    const hiddenIds = new Set(s.units.filter(u => !visibleTo(s, u, 'player')).map(u => u.id));
    v.log = v.log.filter(e => !(e.detail && e.detail.unit && hiddenIds.has(e.detail.unit)));
  }
  v.prompt = prompt(s);
  if (v.prompt.rank === Infinity) v.prompt.rank = 1e9; // JSON has no Infinity
  return v;
}

export { endRound as _endRound, imperialAura as _imperialAura, hidesIn as _hidesIn, officerWeaponLevel, casualtiesOf, evasionOf, evadeCasualties, disciplinedBonus, warDrumsBonus, hornReady, hornTargets, checkpointMorale, checkpointsPassed, overwatchFire as _overwatchFire, surroundAfterTurn as _surroundAfterTurn,
  moveOptions, attackTargets, actionMenu, threatArea, TACTIC_SIDES, tileRules, ladderTiles, climbTiles, insideCity, isWallTop, gateAt,
  newState, act, viewFor, prompt, reachable, duelTargets, movementOf, moraleState, visibleTo, rangeOk,
  resolveAttack, buildRoll, skillCheck, setRng, yinYang, typeOf, officerOf, unitById, SIDES, settle, advance,
};
