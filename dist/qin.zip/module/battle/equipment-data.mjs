// Equipment a unit can carry (David's Equipment traits from the Battle Sheets page, snapshot 2026-10-25; regenerate from
// r20import/sheets/traits.json when the sheet changes). Each piece is stored on the unit as a trait-list entry flagged
// `equip`, so the engine reads it like any other trait. Kinds (David, 2026-10-25):
//   upgrade — Sharpened Weapons, Reinforced Armor, Saddle: one of each, a higher tier replaces a lower
//   gear    — War Drums, Rallying Banner, War Horn, Medical Supplies (2026-11-09): a unit carries only ONE piece of gear in all
//   siege   — Siege Ladders or Siege Engine, never both
export const KIND_LABEL = { upgrade: "Upgrades", gear: "Gear (one piece)", siege: "Siege equipment (one piece)" };
export const EQUIPMENT = [
  { family: "Sharpened Weapons", kind: "upgrade", tiers: [
    { name: "Sharpened Weapons", desc: "Melee damage +1." },
    { name: "Sharpened Weapons+", desc: "Melee damage +2." },
    { name: "Sharpened Weapons++", desc: "Melee damage +3." },
  ] },
  { family: "Fine Arrows", kind: "upgrade", tiers: [
    { name: "Fine Arrows", desc: "Ranged units only. Ranged damage +1." },
    { name: "Fine Arrows+", desc: "Ranged units only. Ranged damage +2." },
    { name: "Fine Arrows++", desc: "Ranged units only. Ranged damage +3." },
  ] },
  { family: "Reinforced Armor", kind: "upgrade", tiers: [
    { name: "Reinforced Armor", desc: "Armor +1." },
    { name: "Reinforced Armor+", desc: "Armor +2." },
    { name: "Reinforced Armor++", desc: "Armor +3." },
  ] },
  { family: "Saddle", kind: "upgrade", tiers: [
    { name: "Saddle", desc: "Cavalry only. Attack +1." },
    { name: "Saddle+", desc: "Cavalry only. Attack +1, Melee defense +1." },
    { name: "Saddle++", desc: "Cavalry only. Attack +1, Melee defense +1, Movement +1." },
  ] },
  { family: "War Drums", kind: "gear", tiers: [
    { name: "War Drums", desc: "Allied units within 2 tiles gain Command rolls +1." },
    { name: "War Drums+", desc: "Allied units within 3 tiles gain Command rolls +1." },
    { name: "War Drums++", desc: "Allied units within 3 tiles gain Command rolls +2." },
  ] },
  { family: "Rallying Banner", kind: "gear", tiers: [
    { name: "Rallying Banner", desc: "Adjacent allied units gain 2 morale at the end of this unit's turn." },
    { name: "Rallying Banner+", desc: "Adjacent allied units gain 4 morale at the end of this unit's turn." },
    { name: "Rallying Banner++", desc: "Adjacent allied units gain 6 morale at the end of this unit's turn." },
  ] },
  { family: "War Horn", kind: "gear", tiers: [
    { name: "War Horn", desc: "Adds the Reinvigorate action: an adjacent allied unit reactivates and takes another turn immediately. Using it ends this unit's turn. Needs 3 turns to recharge after use." },
  ] },
  { family: "Medical Supplies", kind: "gear", tiers: [
    { name: "Medical Supplies", desc: "Adds the Tend the Wounded action: this unit or an adjacent ally regains 15% of its full health (never above its health at the start of the battle). 2 uses per battle. Takes the unit's turn; not while an enemy is next to it." },
    { name: "Medical Supplies+", desc: "As Medical Supplies, 3 uses per battle." },
    { name: "Medical Supplies++", desc: "As Medical Supplies, 3 uses per battle, and each heals 20% of full health." },
  ] },
  { family: "Siege Ladders", kind: "siege", tiers: [
    { name: "Siege Ladders", desc: "Gives the Place Ladder action next to a city wall or tower square without a ladder (not gates); it ends the turn and uses the ladders. Outside units next to a laddered wall square can fight the unit on it in melee, and can climb onto it if it is empty (all their movement; not cavalry or units carrying siege equipment). Can be dropped, and is dropped when the unit falls; an empty-handed unit on its square can pick it up (its action for the turn). No movement penalty (David, 2026-11-04)." },
  ] },
  { family: "Siege Engine", kind: "siege", tiers: [
    { name: "Siege Engine", desc: "Movement -1 while carried. Attack Gate deals double damage. Can be dropped, and is dropped when the unit falls; an empty-handed unit on its square can pick it up (its action for the turn). A unit carries ladders or a siege engine, never both." },
  ] },
];
const byName = new Map(EQUIPMENT.flatMap(f => f.tiers.map(t => [t.name, { ...t, family: f.family, kind: f.kind }])));
/** The catalogue entry for a name (exact), or null. */
export const equipmentByName = (name) => byName.get(String(name ?? "").trim()) ?? null;
/** The family a name belongs to (War Drums+ -> War Drums), or null when it isn't equipment. */
export const equipmentFamily = (name) => equipmentByName(name)?.family ?? null;
/** The kind of a piece: upgrade | gear | siege, or null. */
export const equipmentKind = (name) => equipmentByName(name)?.kind ?? null;
